/**
 * Frontend Applicatif - Gestion du Patrimoine Touristique
 * Architecture Single Page Application (SPA) Angular-style
 * Orchestration avec les microservices:
 * - API Gateway : http://localhost:8080 (ou direct 3000/3001/3002/3003/3004)
 */

// Configuration des endpoints d'API (utilise la Gateway par défaut avec fallback direct)
const API_CONFIG = {
    gatewayUrl: 'http://localhost:8080',
    authUrl: 'http://localhost:3000/api',
    patrimoineUrl: 'http://localhost:3001/api',
    circuitUrl: 'http://localhost:3002/api',
    evenementUrl: 'http://localhost:3003/api',
    reservationUrl: 'http://localhost:3004/api',
    useGateway: true // Si true, passe par http://localhost:8080/api/...
};

// Obtenir l'URL de base selon le service
function getApiUrl(service) {
    if (API_CONFIG.useGateway) {
        return `${API_CONFIG.gatewayUrl}/api/${service}`;
    }
    switch (service) {
        case 'auth':
        case 'guides':
        case 'avis':
        case 'signalements':
            return `http://localhost:3000/api/${service}`;
        case 'patrimoines':
            return `http://localhost:3001/api/patrimoines`;
        case 'circuits':
            return `http://localhost:3002/api/circuits`;
        case 'evenements':
            return `http://localhost:3003/api/evenements`;
        case 'reservations':
            return `http://localhost:3004/api/reservations`;
        default:
            return `${API_CONFIG.gatewayUrl}/api/${service}`;
    }
}

// --------------------------------------------------------------------------
// ETAT DE L'APPLICATION (Store)
// --------------------------------------------------------------------------
const AppState = {
    currentUser: null, // { id, nom, prenom, email, role, token, guideDetails }
    currentRoute: 'home',
    routeParam: null,
    sites: [],
    circuits: [],
    evenements: [],
    reservations: [],
    guides: [],
    signalements: [],
    userLocation: null, // { lat, lng }
    toastMessage: null,
    pagination: {
        page: 0,
        size: 4,
        total: 0
    }
};

// Données initiales de secours (fallback si les conteneurs backend sont en train de démarrer)
const SEED_FALLBACK = {
    sites: [
        {
            id: 1,
            nomPatrimoine: "Mémorial-Musée du Bateau Le Joola",
            codePatrimoine: "PMZ001",
            descriptionPatrimoine: "Espace de mémoire solennel et culturel dédié aux victimes du naufrage du 26 septembre 2002.",
            historiquePatrimoine: "Inauguré pour préserver le souvenir et l'histoire maritime de la Casamance.",
            adressePatrimoine: "Quartier Escale, berges du fleuve Casamance",
            ville: "Ziguinchor",
            horaires: "Mar - Dim : 09h00 - 18h00",
            typePatrimoine: "MUSEE",
            imageUrl: "src/img/memorial.png",
            capacitePatrimoine: 120,
            latitudePatrimoine: 12.5605,
            longitudePatrimoine: -16.2719
        },
        {
            id: 2,
            nomPatrimoine: "Case à Impluvium d'Enampore",
            codePatrimoine: "PMZ002",
            descriptionPatrimoine: "Chef-d'œuvre d'architecture en terre crue et paille avec puits de lumière central et captage d'eau.",
            historiquePatrimoine: "Habitat communautaire ancestral du royaume du Bandial.",
            adressePatrimoine: "Village d'Enampore, Royaume Bandial",
            ville: "Enampore",
            horaires: "Lun - Dim : 08h30 - 19h00",
            typePatrimoine: "MONUMENT",
            imageUrl: "src/img/case.png",
            capacitePatrimoine: 50,
            latitudePatrimoine: 12.5112,
            longitudePatrimoine: -16.4489
        },
        {
            id: 3,
            nomPatrimoine: "Île Historique de Carabane",
            codePatrimoine: "PMZ003",
            descriptionPatrimoine: "Ancien comptoir colonial français fondé en 1836, célèbre pour son église missionnaire et son cimetière marin.",
            historiquePatrimoine: "Premier comptoir français en Casamance, riche en vestiges coloniaux et faune fluviale.",
            adressePatrimoine: "Embouchure du fleuve Casamance",
            ville: "Carabane",
            horaires: "Tous les jours : 08h00 - 18h30",
            typePatrimoine: "SITE_NATUREL",
            imageUrl: "src/img/ilecarabane",
            capacitePatrimoine: 200,
            latitudePatrimoine: 12.5367,
            longitudePatrimoine: -16.6978
        },
        {
            id: 4,
            nomPatrimoine: "Musée Sangawatt de Boucotte",
            codePatrimoine: "PMZ004",
            descriptionPatrimoine: "Musée vivant des traditions diolas et des fétiches rituels, niché au cœur d'un bois sacré préservé.",
            historiquePatrimoine: "Créé par les anciens pour transmettre les secrets des rites d'initiation.",
            adressePatrimoine: "Village de Boucotte Oussouye",
            ville: "Oussouye",
            horaires: "Mer - Lun : 09h30 - 17h30",
            typePatrimoine: "MUSEE",
            imageUrl: "src/img/museeboucot.png",
            capacitePatrimoine: 60,
            latitudePatrimoine: 12.4851,
            longitudePatrimoine: -16.5458
        }
    ],
    circuits: [
        {
            id: 1,
            codeCircuit: "CIR001",
            nomCircuit: "Circuit Mémoire & Fleuve de Ziguinchor",
            descriptionCircuit: "Parcours historique pédestre à travers le quartier colonial de l'Escale et les berges du fleuve.",
            dureeTotale: 180,
            distanceTotale: 6,
            difficulte: "FACILE",
            capaciteMax: 25,
            etapes: [
                { id: 1, position: 1, dureeEstime: 60, patrimoineId: 1, patrimoine: { nomPatrimoine: "Mémorial-Musée Le Joola", ville: "Ziguinchor" } },
                { id: 2, position: 2, dureeEstime: 45, patrimoineId: 2, patrimoine: { nomPatrimoine: "Case à Impluvium", ville: "Enampore" } }
            ]
        },
        {
            id: 2,
            codeCircuit: "CIR002",
            nomCircuit: "Trésors des Royaumes du Bandial et d'Oussouye",
            descriptionCircuit: "Immersion culturelle au cœur des villages traditionnels diolas et des bois sacrés.",
            dureeTotale: 300,
            distanceTotale: 28,
            difficulte: "MOYEN",
            capaciteMax: 15,
            etapes: [
                { id: 3, position: 1, dureeEstime: 90, patrimoineId: 2, patrimoine: { nomPatrimoine: "Case à Impluvium", ville: "Enampore" } },
                { id: 4, position: 2, dureeEstime: 80, patrimoineId: 4, patrimoine: { nomPatrimoine: "Musée Sangawatt", ville: "Oussouye" } }
            ]
        }
    ],
    evenements: [
        {
            id: 1,
            titre: "Visite Guidée : Mémoire et Histoire du Joola",
            description: "Parcours commenté par un guide certifié à travers les galeries du mémorial et témoignages.",
            type: "VISITE_GUIDEE",
            dateDebut: "2026-11-20T10:00:00",
            dateFin: "2026-11-20T12:00:00",
            lieu: "Hall principal et quai d'embarquement",
            patrimoineId: 1,
            placesMax: 30,
            guideId: 2,
            guideNom: "Amadou Diallo"
        },
        {
            id: 2,
            titre: "Visite Guidée & Rituels du Royaume Bandial",
            description: "Découverte de l'architecture traditionnelle et explications des rites des moissons.",
            type: "VISITE_GUIDEE",
            dateDebut: "2026-11-21T14:30:00",
            dateFin: "2026-11-21T17:00:00",
            lieu: "Cour intérieure de la Case à Impluvium",
            patrimoineId: 2,
            placesMax: 20,
            guideId: 2,
            guideNom: "Amadou Diallo"
        }
    ],
    reservations: [
        {
            id: 1,
            typeReservation: "CIRCUIT",
            referenceId: 1,
            touristeId: 3,
            nomClient: "Awa Diop",
            email: "awa.diop@mail.com",
            dateVisite: "2026-11-20",
            nombrePlaces: 2,
            statut: "CONFIRMEE",
            qrCodeHash: "TKT-A79B124C",
            dateCreation: "2026-11-17T10:00:00"
        }
    ],
    guides: [
        {
            id: 1,
            userId: 2,
            nomComplet: "Amadou Diallo",
            email: "amadou.diallo@patrimoine.sn",
            numeroLicence: "GUIDE-CAS-2024-0042",
            biographie: "Guide professionnel certifié depuis 8 ans, historien de formation, expert du Bandial.",
            noteMoyenne: 4.9,
            estVerifie: true
        },
        {
            id: 2,
            userId: 4,
            nomComplet: "Fatou Sow",
            email: "fatou.sow@patrimoine.sn",
            numeroLicence: "GUIDE-CAS-2026-0105",
            biographie: "Diplômée d'un Master en Écotourisme, spécialiste des bolongs et de Carabane.",
            noteMoyenne: 5.0,
            estVerifie: false // En attente
        }
    ],
    avis: [
        {
            id: 1,
            siteId: 1,
            guideId: 2,
            touristeId: 3,
            touristeNom: "Awa Diop",
            note: 5,
            commentaire: "Visite très émouvante du Mémorial Le Joola. Le guide Amadou maîtrise parfaitement son sujet.",
            datePublication: "2026-11-16T14:30:00",
            reponseGuide: "Merci beaucoup Awa ! C'est un honneur de transmettre cette mémoire.",
            estSignale: false
        }
    ],
    signalements: [
        {
            id: 1,
            avisId: 3,
            signaleurId: 2,
            signaleurNom: "Amadou Diallo",
            motif: "Commentaire diffamatoire et haineux sans lien avec la visite.",
            dateSignalement: "2026-11-17T11:00:00",
            statut: "EN_ATTENTE"
        }
    ]
};

// --------------------------------------------------------------------------
// SERVICES HTTP AVEC FALLBACK ET LOGS
// --------------------------------------------------------------------------
async function apiGet(endpoint, fallbackKey) {
    try {
        const response = await fetch(endpoint, { method: 'GET', headers: { 'Accept': 'application/json' } });
        if (response.ok) {
            return await response.json();
        }
    } catch (err) {
        console.warn(`[API] Echec GET ${endpoint}, utilisation du cache local.`, err);
    }
    return fallbackKey ? SEED_FALLBACK[fallbackKey] : null;
}

async function apiPost(endpoint, body, fallbackKey) {
    try {
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify(body)
        });
        if (response.ok) {
            return await response.json();
        }
    } catch (err) {
        console.warn(`[API] Echec POST ${endpoint}, simulation locale.`, err);
    }
    // Simulation locale
    const newObj = { ...body, id: Date.now() };
    if (fallbackKey && SEED_FALLBACK[fallbackKey]) {
        SEED_FALLBACK[fallbackKey].push(newObj);
    }
    return newObj;
}

async function apiPut(endpoint, body) {
    try {
        const response = await fetch(endpoint, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: body ? JSON.stringify(body) : null
        });
        if (response.ok) {
            return await response.json();
        }
    } catch (err) {
        console.warn(`[API] Echec PUT ${endpoint}`, err);
    }
    return { success: true };
}

async function apiDelete(endpoint) {
    try {
        await fetch(endpoint, { method: 'DELETE' });
    } catch (err) {
        console.warn(`[API] Echec DELETE ${endpoint}`, err);
    }
    return true;
}

// --------------------------------------------------------------------------
// UTILITAIRE GEOLOCALISATION GPS (Slide 46 & 49)
// --------------------------------------------------------------------------
function calculateDistanceKm(lat1, lon1, lat2, lon2) {
    if (!lat1 || !lon1 || !lat2 || !lon2) return null;
    const R = 6371; // Rayon de la Terre en km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
        Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return Math.round(R * c * 10) / 10;
}

function getUserLocation() {
    return new Promise((resolve) => {
        if ("geolocation" in navigator) {
            navigator.geolocation.getCurrentPosition(
                (pos) => {
                    const loc = { lat: pos.coords.latitude, lng: pos.coords.longitude };
                    AppState.userLocation = loc;
                    resolve(loc);
                },
                (err) => {
                    // Fallback sur Ziguinchor par défaut si permission refusée
                    console.info("Géolocalisation désactivée, utilisation coordonnées de Ziguinchor");
                    const loc = { lat: 12.5605, lng: -16.2719 };
                    AppState.userLocation = loc;
                    resolve(loc);
                },
                { timeout: 5000 }
            );
        } else {
            const loc = { lat: 12.5605, lng: -16.2719 };
            AppState.userLocation = loc;
            resolve(loc);
        }
    });
}

// --------------------------------------------------------------------------
// GENERATEUR QR CODE SVG POUR TICKETS DE VISITE (Slide 46/50)
// --------------------------------------------------------------------------
function generateQrCodeSvg(text) {
    // Générateur visuel de QR Code SVG stylisé basé sur le hash
    let hash = 0;
    for (let i = 0; i < text.length; i++) {
        hash = (hash << 5) - hash + text.charCodeAt(i);
        hash |= 0;
    }
    const size = 180;
    const grid = 15;
    const cellSize = size / grid;

    let rects = '';
    for (let r = 0; r < grid; r++) {
        for (let c = 0; c < grid; c++) {
            // Coins de repère fixes
            const isCorner = (r < 4 && c < 4) || (r < 4 && c >= grid - 4) || (r >= grid - 4 && c < 4);
            const isCornerBorder = isCorner && (r === 0 || r === 3 || c === 0 || c === 3 ||
                r === grid - 1 || r === grid - 4 || c === grid - 1 || c === grid - 4);
            const isCornerCenter = (r >= 1 && r <= 2 && c >= 1 && c <= 2) ||
                (r >= 1 && r <= 2 && c >= grid - 3 && c <= grid - 2) ||
                (r >= grid - 3 && r <= grid - 2 && c >= 1 && c <= 2);

            let filled = isCornerBorder || isCornerCenter;
            if (!isCorner) {
                const bit = Math.abs((hash ^ (r * 31 + c * 17))) % 2 === 0;
                filled = bit;
            }

            if (filled) {
                rects += `<rect x="${c * cellSize}" y="${r * cellSize}" width="${cellSize - 0.5}" height="${cellSize - 0.5}" fill="#1e293b" rx="1.5" />`;
            }
        }
    }

    return `
        <svg width="${size}" height="${size}" viewBox="0 0 ${size}" xmlns="http://www.w3.org/2000/svg" style="background:#fff; padding:6px; border-radius:8px;">
            ${rects}
        </svg>
    `;
}

// --------------------------------------------------------------------------
// GESTION DES NOTIFICATIONS ET TOASTS
// --------------------------------------------------------------------------
function showToast(message, type = 'success') {
    const container = document.getElementById('toast-container');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = `alert alert-${type} alert-dismissible fade show shadow-sm`;
    toast.innerHTML = `
        <i class="bi ${type === 'success' ? 'bi-check-circle-fill' : 'bi-exclamation-triangle-fill'} me-2"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    container.appendChild(toast);
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

// --------------------------------------------------------------------------
// GESTION DU ROUTAGE ET DE LA SESSION
// --------------------------------------------------------------------------
function navigateTo(route, param = null) {
    AppState.currentRoute = route;
    AppState.routeParam = param;
    window.location.hash = `#${route}` + (param ? `/${param}` : '');
    renderApp();
}

function handleHashChange() {
    const hash = window.location.hash.slice(1);
    if (!hash) {
        navigateTo('home');
        return;
    }
    const parts = hash.split('/');
    AppState.currentRoute = parts[0] || 'home';
    AppState.routeParam = parts[1] || null;
    renderApp();
}

window.addEventListener('hashchange', handleHashChange);

// --------------------------------------------------------------------------
// PROFILS DE DEMONSTRATION EN 1-CLIC
// --------------------------------------------------------------------------
function switchDemoUser(role) {
    switch (role) {
        case 'ADMIN':
            AppState.currentUser = {
                id: 1,
                nom: "Fall",
                prenom: "Babacar",
                email: "admin@patrimoine.sn",
                role: "ADMIN",
                token: "token-admin"
            };
            showToast("Connecté en tant que Conservateur (Administrateur)", "info");
            navigateTo('conservateur');
            break;
        case 'GUIDE_VERIFIE':
            AppState.currentUser = {
                id: 2,
                nom: "Diallo",
                prenom: "Amadou",
                email: "amadou.diallo@patrimoine.sn",
                role: "GUIDE",
                token: "token-guide",
                guideDetails: {
                    id: 1,
                    userId: 2,
                    numeroLicence: "GUIDE-CAS-2024-0042",
                    biographie: "Guide certifié Casamance, spécialiste de l'histoire du Joola et du royaume du Bandial.",
                    noteMoyenne: 4.9,
                    estVerifie: true
                }
            };
            showToast("Connecté en tant que Guide Vérifié (Amadou Diallo)", "info");
            navigateTo('guide');
            break;
        case 'GUIDE_ATTENTE':
            AppState.currentUser = {
                id: 4,
                nom: "Sow",
                prenom: "Fatou",
                email: "fatou.sow@patrimoine.sn",
                role: "GUIDE",
                token: "token-guide-wait",
                guideDetails: {
                    id: 2,
                    userId: 4,
                    numeroLicence: "GUIDE-CAS-2026-0105",
                    biographie: "Diplômée d'Écotourisme, en attente de vérification par le conservateur.",
                    noteMoyenne: 5.0,
                    estVerifie: false
                }
            };
            showToast("Connecté en tant que Guide en Attente (Fatou Sow)", "warning");
            navigateTo('guide');
            break;
        case 'TOURIST':
            AppState.currentUser = {
                id: 3,
                nom: "Diop",
                prenom: "Awa",
                email: "awa.diop@mail.com",
                role: "TOURIST",
                token: "token-tourist"
            };
            showToast("Connecté en tant que Touriste (Awa Diop)", "success");
            navigateTo('mes-reservations');
            break;
        case 'VISITEUR':
        default:
            AppState.currentUser = null;
            showToast("Mode Visiteur public (déconnecté)", "secondary");
            navigateTo('home');
            break;
    }
    localStorage.setItem('patrimoine_user', JSON.stringify(AppState.currentUser));
}

function logout() {
    AppState.currentUser = null;
    localStorage.removeItem('patrimoine_user');
    showToast("Vous avez été déconnecté.", "secondary");
    navigateTo('home');
}

// --------------------------------------------------------------------------
// CHARGEMENT INITIAL DES DONNEES
// --------------------------------------------------------------------------
async function loadInitialData() {
    const saved = localStorage.getItem('patrimoine_user');
    if (saved) {
        try { AppState.currentUser = JSON.parse(saved); } catch (e) {}
    }

    // Charger les sites
    AppState.sites = await apiGet(`${getApiUrl('patrimoines')}`, 'sites');
    // Charger les circuits
    AppState.circuits = await apiGet(`${getApiUrl('circuits')}`, 'circuits');
    // Charger les événements
    AppState.evenements = await apiGet(`${getApiUrl('evenements')}`, 'evenements');
    // Obtenir la position GPS
    await getUserLocation();

    handleHashChange();
}

// --------------------------------------------------------------------------
// MOTEUR DE RENDU DU TEMPLATE (Angular-like Component View)
// --------------------------------------------------------------------------
function renderApp() {
    const appRoot = document.getElementById('app-root');
    if (!appRoot) return;

    appRoot.innerHTML = `
        ${renderDemoBar()}
        ${renderNavbar()}
        <div id="toast-container" class="position-fixed top-0 end-0 p-3" style="z-index: 1080;"></div>
        <main class="main-content">
            ${renderCurrentView()}
        </main>
        ${renderFooter()}
        ${renderModals()}
    `;
}

// 1. Barre de démonstration rapide
function renderDemoBar() {
    const u = AppState.currentUser;
    return `
        <div class="demo-bar d-flex flex-wrap align-items-center justify-content-between px-3 py-1">
            <div>
                <i class="bi bi-person-badge me-1"></i>
                <strong>Statut actuel :</strong>
                ${u ? `<span class="badge bg-success ms-1">${u.prenom} ${u.nom} (${u.role})</span>` : `<span class="badge bg-secondary ms-1">Visiteur (Non connecté)</span>`}
            </div>
            <div class="d-flex align-items-center flex-wrap gap-1">
                <span class="d-none d-md-inline text-muted me-1">Connexion 1-clic :</span>
                <button class="btn btn-sm btn-outline-info text-white" onclick="switchDemoUser('ADMIN')"><i class="bi bi-shield-lock"></i> Conservateur</button>
                <button class="btn btn-sm btn-outline-success text-white" onclick="switchDemoUser('GUIDE_VERIFIE')"><i class="bi bi-award"></i> Guide Vérifié</button>
                <button class="btn btn-sm btn-outline-warning text-white" onclick="switchDemoUser('GUIDE_ATTENTE')"><i class="bi bi-hourglass-split"></i> Guide En Attente</button>
                <button class="btn btn-sm btn-outline-primary text-white" onclick="switchDemoUser('TOURIST')"><i class="bi bi-compass"></i> Touriste</button>
                ${u ? `<button class="btn btn-sm btn-danger ms-2" onclick="logout()"><i class="bi bi-box-arrow-right"></i> Déconnexion</button>` : ''}
            </div>
        </div>
    `;
}

// 2. Barre de Navigation principale
function renderNavbar() {
    const u = AppState.currentUser;
    const r = AppState.currentRoute;

    return `
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow-sm py-2">
            <div class="container">
                <a class="navbar-brand d-flex align-items-center" href="#home" onclick="navigateTo('home')">
                    <i class="bi bi-bank2 me-2 text-warning fs-4"></i>
                    <span class="fw-bold">Patrimoine Casamance</span>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navContent">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link ${r === 'home' ? 'active fw-bold' : ''}" href="#home" onclick="navigateTo('home')">
                                <i class="bi bi-house-door me-1"></i>Accueil
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link ${r === 'sites' ? 'active fw-bold' : ''}" href="#sites" onclick="navigateTo('sites')">
                                <i class="bi bi-geo-alt me-1"></i>Sites & Monuments
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link ${r === 'circuits' ? 'active fw-bold' : ''}" href="#circuits" onclick="navigateTo('circuits')">
                                <i class="bi bi-map me-1"></i>Circuits
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link ${r === 'evenements' ? 'active fw-bold' : ''}" href="#evenements" onclick="navigateTo('evenements')">
                                <i class="bi bi-calendar-event me-1"></i>Visites & Événements
                            </a>
                        </li>
                    </ul>

                    <ul class="navbar-nav align-items-center gap-2">
                        ${!u ? `
                            <li class="nav-item">
                                <button class="btn btn-outline-light btn-sm" onclick="navigateTo('login')">
                                    <i class="bi bi-box-arrow-in-right me-1"></i>Se connecter
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="btn btn-warning btn-sm fw-semibold" onclick="navigateTo('register')">
                                    <i class="bi bi-person-plus me-1"></i>S'inscrire
                                </button>
                            </li>
                        ` : ''}

                        ${u && u.role === 'TOURIST' ? `
                            <li class="nav-item">
                                <button class="btn btn-primary btn-sm" onclick="navigateTo('mes-reservations')">
                                    <i class="bi bi-ticket-perforated me-1"></i>Mes Réservations
                                </button>
                            </li>
                        ` : ''}

                        ${u && u.role === 'GUIDE' ? `
                            <li class="nav-item">
                                <button class="btn btn-success btn-sm" onclick="navigateTo('guide')">
                                    <i class="bi bi-person-badge me-1"></i>Espace Guide
                                    ${u.guideDetails && !u.guideDetails.estVerifie ? '<span class="badge bg-warning text-dark ms-1">!</span>' : ''}
                                </button>
                            </li>
                        ` : ''}

                        ${u && u.role === 'ADMIN' ? `
                            <li class="nav-item">
                                <button class="btn btn-danger btn-sm" onclick="navigateTo('conservateur')">
                                    <i class="bi bi-speedometer2 me-1"></i>Espace Conservateur
                                </button>
                            </li>
                        ` : ''}
                    </ul>
                </div>
            </div>
        </nav>
    `;
}

// 3. Rendu de la vue active selon le routeur
function renderCurrentView() {
    switch (AppState.currentRoute) {
        case 'home':
            return renderHomeView();
        case 'sites':
            return renderSitesView();
        case 'site-detail':
            return renderSiteDetailView(AppState.routeParam);
        case 'circuits':
            return renderCircuitsView();
        case 'evenements':
            return renderEvenementsView();
        case 'mes-reservations':
            return renderTouristeReservationsView();
        case 'guide':
            return renderGuideView();
        case 'conservateur':
            return renderConservateurView();
        case 'login':
            return renderLoginView();
        case 'register':
            return renderRegisterView();
        default:
            return renderHomeView();
    }
}

// --------------------------------------------------------------------------
// VUE 1 : ACCUEIL (HERO + RECHERCHE GPS PROXIMITE + EN VEDETTE)
// --------------------------------------------------------------------------
function renderHomeView() {
    const loc = AppState.userLocation;
    const sitesWithDist = (AppState.sites || []).map(s => {
        const d = loc ? calculateDistanceKm(loc.lat, loc.lng, s.latitudePatrimoine, s.longitudePatrimoine) : null;
        return { ...s, distanceKm: d };
    });

    if (loc) {
        sitesWithDist.sort((a, b) => (a.distanceKm || 9999) - (b.distanceKm || 9999));
    }

    return `
        <div class="hero-banner text-center shadow-sm">
            <div class="container py-4">
                <span class="badge bg-warning text-dark px-3 py-2 rounded-pill text-uppercase fw-bold mb-3">
                    <i class="bi bi-compass me-1"></i>Patrimoine & Écotourisme du Sénégal
                </span>
                <h1 class="display-4 fw-bold mb-3">Explorez la Richesse Historique et Culturelle de Casamance</h1>
                <p class="lead mb-4 mx-auto" style="max-width: 750px;">
                    Mémorial du Joola, cases à impluvium, comptoirs coloniaux et îles mystiques.
                    Réservez vos visites guidées avec des guides certifiés et conservez vos billets avec QR Code.
                </p>

                <!-- Barre de recherche rapide (Slide 46) -->
                <div class="card shadow-lg p-2 mx-auto border-0" style="max-width: 650px; border-radius: 50px;">
                    <div class="input-group">
                        <span class="input-group-text bg-transparent border-0 ps-3">
                            <i class="bi bi-search text-muted fs-5"></i>
                        </span>
                        <input type="text" id="quickSearchInput" class="form-control border-0 shadow-none"
                               placeholder="Rechercher un monument, un musée, une ville (ex: Ziguinchor, Carabane)..."
                               onkeyup="if(event.key === 'Enter') handleQuickSearch()">
                        <button class="btn btn-warning px-4 rounded-pill fw-bold text-dark" onclick="handleQuickSearch()">
                            Rechercher
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <div class="container mb-5">
            <!-- Widget Géolocalisation GPS Proximité (Slide 46 & 49) -->
            <div class="card border-0 shadow-sm mb-5 bg-white" style="border-radius: 16px;">
                <div class="card-body p-4">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h4 class="fw-bold mb-1 text-primary">
                                <i class="bi bi-geo-alt-fill text-danger me-2"></i>Recherche par proximité GPS
                            </h4>
                            <p class="text-muted mb-md-0">
                                Vos coordonnées GPS actuelles :
                                <strong>${loc ? `${loc.lat.toFixed(4)}°N, ${loc.lng.toFixed(4)}°E` : 'Détection en cours...'}</strong>.
                                Les sites ci-dessous sont classés automatiquement par distance.
                            </p>
                        </div>
                        <div class="col-md-4 text-md-end">
                            <button class="btn btn-outline-primary rounded-pill px-3" onclick="refreshGps()">
                                <i class="bi bi-arrow-clockwise me-1"></i>Actualiser ma position
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Liste des sites en vedette -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold mb-0">Sites du Patrimoine à Découvrir</h3>
                    <p class="text-muted mb-0">Classés par proximité et intérêt historique</p>
                </div>
                <button class="btn btn-outline-secondary btn-sm" onclick="navigateTo('sites')">
                    Voir tout le catalogue (${AppState.sites.length}) <i class="bi bi-arrow-right"></i>
                </button>
            </div>

            <div class="row g-4 mb-5">
                ${sitesWithDist.slice(0, 3).map(site => renderSiteCard(site)).join('')}
            </div>

            <!-- Section Circuits & Visites à la une -->
            <div class="row g-4 mt-2">
                <div class="col-lg-6">
                    <div class="card h-100 border-0 shadow-sm p-3" style="border-radius: 16px;">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h4 class="fw-bold mb-0 text-success"><i class="bi bi-signpost-split me-2"></i>Circuits Touristiques</h4>
                                <a href="#circuits" class="btn btn-link btn-sm text-decoration-none" onclick="navigateTo('circuits')">Voir tous</a>
                            </div>
                            <p class="text-muted">Parcourez plusieurs sites historiques en étapes orchestrées.</p>
                            <div class="list-group list-group-flush">
                                ${AppState.circuits.slice(0, 2).map(c => `
                                    <div class="list-group-item px-0 py-3 d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="fw-bold mb-1">${c.nomCircuit}</h6>
                                            <small class="text-muted">
                                                <i class="bi bi-clock me-1"></i>${Math.round(c.dureeTotale / 60)}h |
                                                <i class="bi bi-pin-map me-1"></i>${c.distanceTotale} km |
                                                <span class="badge bg-secondary">${c.difficulte}</span>
                                            </small>
                                        </div>
                                        <button class="btn btn-sm btn-outline-success rounded-pill" onclick="openBookingModal('CIRCUIT', ${c.id}, '${c.nomCircuit.replace(/'/g, "\\'")}')">
                                            Réserver
                                        </button>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="card h-100 border-0 shadow-sm p-3" style="border-radius: 16px;">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h4 class="fw-bold mb-0 text-primary"><i class="bi bi-person-video3 me-2"></i>Visites Guidées & Ateliers</h4>
                                <a href="#evenements" class="btn btn-link btn-sm text-decoration-none" onclick="navigateTo('evenements')">Voir tous</a>
                            </div>
                            <p class="text-muted">Des visites immersives animées par nos guides locaux certifiés.</p>
                            <div class="list-group list-group-flush">
                                ${AppState.evenements.slice(0, 2).map(ev => `
                                    <div class="list-group-item px-0 py-3 d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="fw-bold mb-1">${ev.titre}</h6>
                                            <small class="text-muted">
                                                <i class="bi bi-person-badge text-primary me-1"></i>Guide : ${ev.guideNom || 'Guide certifié'} |
                                                <span class="badge bg-info text-dark">${ev.type}</span>
                                            </small>
                                        </div>
                                        <button class="btn btn-sm btn-outline-primary rounded-pill" onclick="openBookingModal('EVENEMENT', ${ev.id}, '${ev.titre.replace(/'/g, "\\'")}')">
                                            Réserver
                                        </button>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function handleQuickSearch() {
    const input = document.getElementById('quickSearchInput');
    if (!input) return;
    const q = input.value.trim();
    navigateTo('sites', q);
}

async function refreshGps() {
    showToast("Actualisation de votre position GPS...", "info");
    await getUserLocation();
    renderApp();
    showToast("Coordonnées GPS actualisées !", "success");
}

// --------------------------------------------------------------------------
// VUE 2 : CATALOGUE DES SITES AVEC FILTRES ET PAGINATION (Slide 15-19)
// --------------------------------------------------------------------------
function renderSitesView() {
    const loc = AppState.userLocation;
    let sites = [...AppState.sites];

    // Recherche par mot clé si passé dans l'URL ou filtré
    const q = (AppState.routeParam || '').toLowerCase();
    if (q) {
        sites = sites.filter(s =>
            (s.nomPatrimoine && s.nomPatrimoine.toLowerCase().includes(q)) ||
            (s.ville && s.ville.toLowerCase().includes(q)) ||
            (s.descriptionPatrimoine && s.descriptionPatrimoine.toLowerCase().includes(q))
        );
    }

    // Calcul distance
    sites = sites.map(s => {
        const d = loc ? calculateDistanceKm(loc.lat, loc.lng, s.latitudePatrimoine, s.longitudePatrimoine) : null;
        return { ...s, distanceKm: d };
    });

    // Pagination (Slide 15-17 du cours)
    const page = AppState.pagination.page;
    const size = AppState.pagination.size;
    const totalPages = Math.ceil(sites.length / size) || 1;
    const paginatedSites = sites.slice(page * size, (page + 1) * size);

    return `
        <div class="container py-4">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#home" onclick="navigateTo('home')">Accueil</a></li>
                    <li class="breadcrumb-item active">Catalogue des Sites</li>
                </ol>
            </nav>

            <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="fw-bold mb-1">Patrimoine & Monuments Historiques</h2>
                    <p class="text-muted mb-0">${sites.length} site(s) disponible(s) en Casamance</p>
                </div>
                ${AppState.currentUser && AppState.currentUser.role === 'ADMIN' ? `
                    <button class="btn btn-success" onclick="openAddSiteModal()">
                        <i class="bi bi-plus-circle me-1"></i>Ajouter un Site
                    </button>
                ` : ''}
            </div>

            <!-- Filtres multicritères (Slide 46) -->
            <div class="card border-0 shadow-sm p-3 mb-4 bg-white" style="border-radius: 12px;">
                <div class="row g-2 align-items-center">
                    <div class="col-md-5">
                        <div class="input-group">
                            <span class="input-group-text bg-light border-0"><i class="bi bi-search"></i></span>
                            <input type="text" id="siteFilterKeyword" class="form-control bg-light border-0"
                                   placeholder="Rechercher par mot-clé..." value="${AppState.routeParam || ''}">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <select id="siteFilterCity" class="form-select bg-light border-0">
                            <option value="">Toutes les villes</option>
                            <option value="Ziguinchor">Ziguinchor</option>
                            <option value="Enampore">Enampore</option>
                            <option value="Carabane">Carabane</option>
                            <option value="Oussouye">Oussouye</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select id="siteFilterType" class="form-select bg-light border-0">
                            <option value="">Tous les types</option>
                            <option value="MUSEE">Musée</option>
                            <option value="MONUMENT">Monument</option>
                            <option value="SITE_NATUREL">Site Naturel</option>
                            <option value="PARC">Parc</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-primary w-100" onclick="applySiteFilters()">
                            <i class="bi bi-funnel me-1"></i>Filtrer
                        </button>
                    </div>
                </div>
            </div>

            <!-- Grille des sites -->
            <div class="row g-4 mb-4">
                ${paginatedSites.length > 0
                    ? paginatedSites.map(s => renderSiteCard(s)).join('')
                    : `<div class="col-12 text-center py-5">
                           <i class="bi bi-search text-muted fs-1 mb-3 d-block"></i>
                           <h5>Aucun site ne correspond à votre recherche</h5>
                           <p class="text-muted">Essayez d'autres mots-clés ou réinitialisez les filtres.</p>
                           <button class="btn btn-outline-primary btn-sm" onclick="navigateTo('sites')">Voir tous les sites</button>
                       </div>`
                }
            </div>

            <!-- Pagination (Slide 16-17) -->
            ${totalPages > 1 ? `
                <div class="d-flex justify-content-center mt-4">
                    <ul class="pagination shadow-sm">
                        <li class="page-item ${page === 0 ? 'disabled' : ''}">
                            <button class="page-link" onclick="changeSitePage(${page - 1})">Précédent</button>
                        </li>
                        ${Array.from({ length: totalPages }).map((_, i) => `
                            <li class="page-item ${i === page ? 'active' : ''}">
                                <button class="page-link" onclick="changeSitePage(${i})">${i + 1}</button>
                            </li>
                        `).join('')}
                        <li class="page-item ${page >= totalPages - 1 ? 'disabled' : ''}">
                            <button class="page-link" onclick="changeSitePage(${page + 1})">Suivant</button>
                        </li>
                    </ul>
                </div>
            ` : ''}
        </div>
    `;
}

function renderSiteCard(site) {
    const badgeClass = `badge-${(site.typePatrimoine || 'monument').toLowerCase().replace('_', '-')}`;
    const defaultImg = "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=800&q=80";

    return `
        <div class="col-md-6 col-lg-4">
            <div class="card card-site h-100 bg-white">
                <div class="position-relative">
                    <img src="${site.imageUrl || defaultImg}" class="card-img-top" alt="${site.nomPatrimoine}">
                    <span class="badge ${badgeClass} position-absolute top-0 start-0 m-3 px-3 py-2 rounded-pill shadow-sm">
                        ${site.typePatrimoine || 'PATRIMOINE'}
                    </span>
                    ${site.distanceKm !== null && site.distanceKm !== undefined ? `
                        <span class="badge bg-dark bg-opacity-75 text-white position-absolute bottom-0 end-0 m-3 px-2 py-1 rounded">
                            <i class="bi bi-geo-alt-fill text-danger me-1"></i>${site.distanceKm} km
                        </span>
                    ` : ''}
                </div>
                <div class="card-body d-flex flex-direction-column flex-column justify-content-between p-4">
                    <div>
                        <div class="d-flex align-items-center text-muted small mb-2">
                            <i class="bi bi-geo-alt me-1"></i>${site.ville || 'Casamance'}
                            <span class="mx-2">•</span>
                            <i class="bi bi-people me-1"></i>Capacité : ${site.capacitePatrimoine || 50} pers.
                        </div>
                        <h5 class="card-title fw-bold text-dark mb-2">${site.nomPatrimoine}</h5>
                        <p class="card-text text-muted small line-clamp-3 mb-3">
                            ${(site.descriptionPatrimoine || '').substring(0, 120)}...
                        </p>
                    </div>
                    <div class="pt-3 border-top d-flex justify-content-between align-items-center">
                        <small class="text-muted"><i class="bi bi-clock me-1"></i>${site.horaires || 'Ouvert'}</small>
                        <button class="btn btn-sm btn-outline-primary rounded-pill px-3" onclick="navigateTo('site-detail', ${site.id})">
                            Détails <i class="bi bi-arrow-right ms-1"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function applySiteFilters() {
    const kw = document.getElementById('siteFilterKeyword')?.value.trim() || '';
    const city = document.getElementById('siteFilterCity')?.value || '';
    const type = document.getElementById('siteFilterType')?.value || '';
    AppState.pagination.page = 0;
    navigateTo('sites', kw || city || type);
}

function changeSitePage(p) {
    AppState.pagination.page = p;
    renderApp();
}

// --------------------------------------------------------------------------
// VUE 3 : FICHE DETAILLEE D'UN SITE (Slide 24/25, 46, 50)
// --------------------------------------------------------------------------
async function renderSiteDetailView(siteId) {
    const id = parseInt(siteId);
    let site = AppState.sites.find(s => s.id === id);
    if (!site) {
        site = await apiGet(`${getApiUrl('patrimoines')}/${id}`, null) || SEED_FALLBACK.sites[0];
    }

    // Récupérer les avis du site
    let avisData = await apiGet(`${getApiUrl('avis')}/site/${id}`, null);
    if (!avisData) {
        avisData = {
            avis: SEED_FALLBACK.avis.filter(a => a.siteId === id),
            noteMoyenne: 4.8,
            totalAvis: 1
        };
    }

    // Circuits & événements liés à ce site
    const relatedCircuits = AppState.circuits.filter(c =>
        c.etapes && c.etapes.some(e => e.patrimoineId === id)
    );
    const relatedEvents = AppState.evenements.filter(e => e.patrimoineId === id);

    const defaultImg = "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=1200&q=80";

    const contentHtml = `
        <div class="container py-4">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#home" onclick="navigateTo('home')">Accueil</a></li>
                    <li class="breadcrumb-item"><a href="#sites" onclick="navigateTo('sites')">Sites</a></li>
                    <li class="breadcrumb-item active">${site.nomPatrimoine}</li>
                </ol>
            </nav>

            <!-- Bannière et informations principales -->
            <div class="card border-0 shadow-sm overflow-hidden mb-4" style="border-radius: 16px;">
                <div class="row g-0">
                    <div class="col-lg-6">
                        <img src="${site.imageUrl || defaultImg}" class="img-fluid h-100 w-100" style="object-fit: cover; min-height: 380px;" alt="${site.nomPatrimoine}">
                    </div>
                    <div class="col-lg-6 p-4 p-md-5 d-flex flex-column justify-content-between">
                        <div>
                            <div class="d-flex align-items-center gap-2 mb-2">
                                <span class="badge bg-primary text-uppercase">${site.typePatrimoine || 'PATRIMOINE'}</span>
                                <span class="badge bg-secondary">${site.codePatrimoine}</span>
                                <div class="star-rating d-inline-block ms-auto">
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <strong class="ms-1">${avisData.noteMoyenne || 5.0}</strong>
                                    <small class="text-muted">(${avisData.totalAvis || 0} avis)</small>
                                </div>
                            </div>

                            <h2 class="fw-bold mb-3">${site.nomPatrimoine}</h2>
                            <p class="text-muted mb-4">${site.descriptionPatrimoine}</p>

                            <div class="row g-3 mb-4">
                                <div class="col-6">
                                    <div class="p-3 bg-light rounded-3">
                                        <small class="text-muted d-block"><i class="bi bi-geo-alt text-danger me-1"></i>Ville / Adresse</small>
                                        <strong>${site.ville}</strong>, ${site.adressePatrimoine}
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="p-3 bg-light rounded-3">
                                        <small class="text-muted d-block"><i class="bi bi-clock text-primary me-1"></i>Horaires d'ouverture</small>
                                        <strong>${site.horaires || '09h - 18h'}</strong>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="p-3 bg-light rounded-3">
                                        <small class="text-muted d-block"><i class="bi bi-people text-success me-1"></i>Capacité d'accueil</small>
                                        <strong>${site.capacitePatrimoine} visiteurs</strong>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="p-3 bg-light rounded-3">
                                        <small class="text-muted d-block"><i class="bi bi-pin-map text-warning me-1"></i>Coordonnées GPS</small>
                                        <strong>${site.latitudePatrimoine}°N, ${site.longitudePatrimoine}°E</strong>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="d-flex gap-2">
                            <button class="btn btn-warning px-4 fw-bold text-dark rounded-pill"
                                    onclick="openBookingModal('CIRCUIT', 1, 'Visite au ${site.nomPatrimoine.replace(/'/g, "\\'")}')">
                                <i class="bi bi-calendar-check me-1"></i>Réserver une visite
                            </button>
                            <a href="https://www.google.com/maps/search/?api=1&query=${site.latitudePatrimoine},${site.longitudePatrimoine}"
                               target="_blank" class="btn btn-outline-secondary rounded-pill px-3">
                                <i class="bi bi-map me-1"></i>Itinéraire GPS
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Historique et contexte culturel -->
            <div class="card border-0 shadow-sm p-4 mb-4" style="border-radius: 16px;">
                <h4 class="fw-bold mb-3"><i class="bi bi-journal-text text-primary me-2"></i>Historique & Valeur Patrimoniale</h4>
                <p class="text-muted leading-relaxed mb-0">${site.historiquePatrimoine || 'Ce lieu est un témoin remarquable des coutumes, de la mémoire et de l\'architecture traditionnelle du peuple de Casamance.'}</p>
            </div>

            <!-- Circuits et visites guidées associées -->
            <div class="row g-4 mb-5">
                <div class="col-md-6">
                    <div class="card h-100 border-0 shadow-sm p-3" style="border-radius: 16px;">
                        <h5 class="fw-bold mb-3 text-success"><i class="bi bi-signpost-split me-2"></i>Circuits incluant ce site</h5>
                        ${relatedCircuits.length > 0 ? `
                            <div class="list-group list-group-flush">
                                ${relatedCircuits.map(c => `
                                    <div class="list-group-item px-0 py-2 d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="fw-bold mb-0">${c.nomCircuit}</h6>
                                            <small class="text-muted">${c.distanceTotale} km - ${c.difficulte}</small>
                                        </div>
                                        <button class="btn btn-sm btn-outline-success rounded-pill" onclick="openBookingModal('CIRCUIT', ${c.id}, '${c.nomCircuit.replace(/'/g, "\\'")}')">Réserver</button>
                                    </div>
                                `).join('')}
                            </div>
                        ` : `<p class="text-muted small">Aucun circuit groupé pour l'instant.</p>`}
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card h-100 border-0 shadow-sm p-3" style="border-radius: 16px;">
                        <h5 class="fw-bold mb-3 text-primary"><i class="bi bi-calendar2-check me-2"></i>Visites guidées programmées</h5>
                        ${relatedEvents.length > 0 ? `
                            <div class="list-group list-group-flush">
                                ${relatedEvents.map(e => `
                                    <div class="list-group-item px-0 py-2 d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="fw-bold mb-0">${e.titre}</h6>
                                            <small class="text-muted">Guide : ${e.guideNom || 'Guide agréé'} | ${e.placesMax} places</small>
                                        </div>
                                        <button class="btn btn-sm btn-outline-primary rounded-pill" onclick="openBookingModal('EVENEMENT', ${e.id}, '${e.titre.replace(/'/g, "\\'")}')">Réserver</button>
                                    </div>
                                `).join('')}
                            </div>
                        ` : `<p class="text-muted small">Aucune visite programmée pour cette semaine.</p>`}
                    </div>
                </div>
            </div>

            <!-- Avis et commentaires des visiteurs (Slide 46 & 49) -->
            <div class="card border-0 shadow-sm p-4" style="border-radius: 16px;">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h4 class="fw-bold mb-0"><i class="bi bi-chat-heart text-danger me-2"></i>Avis des Visiteurs</h4>
                        <div class="star-rating mt-1">
                            ${'★'.repeat(Math.round(avisData.noteMoyenne || 5))}${'☆'.repeat(5 - Math.round(avisData.noteMoyenne || 5))}
                            <span class="text-dark fw-bold ms-2">${avisData.noteMoyenne || 5.0} / 5</span>
                        </div>
                    </div>
                    ${AppState.currentUser ? `
                        <button class="btn btn-outline-primary rounded-pill px-3" onclick="openReviewModal(${id}, null, '${site.nomPatrimoine.replace(/'/g, "\\'")}')">
                            <i class="bi bi-pencil-square me-1"></i>Donner mon avis
                        </button>
                    ` : `
                        <button class="btn btn-outline-secondary btn-sm rounded-pill" onclick="navigateTo('login')">
                            Connectez-vous pour laisser un avis
                        </button>
                    `}
                </div>

                <div class="list-group list-group-flush">
                    ${(avisData.avis || []).length > 0 ? (avisData.avis || []).map(a => `
                        <div class="list-group-item px-0 py-3">
                            <div class="d-flex justify-content-between">
                                <h6 class="fw-bold mb-1">${a.touristeNom || 'Visiteur'}</h6>
                                <div class="star-rating small">${'★'.repeat(a.note)}${'☆'.repeat(5 - a.note)}</div>
                            </div>
                            <p class="text-muted small mb-2">${a.commentaire}</p>
                            ${a.reponseGuide ? `
                                <div class="bg-light p-3 rounded-3 mt-2 ms-4 border-start border-primary border-3">
                                    <small class="fw-bold text-primary d-block"><i class="bi bi-reply-fill me-1"></i>Réponse du guide :</small>
                                    <span class="small text-muted">${a.reponseGuide}</span>
                                </div>
                            ` : ''}
                            ${AppState.currentUser && AppState.currentUser.role === 'GUIDE' && !a.reponseGuide ? `
                                <button class="btn btn-sm btn-link text-primary p-0 mt-2" onclick="openReplyModal(${a.id})">
                                    <i class="bi bi-reply"></i> Répondre à ce commentaire
                                </button>
                            ` : ''}
                        </div>
                    `).join('') : `<p class="text-muted text-center py-3">Soyez le premier à partager votre expérience sur ce site patrimonial !</p>`}
                </div>
            </div>
        </div>
    `;

    const main = document.querySelector('.main-content');
    if (main) main.innerHTML = contentHtml;
    return contentHtml;
}

// --------------------------------------------------------------------------
// VUE 4 : CIRCUITS TOURISTIQUES (Slide 46)
// --------------------------------------------------------------------------
function renderCircuitsView() {
    return `
        <div class="container py-4">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#home" onclick="navigateTo('home')">Accueil</a></li>
                    <li class="breadcrumb-item active">Circuits Touristiques</li>
                </ol>
            </nav>

            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="fw-bold mb-1">Circuits Touristiques Orchestrés</h2>
                    <p class="text-muted mb-0">Itinéraires multi-étapes reliant les trésors de Basse-Casamance</p>
                </div>
            </div>

            <div class="row g-4">
                ${AppState.circuits.map(c => `
                    <div class="col-lg-6">
                        <div class="card border-0 shadow-sm h-100 p-4 bg-white" style="border-radius: 16px;">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <div>
                                    <span class="badge bg-secondary mb-2">${c.codeCircuit}</span>
                                    <h4 class="fw-bold mb-1">${c.nomCircuit}</h4>
                                </div>
                                <span class="badge bg-${c.difficulte === 'FACILE' ? 'success' : c.difficulte === 'MOYEN' ? 'warning text-dark' : 'danger'} px-3 py-2 rounded-pill">
                                    ${c.difficulte}
                                </span>
                            </div>

                            <p class="text-muted mb-3">${c.descriptionCircuit}</p>

                            <div class="d-flex gap-3 mb-3 p-3 bg-light rounded-3 text-center">
                                <div class="flex-fill">
                                    <small class="text-muted d-block">Durée estimée</small>
                                    <strong>${Math.round(c.dureeTotale / 60)} heures</strong>
                                </div>
                                <div class="flex-fill border-start">
                                    <small class="text-muted d-block">Distance totale</small>
                                    <strong>${c.distanceTotale} km</strong>
                                </div>
                                <div class="flex-fill border-start">
                                    <small class="text-muted d-block">Capacité max</small>
                                    <strong>${c.capaciteMax} personnes</strong>
                                </div>
                            </div>

                            <h6 class="fw-bold mb-2 text-primary"><i class="bi bi-list-ol me-1"></i>Étapes du Circuit (Patrimoines liés) :</h6>
                            <ul class="list-group list-group-flush mb-4">
                                ${(c.etapes || []).map(e => `
                                    <li class="list-group-item px-0 py-2 d-flex justify-content-between align-items-center bg-transparent">
                                        <div>
                                            <span class="badge bg-primary rounded-circle me-2">${e.position}</span>
                                            <strong>${e.patrimoine ? e.patrimoine.nomPatrimoine : 'Patrimoine #' + e.patrimoineId}</strong>
                                            ${e.patrimoine && e.patrimoine.ville ? `<small class="text-muted">(${e.patrimoine.ville})</small>` : ''}
                                        </div>
                                        <small class="text-muted">${e.dureeEstime} min</small>
                                    </li>
                                `).join('')}
                            </ul>

                            <div class="mt-auto pt-3 border-top d-flex justify-content-between align-items-center">
                                <span class="text-success fw-bold"><i class="bi bi-check2-circle me-1"></i>Guide certifié inclus</span>
                                <button class="btn btn-warning px-4 rounded-pill fw-bold text-dark"
                                        onclick="openBookingModal('CIRCUIT', ${c.id}, '${c.nomCircuit.replace(/'/g, "\\'")}')">
                                    <i class="bi bi-calendar-check me-1"></i>Réserver
                                </button>
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

// --------------------------------------------------------------------------
// VUE 5 : EVENEMENTS & VISITES GUIDEES (Slide 46)
// --------------------------------------------------------------------------
function renderEvenementsView() {
    return `
        <div class="container py-4">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#home" onclick="navigateTo('home')">Accueil</a></li>
                    <li class="breadcrumb-item active">Visites & Événements</li>
                </ol>
            </nav>

            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="fw-bold mb-1">Visites Guidées, Ateliers & Expositions</h2>
                    <p class="text-muted mb-0">Planifiées et encadrées par des professionnels du patrimoine</p>
                </div>
            </div>

            <div class="row g-4">
                ${AppState.evenements.map(e => `
                    <div class="col-lg-6">
                        <div class="card border-0 shadow-sm p-4 bg-white h-100" style="border-radius: 16px;">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <span class="badge bg-info text-dark px-3 py-2 rounded-pill">${e.type}</span>
                                <span class="badge bg-light text-muted border">${e.placesMax} places max</span>
                            </div>

                            <h4 class="fw-bold mb-2">${e.titre}</h4>
                            <p class="text-muted small mb-3">${e.description}</p>

                            <div class="p-3 bg-light rounded-3 mb-3">
                                <div class="d-flex align-items-center mb-2">
                                    <i class="bi bi-calendar3 text-primary me-2 fs-5"></i>
                                    <div>
                                        <small class="text-muted d-block">Date et Heure</small>
                                        <strong>${new Date(e.dateDebut).toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</strong>
                                        à ${new Date(e.dateDebut).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                                    </div>
                                </div>
                                <div class="d-flex align-items-center mb-2">
                                    <i class="bi bi-geo-alt text-danger me-2 fs-5"></i>
                                    <div>
                                        <small class="text-muted d-block">Lieu de rendez-vous</small>
                                        <strong>${e.lieu}</strong>
                                    </div>
                                </div>
                                ${e.guideNom ? `
                                    <div class="d-flex align-items-center">
                                        <i class="bi bi-person-badge text-success me-2 fs-5"></i>
                                        <div>
                                            <small class="text-muted d-block">Guide assigné</small>
                                            <strong class="text-success">${e.guideNom}</strong>
                                        </div>
                                    </div>
                                ` : ''}
                            </div>

                            <div class="mt-auto d-flex justify-content-between align-items-center pt-3 border-top">
                                <span class="text-muted small"><i class="bi bi-ticket-perforated me-1"></i>Ticket avec QR Code</span>
                                <button class="btn btn-primary px-4 rounded-pill"
                                        onclick="openBookingModal('EVENEMENT', ${e.id}, '${e.titre.replace(/'/g, "\\'")}')">
                                    Réserver ma place
                                </button>
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

// --------------------------------------------------------------------------
// VUE 6 : ESPACE TOURISTE - MES RESERVATIONS & QR CODES (Slide 46 & 49)
// --------------------------------------------------------------------------
async function renderTouristeReservationsView() {
    const u = AppState.currentUser;
    if (!u) {
        return `
            <div class="container py-5 text-center">
                <i class="bi bi-lock text-warning display-3 mb-3 d-block"></i>
                <h3>Connexion Requise</h3>
                <p class="text-muted">Veuillez vous connecter pour accéder à vos réservations et vos billets avec QR Code.</p>
                <button class="btn btn-primary" onclick="switchDemoUser('TOURIST')">Se connecter comme Awa Diop (Touriste)</button>
            </div>
        `;
    }

    // Récupérer les réservations du touriste
    let reservations = await apiGet(`${getApiUrl('reservations')}?touristeId=${u.id}`, null);
    if (!reservations || reservations.length === 0) {
        reservations = SEED_FALLBACK.reservations;
    }
    AppState.reservations = reservations;

    return `
        <div class="container py-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="fw-bold mb-1"><i class="bi bi-ticket-detailed text-primary me-2"></i>Mes Billets & Réservations</h2>
                    <p class="text-muted mb-0">Bienvenue ${u.prenom} ${u.nom} • Retrouvez vos billets horodatés et QR codes de validation</p>
                </div>
                <button class="btn btn-outline-primary btn-sm rounded-pill" onclick="navigateTo('sites')">
                    <i class="bi bi-plus-lg me-1"></i>Nouvelle Réservation
                </button>
            </div>

            <div class="row g-4">
                ${reservations.map(r => {
                    const statusClass = r.statut === 'CONFIRMEE' ? 'bg-success' : r.statut === 'EN_ATTENTE' ? 'bg-warning text-dark' : 'bg-danger';
                    return `
                        <div class="col-md-6 col-lg-6">
                            <div class="ticket-card shadow-sm h-100">
                                <div class="ticket-header d-flex justify-content-between align-items-center">
                                    <div>
                                        <small class="text-light text-uppercase fw-semibold d-block">Billet de Visite • Casamance</small>
                                        <h5 class="fw-bold mb-0 text-white">${r.typeReservation === 'CIRCUIT' ? 'Circuit Touristique' : 'Visite Guidée'} #${r.referenceId}</h5>
                                    </div>
                                    <span class="badge ${statusClass} px-3 py-2 rounded-pill shadow-sm">${r.statut}</span>
                                </div>
                                <div class="ticket-body">
                                    <div class="row align-items-center">
                                        <div class="col-sm-7">
                                            <div class="mb-2">
                                                <small class="text-muted d-block">Titulaire du billet</small>
                                                <strong>${r.nomClient}</strong> (${r.email})
                                            </div>
                                            <div class="mb-2">
                                                <small class="text-muted d-block">Date de visite</small>
                                                <strong><i class="bi bi-calendar3 me-1 text-primary"></i>${r.dateVisite}</strong>
                                            </div>
                                            <div class="mb-2">
                                                <small class="text-muted d-block">Nombre de places réservées</small>
                                                <strong><i class="bi bi-person-check me-1 text-success"></i>${r.nombrePlaces} personne(s)</strong>
                                            </div>
                                            <div class="mb-3">
                                                <small class="text-muted d-block">Référence Hash</small>
                                                <code class="fw-bold text-dark">${r.qrCodeHash || 'TKT-992B144'}</code>
                                            </div>
                                        </div>
                                        <div class="col-sm-5 text-center border-start py-2">
                                            <div class="qr-container mb-2">
                                                ${generateQrCodeSvg(r.qrCodeHash || 'TKT-992B144')}
                                            </div>
                                            <small class="text-muted d-block">Scanner au point d'accès</small>
                                        </div>
                                    </div>

                                    <div class="pt-3 border-top mt-3 d-flex flex-wrap gap-2 justify-content-between align-items-center">
                                        <button class="btn btn-outline-primary btn-sm rounded-pill"
                                                onclick="openTicketModal(${JSON.stringify(r).replace(/"/g, '&quot;')})">
                                            <i class="bi bi-qr-code me-1"></i>Plein écran / Imprimer
                                        </button>

                                        <div class="d-flex gap-2">
                                            ${r.statut !== 'ANNULEE' ? `
                                                <button class="btn btn-outline-warning btn-sm rounded-pill text-dark"
                                                        onclick="openReviewModal(1, 2, 'Visite #${r.referenceId}')">
                                                    <i class="bi bi-star-fill text-warning me-1"></i>Laisser un avis
                                                </button>
                                                <button class="btn btn-outline-danger btn-sm rounded-pill" onclick="cancelReservation(${r.id})">
                                                    Annuler
                                                </button>
                                            ` : `<span class="badge bg-secondary">Réservation clôturée</span>`}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
                }).join('')}
            </div>
        </div>
    `;
}

async function cancelReservation(resId) {
    if (!confirm("Êtes-vous sûr de vouloir annuler cette réservation ? Vos places seront remises à disposition.")) return;
    await apiPut(`${getApiUrl('reservations')}/${resId}/annuler`);
    showToast("Réservation annulée avec succès.", "info");
    renderTouristeReservationsView().then(html => {
        const main = document.querySelector('.main-content');
        if (main) main.innerHTML = html;
    });
}

// --------------------------------------------------------------------------
// VUE 7 : ESPACE GUIDE (Slide 47 & 48)
// --------------------------------------------------------------------------
async function renderGuideView() {
    const u = AppState.currentUser;
    if (!u || u.role !== 'GUIDE') {
        return `
            <div class="container py-5 text-center">
                <i class="bi bi-shield-lock text-danger display-3 mb-3 d-block"></i>
                <h3>Accès réservé aux Guides Touristiques</h3>
                <p class="text-muted">Connectez-vous avec un compte guide pour gérer vos visites et consulter vos avis.</p>
                <div class="d-flex justify-content-center gap-2">
                    <button class="btn btn-success" onclick="switchDemoUser('GUIDE_VERIFIE')">Guide Vérifié (Amadou)</button>
                    <button class="btn btn-warning" onclick="switchDemoUser('GUIDE_ATTENTE')">Guide En Attente (Fatou)</button>
                </div>
            </div>
        `;
    }

    // Charger les détails du guide
    let guideDetails = u.guideDetails;
    if (!guideDetails) {
        const gd = await apiGet(`${getApiUrl('guides')}/user/${u.id}`, null);
        guideDetails = gd || SEED_FALLBACK.guides[0];
    }

    // Charger les visites guidées de ce guide (Agenda personnel) (Slide 48)
    const myEvents = AppState.evenements.filter(e => e.guideId === u.id || u.id === 2);

    // Charger les avis reçus par le guide (Slide 48)
    let avisData = await apiGet(`${getApiUrl('avis')}/guide/${u.id}`, null);
    if (!avisData) {
        avisData = {
            avis: SEED_FALLBACK.avis,
            noteMoyenne: guideDetails.noteMoyenne || 4.9,
            totalAvis: 1
        };
    }

    return `
        <div class="container py-4">
            <div class="card border-0 shadow-sm p-4 mb-4 bg-white" style="border-radius: 16px;">
                <div class="d-flex flex-wrap justify-content-between align-items-center">
                    <div class="d-flex align-items-center gap-3">
                        <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center fs-2 fw-bold" style="width: 70px; height: 70px;">
                            ${u.prenom[0]}${u.nom[0]}
                        </div>
                        <div>
                            <h3 class="fw-bold mb-1">${u.prenom} ${u.nom}</h3>
                            <span class="text-muted"><i class="bi bi-envelope me-1"></i>${u.email}</span>
                            <span class="mx-2">•</span>
                            <span class="text-muted"><i class="bi bi-card-text me-1"></i>Licence : <strong>${guideDetails.numeroLicence || 'N/A'}</strong></span>
                        </div>
                    </div>

                    <div class="mt-3 mt-md-0 text-md-end">
                        ${guideDetails.estVerifie ? `
                            <span class="badge bg-success px-3 py-2 rounded-pill fs-6">
                                <i class="bi bi-patch-check-fill me-1"></i>Compte Guide Vérifié & Agréé
                            </span>
                        ` : `
                            <span class="badge bg-warning text-dark px-3 py-2 rounded-pill fs-6">
                                <i class="bi bi-hourglass-split me-1"></i>En attente de validation par le conservateur
                            </span>
                        `}
                        <div class="star-rating mt-2">
                            ${'★'.repeat(Math.round(guideDetails.noteMoyenne || 5))}
                            <strong class="text-dark ms-1">${guideDetails.noteMoyenne || 5.0} / 5</strong>
                        </div>
                    </div>
                </div>

                ${!guideDetails.estVerifie ? `
                    <div class="alert alert-warning mt-3 mb-0" role="alert">
                        <i class="bi bi-info-circle-fill me-2"></i>
                        Votre compte guide a été transmis au conservateur du patrimoine. Vous recevrez une validation dès contrôle de votre licence professionnelle.
                    </div>
                ` : ''}
            </div>

            <!-- Onglets Guide (Slide 48) -->
            <ul class="nav nav-pills mb-4" id="guideTabs">
                <li class="nav-item">
                    <button class="nav-link active rounded-pill px-4" data-bs-toggle="pill" data-bs-target="#tab-agenda">
                        <i class="bi bi-calendar-day me-1"></i>Agenda personnel des visites
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link rounded-pill px-4" data-bs-toggle="pill" data-bs-target="#tab-avis">
                        <i class="bi bi-chat-dots me-1"></i>Avis reçus & Réponses (${avisData.totalAvis || 0})
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link rounded-pill px-4" data-bs-toggle="pill" data-bs-target="#tab-profil">
                        <i class="bi bi-person-lines-fill me-1"></i>Profil professionnel
                    </button>
                </li>
            </ul>

            <div class="tab-content">
                <!-- 1. Agenda du jour (Slide 48) -->
                <div class="tab-pane fade show active" id="tab-agenda">
                    <div class="card border-0 shadow-sm p-4 bg-white" style="border-radius: 16px;">
                        <h4 class="fw-bold mb-3"><i class="bi bi-clock-history text-primary me-2"></i>Visites Guidées Assignées</h4>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <thead class="table-light">
                                    <tr>
                                        <th>Date & Heure</th>
                                        <th>Visite / Événement</th>
                                        <th>Lieu de rassemblement</th>
                                        <th>Places réservées</th>
                                        <th>Statut</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${myEvents.map(ev => `
                                        <tr>
                                            <td>
                                                <strong>${new Date(ev.dateDebut).toLocaleDateString('fr-FR')}</strong><br>
                                                <small class="text-muted">${new Date(ev.dateDebut).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</small>
                                            </td>
                                            <td>
                                                <h6 class="fw-bold mb-0">${ev.titre}</h6>
                                                <small class="text-muted">${ev.type}</small>
                                            </td>
                                            <td><i class="bi bi-geo-alt text-danger me-1"></i>${ev.lieu}</td>
                                            <td><span class="badge bg-primary rounded-pill px-3">${ev.placesMax} max</span></td>
                                            <td><span class="badge bg-success">Programmée</span></td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- 2. Avis reçus et réponses (Slide 48) -->
                <div class="tab-pane fade" id="tab-avis">
                    <div class="card border-0 shadow-sm p-4 bg-white" style="border-radius: 16px;">
                        <h4 class="fw-bold mb-3"><i class="bi bi-chat-quote text-success me-2"></i>Commentaires des Visiteurs</h4>
                        <div class="list-group list-group-flush">
                            ${(avisData.avis || []).map(a => `
                                <div class="list-group-item px-0 py-3">
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <h6 class="fw-bold mb-0">${a.touristeNom || 'Touriste'}</h6>
                                        <div class="star-rating small">${'★'.repeat(a.note)}${'☆'.repeat(5 - a.note)}</div>
                                    </div>
                                    <p class="text-muted small mb-2">${a.commentaire}</p>

                                    ${a.reponseGuide ? `
                                        <div class="p-3 bg-light rounded-3 ms-4 border-start border-success border-3">
                                            <strong class="text-success small d-block"><i class="bi bi-reply-fill"></i> Votre réponse :</strong>
                                            <small class="text-muted">${a.reponseGuide}</small>
                                        </div>
                                    ` : `
                                        <div class="d-flex gap-2 mt-2">
                                            <button class="btn btn-sm btn-outline-primary rounded-pill" onclick="openReplyModal(${a.id})">
                                                <i class="bi bi-reply"></i> Répondre
                                            </button>
                                            <button class="btn btn-sm btn-outline-danger rounded-pill" onclick="openSignalementModal(${a.id})">
                                                <i class="bi bi-flag"></i> Signaler abus
                                            </button>
                                        </div>
                                    `}
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>

                <!-- 3. Profil professionnel (Slide 48) -->
                <div class="tab-pane fade" id="tab-profil">
                    <div class="card border-0 shadow-sm p-4 bg-white" style="border-radius: 16px;">
                        <h4 class="fw-bold mb-3"><i class="bi bi-person-gear text-primary me-2"></i>Mettre à jour mon profil</h4>
                        <form onsubmit="handleUpdateGuideProfile(event, ${u.id})">
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Numéro de Licence Professionnelle</label>
                                <input type="text" id="guideLicenceInput" class="form-control" value="${guideDetails.numeroLicence || ''}" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Biographie & Spécialités Culturelles</label>
                                <textarea id="guideBioInput" class="form-control" rows="4" required>${guideDetails.biographie || ''}</textarea>
                            </div>
                            <button type="submit" class="btn btn-primary rounded-pill px-4">
                                <i class="bi bi-save me-1"></i>Enregistrer les modifications
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    `;
}

async function handleUpdateGuideProfile(event, userId) {
    event.preventDefault();
    const licence = document.getElementById('guideLicenceInput').value;
    const bio = document.getElementById('guideBioInput').value;
    await apiPut(`${getApiUrl('guides')}/user/${userId}`, { numeroLicence: licence, biographie: bio });
    showToast("Profil professionnel mis à jour !", "success");
}

// --------------------------------------------------------------------------
// VUE 8 : ESPACE CONSERVATEUR / ADMIN (Slide 47 & 50)
// --------------------------------------------------------------------------
async function renderConservateurView() {
    const u = AppState.currentUser;
    if (!u || u.role !== 'ADMIN') {
        return `
            <div class="container py-5 text-center">
                <i class="bi bi-shield-x text-danger display-3 mb-3 d-block"></i>
                <h3>Accès Restreint au Conservateur</h3>
                <p class="text-muted">Cet espace administrateur est réservé à la gestion des patrimoines, validation des guides et modération.</p>
                <button class="btn btn-danger" onclick="switchDemoUser('ADMIN')">Se connecter comme Conservateur</button>
            </div>
        `;
    }

    // Charger les guides et signalements
    let guides = await apiGet(`${getApiUrl('guides')}`, 'guides') || SEED_FALLBACK.guides;
    let signalements = await apiGet(`${getApiUrl('signalements')}`, 'signalements') || SEED_FALLBACK.signalements;

    const pendingGuides = guides.filter(g => !g.estVerifie);
    const pendingSignalements = signalements.filter(s => s.statut === 'EN_ATTENTE');

    return `
        <div class="container py-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="fw-bold mb-1"><i class="bi bi-shield-shaded text-danger me-2"></i>Administration du Patrimoine</h2>
                    <p class="text-muted mb-0">Conservateur en chef : ${u.prenom} ${u.nom} • Contrôle global de la plateforme</p>
                </div>
                <button class="btn btn-success rounded-pill px-3" onclick="openAddSiteModal()">
                    <i class="bi bi-plus-lg me-1"></i>Nouveau Site
                </button>
            </div>

            <!-- KPIs -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <div class="card border-0 shadow-sm p-3 bg-white text-center" style="border-radius: 12px;">
                        <h3 class="fw-bold text-primary mb-0">${AppState.sites.length}</h3>
                        <small class="text-muted">Sites & Monuments</small>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="card border-0 shadow-sm p-3 bg-white text-center" style="border-radius: 12px;">
                        <h3 class="fw-bold text-success mb-0">${AppState.circuits.length}</h3>
                        <small class="text-muted">Circuits Actifs</small>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="card border-0 shadow-sm p-3 bg-white text-center" style="border-radius: 12px;">
                        <h3 class="fw-bold text-warning mb-0">${pendingGuides.length}</h3>
                        <small class="text-muted">Guides en attente</small>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="card border-0 shadow-sm p-3 bg-white text-center" style="border-radius: 12px;">
                        <h3 class="fw-bold text-danger mb-0">${pendingSignalements.length}</h3>
                        <small class="text-muted">Signalements à modérer</small>
                    </div>
                </div>
            </div>

            <!-- Onglets de gestion (Slide 47) -->
            <ul class="nav nav-tabs mb-4">
                <li class="nav-item">
                    <button class="nav-link active fw-bold" data-bs-toggle="tab" data-bs-target="#admin-sites">
                        <i class="bi bi-bank me-1"></i>Gestion des Sites (${AppState.sites.length})
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link fw-bold" data-bs-toggle="tab" data-bs-target="#admin-guides">
                        <i class="bi bi-person-check me-1"></i>Validation Guides (${pendingGuides.length})
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link fw-bold" data-bs-toggle="tab" data-bs-target="#admin-moderation">
                        <i class="bi bi-shield-exclamation me-1"></i>Modération Avis (${pendingSignalements.length})
                    </button>
                </li>
            </ul>

            <div class="tab-content">
                <!-- 1. CRUD SITES (Slide 47) -->
                <div class="tab-pane fade show active" id="admin-sites">
                    <div class="card border-0 shadow-sm p-4 bg-white" style="border-radius: 16px;">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <thead class="table-light">
                                    <tr>
                                        <th>Code</th>
                                        <th>Nom du Site</th>
                                        <th>Ville</th>
                                        <th>Type</th>
                                        <th>Capacité</th>
                                        <th>Horaires</th>
                                        <th class="text-end">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${AppState.sites.map(s => `
                                        <tr>
                                            <td><code>${s.codePatrimoine}</code></td>
                                            <td><strong>${s.nomPatrimoine}</strong></td>
                                            <td>${s.ville}</td>
                                            <td><span class="badge bg-secondary">${s.typePatrimoine}</span></td>
                                            <td>${s.capacitePatrimoine} pers.</td>
                                            <td><small class="text-muted">${s.horaires}</small></td>
                                            <td class="text-end">
                                                <button class="btn btn-sm btn-outline-primary me-1" onclick="openEditSiteModal(${s.id})">
                                                    <i class="bi bi-pencil"></i>
                                                </button>
                                                <button class="btn btn-sm btn-outline-danger" onclick="deleteSite(${s.id})">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- 2. VALIDATION GUIDES (Slide 47) -->
                <div class="tab-pane fade" id="admin-guides">
                    <div class="card border-0 shadow-sm p-4 bg-white" style="border-radius: 16px;">
                        <h5 class="fw-bold mb-3"><i class="bi bi-award text-warning me-2"></i>Demandes de Validation de Guides</h5>
                        ${pendingGuides.length > 0 ? `
                            <div class="table-responsive">
                                <table class="table table-hover align-middle">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Nom du Guide</th>
                                            <th>Licence Pro</th>
                                            <th>Biographie & Compétences</th>
                                            <th class="text-end">Validation</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${pendingGuides.map(g => `
                                            <tr>
                                                <td>
                                                    <strong>${g.nomComplet}</strong><br>
                                                    <small class="text-muted">${g.email}</small>
                                                </td>
                                                <td><span class="badge bg-light text-dark border">${g.numeroLicence}</span></td>
                                                <td style="max-width: 350px;"><small class="text-muted">${g.biographie}</small></td>
                                                <td class="text-end">
                                                    <button class="btn btn-sm btn-success rounded-pill me-1" onclick="validerGuideCompte(${g.id})">
                                                        <i class="bi bi-check-lg me-1"></i>Valider
                                                    </button>
                                                    <button class="btn btn-sm btn-outline-danger rounded-pill" onclick="refuserGuideCompte(${g.id})">
                                                        Refuser
                                                    </button>
                                                </td>
                                            </tr>
                                        `).join('')}
                                    </tbody>
                                </table>
                            </div>
                        ` : `<div class="p-4 text-center text-muted">Toutes les demandes de guides ont été validées !</div>`}
                    </div>
                </div>

                <!-- 3. MODERATION AVIS SIGNALÉS (Slide 46/47/48) -->
                <div class="tab-pane fade" id="admin-moderation">
                    <div class="card border-0 shadow-sm p-4 bg-white" style="border-radius: 16px;">
                        <h5 class="fw-bold mb-3"><i class="bi bi-flag-fill text-danger me-2"></i>Avis Signalés pour Abus</h5>
                        ${pendingSignalements.length > 0 ? `
                            <div class="table-responsive">
                                <table class="table table-hover align-middle">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Signalé par</th>
                                            <th>Avis ID</th>
                                            <th>Motif du signalement</th>
                                            <th>Date</th>
                                            <th class="text-end">Décision du conservateur</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${pendingSignalements.map(s => `
                                            <tr>
                                                <td><strong>${s.signaleurNom}</strong></td>
                                                <td><span class="badge bg-secondary">#${s.avisId}</span></td>
                                                <td class="text-danger"><em>${s.motif}</em></td>
                                                <td><small class="text-muted">${new Date(s.dateSignalement).toLocaleDateString('fr-FR')}</small></td>
                                                <td class="text-end">
                                                    <button class="btn btn-sm btn-danger rounded-pill me-1" onclick="traiterSignalementDecision(${s.id}, 'RESOLU')">
                                                        <i class="bi bi-trash me-1"></i>Supprimer l'avis
                                                    </button>
                                                    <button class="btn btn-sm btn-outline-secondary rounded-pill" onclick="traiterSignalementDecision(${s.id}, 'REJETE')">
                                                        Rejeter
                                                    </button>
                                                </td>
                                            </tr>
                                        `).join('')}
                                    </tbody>
                                </table>
                            </div>
                        ` : `<div class="p-4 text-center text-muted">Aucun avis signalé pour le moment. Tout est en ordre !</div>`}
                    </div>
                </div>
            </div>
        </div>
    `;
}

async function validerGuideCompte(guideId) {
    await apiPut(`${getApiUrl('guides')}/${guideId}/valider`);
    showToast("Le compte guide a été validé avec succès !", "success");
    renderApp();
}

async function refuserGuideCompte(guideId) {
    await apiPut(`${getApiUrl('guides')}/${guideId}/refuser`);
    showToast("Demande de guide refusée.", "warning");
    renderApp();
}

async function traiterSignalementDecision(sigId, decision) {
    await apiPut(`${getApiUrl('signalements')}/${sigId}/traiter?statut=${decision}`);
    showToast(`Signalement ${decision === 'RESOLU' ? 'résolu et avis supprimé' : 'rejeté'}.`, "info");
    renderApp();
}

async function deleteSite(siteId) {
    if (!confirm("Voulez-vous vraiment supprimer ce site du patrimoine ?")) return;
    await apiDelete(`${getApiUrl('patrimoines')}/${siteId}`);
    AppState.sites = AppState.sites.filter(s => s.id !== siteId);
    showToast("Site supprimé du catalogue.", "info");
    renderApp();
}

// --------------------------------------------------------------------------
// VUES AUTHENTIFICATION (LOGIN & REGISTER)
// --------------------------------------------------------------------------
function renderLoginView() {
    return `
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-md-6 col-lg-5">
                    <div class="card border-0 shadow-lg p-4 p-md-5 bg-white" style="border-radius: 20px;">
                        <div class="text-center mb-4">
                            <i class="bi bi-bank2 text-warning display-4"></i>
                            <h3 class="fw-bold mt-2">Connexion</h3>
                            <p class="text-muted small">Accédez à votre espace Touriste, Guide ou Conservateur</p>
                        </div>

                        <form onsubmit="handleLoginSubmit(event)">
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Adresse Email</label>
                                <input type="email" id="loginEmail" class="form-control" placeholder="nom@exemple.com" required value="awa.diop@mail.com">
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Mot de passe</label>
                                <input type="password" id="loginPassword" class="form-control" placeholder="••••••••" required value="touriste123">
                            </div>
                            <button type="submit" class="btn btn-warning w-100 fw-bold py-2 rounded-pill mt-2">
                                Se connecter
                            </button>
                        </form>

                        <div class="mt-4 pt-3 border-top text-center">
                            <span class="text-muted small">Vous n'avez pas de compte ? </span>
                            <a href="#register" class="fw-bold text-decoration-none" onclick="navigateTo('register')">Créer un compte</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function renderRegisterView() {
    return `
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-md-7 col-lg-6">
                    <div class="card border-0 shadow-lg p-4 p-md-5 bg-white" style="border-radius: 20px;">
                        <div class="text-center mb-4">
                            <i class="bi bi-person-plus text-primary display-4"></i>
                            <h3 class="fw-bold mt-2">Création de Compte</h3>
                            <p class="text-muted small">Rejoignez la plateforme du patrimoine touristique</p>
                        </div>

                        <form onsubmit="handleRegisterSubmit(event)">
                            <div class="row g-2 mb-3">
                                <div class="col-6">
                                    <label class="form-label fw-semibold">Prénom</label>
                                    <input type="text" id="regPrenom" class="form-control" required placeholder="Ex: Moussa">
                                </div>
                                <div class="col-6">
                                    <label class="form-label fw-semibold">Nom</label>
                                    <input type="text" id="regNom" class="form-control" required placeholder="Ex: Sarr">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Adresse Email</label>
                                <input type="email" id="regEmail" class="form-control" required placeholder="moussa@mail.com">
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Mot de passe</label>
                                <input type="password" id="regPassword" class="form-control" required placeholder="Minimum 6 caractères">
                            </div>

                            <!-- Choix du Rôle (Slide 48 & 49) -->
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Vous vous inscrivez en tant que :</label>
                                <div class="d-flex gap-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="regRole" id="roleTourist" value="TOURIST" checked onchange="toggleGuideFields()">
                                        <label class="form-check-label fw-semibold" for="roleTourist">Touriste / Visiteur</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="regRole" id="roleGuide" value="GUIDE" onchange="toggleGuideFields()">
                                        <label class="form-check-label fw-semibold" for="roleGuide">Guide Touristique</label>
                                    </div>
                                </div>
                            </div>

                            <!-- Champs spécifiques pour le Guide (Slide 48) -->
                            <div id="guideSpecificFields" style="display: none;" class="p-3 bg-light rounded-3 mb-3 border">
                                <h6 class="fw-bold text-success mb-2"><i class="bi bi-award me-1"></i>Informations professionnelles Guide</h6>
                                <div class="mb-2">
                                    <label class="form-label small fw-semibold">Numéro de Licence Guide</label>
                                    <input type="text" id="regLicence" class="form-control form-control-sm" placeholder="Ex: GUIDE-CAS-2026-0200">
                                </div>
                                <div>
                                    <label class="form-label small fw-semibold">Biographie & Spécialités</label>
                                    <textarea id="regBio" class="form-control form-control-sm" rows="3" placeholder="Présentez votre expérience et vos zones de visite..."></textarea>
                                </div>
                                <small class="text-muted d-block mt-2">Votre compte sera soumis à la validation du conservateur.</small>
                            </div>

                            <button type="submit" class="btn btn-primary w-100 fw-bold py-2 rounded-pill mt-3">
                                Confirmer l'inscription
                            </button>
                        </form>

                        <div class="mt-4 pt-3 border-top text-center">
                            <span class="text-muted small">Déjà inscrit ? </span>
                            <a href="#login" class="fw-bold text-decoration-none" onclick="navigateTo('login')">Se connecter</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function toggleGuideFields() {
    const isGuide = document.getElementById('roleGuide')?.checked;
    const fields = document.getElementById('guideSpecificFields');
    if (fields) fields.style.display = isGuide ? 'block' : 'none';
}

async function handleLoginSubmit(event) {
    event.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const motDePasse = document.getElementById('loginPassword').value;

    const res = await apiPost(`${getApiUrl('auth')}/login`, { email, motDePasse }, null);
    if (res && res.role) {
        AppState.currentUser = res;
        localStorage.setItem('patrimoine_user', JSON.stringify(res));
        showToast(`Bienvenue ${res.prenom} !`, "success");
        if (res.role === 'ADMIN') navigateTo('conservateur');
        else if (res.role === 'GUIDE') navigateTo('guide');
        else navigateTo('mes-reservations');
    } else {
        showToast("Identifiants incorrects. Veuillez réessayer.", "danger");
    }
}

async function handleRegisterSubmit(event) {
    event.preventDefault();
    const role = document.getElementById('roleGuide')?.checked ? 'GUIDE' : 'TOURIST';
    const body = {
        nom: document.getElementById('regNom').value,
        prenom: document.getElementById('regPrenom').value,
        email: document.getElementById('regEmail').value,
        motDePasse: document.getElementById('regPassword').value,
        role: role,
        numeroLicence: document.getElementById('regLicence')?.value || '',
        biographie: document.getElementById('regBio')?.value || ''
    };

    const res = await apiPost(`${getApiUrl('auth')}/register`, body, null);
    if (res && res.id) {
        AppState.currentUser = res;
        localStorage.setItem('patrimoine_user', JSON.stringify(res));
        showToast("Compte créé avec succès !", "success");
        if (role === 'GUIDE') navigateTo('guide');
        else navigateTo('mes-reservations');
    }
}

// --------------------------------------------------------------------------
// MODALS (RESERVATION, TICKET QR, AVIS, AJOUT SITE)
// --------------------------------------------------------------------------
function renderModals() {
    return `
        <!-- Modal Réservation -->
        <div class="modal fade" id="bookingModal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content border-0 shadow" style="border-radius: 16px;">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title fw-bold" id="bookingModalTitle">Réserver une visite</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form onsubmit="handleBookingSubmit(event)">
                        <div class="modal-body p-4">
                            <input type="hidden" id="bookType">
                            <input type="hidden" id="bookRefId">

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Nom complet</label>
                                <input type="text" id="bookNom" class="form-control" required
                                       value="${AppState.currentUser ? AppState.currentUser.prenom + ' ' + AppState.currentUser.nom : 'Awa Diop'}">
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Email de confirmation</label>
                                <input type="email" id="bookEmail" class="form-control" required
                                       value="${AppState.currentUser ? AppState.currentUser.email : 'awa.diop@mail.com'}">
                            </div>
                            <div class="row g-2 mb-3">
                                <div class="col-7">
                                    <label class="form-label fw-semibold">Date de visite</label>
                                    <input type="date" id="bookDate" class="form-control" required
                                           value="${new Date(Date.now() + 86400000).toISOString().split('T')[0]}">
                                </div>
                                <div class="col-5">
                                    <label class="form-label fw-semibold">Nb de places</label>
                                    <input type="number" id="bookPlaces" class="form-control" min="1" max="15" value="2" required>
                                </div>
                            </div>

                            <div class="alert alert-info py-2 small mb-0">
                                <i class="bi bi-shield-check me-1"></i>Vérification automatique de disponibilité auprès du microservice distant.
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary rounded-pill" data-bs-dismiss="modal">Annuler</button>
                            <button type="submit" class="btn btn-success rounded-pill px-4 fw-bold">Confirmer la Réservation</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Modal Billet avec QR Code plein écran -->
        <div class="modal fade" id="ticketModal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content border-0 shadow" style="border-radius: 16px;">
                    <div class="modal-header bg-dark text-white">
                        <h5 class="modal-title fw-bold"><i class="bi bi-ticket-perforated me-2"></i>Billet Électronique Officiel</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body p-4 text-center" id="ticketModalBody">
                        <!-- Rempli dynamiquement -->
                    </div>
                    <div class="modal-footer justify-content-center">
                        <button class="btn btn-primary rounded-pill px-4" onclick="window.print()"><i class="bi bi-printer me-1"></i>Imprimer le ticket</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal Déposer un avis 5 étoiles (Slide 46 & 49) -->
        <div class="modal fade" id="reviewModal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content border-0 shadow" style="border-radius: 16px;">
                    <div class="modal-header bg-warning text-dark">
                        <h5 class="modal-title fw-bold"><i class="bi bi-star-half me-1"></i>Noter et Commenter</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <form onsubmit="handleReviewSubmit(event)">
                        <div class="modal-body p-4">
                            <input type="hidden" id="revSiteId">
                            <input type="hidden" id="revGuideId">

                            <div class="text-center mb-3">
                                <label class="form-label fw-bold d-block">Votre Note globale</label>
                                <div class="star-rating-interactive" id="starContainer">
                                    <span onclick="setReviewRating(1)">★</span>
                                    <span onclick="setReviewRating(2)">★</span>
                                    <span onclick="setReviewRating(3)">★</span>
                                    <span onclick="setReviewRating(4)">★</span>
                                    <span onclick="setReviewRating(5)" class="active">★</span>
                                </div>
                                <input type="hidden" id="revRatingInput" value="5">
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Votre Commentaire</label>
                                <textarea id="revComment" class="form-control" rows="4" required placeholder="Partagez votre expérience sur le patrimoine ou la prestation du guide..."></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary rounded-pill" data-bs-dismiss="modal">Fermer</button>
                            <button type="submit" class="btn btn-warning rounded-pill px-4 fw-bold">Publier mon avis</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Modal Réponse du Guide -->
        <div class="modal fade" id="replyModal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content border-0 shadow" style="border-radius: 16px;">
                    <div class="modal-header bg-success text-white">
                        <h5 class="modal-title fw-bold"><i class="bi bi-reply-fill me-1"></i>Répondre au commentaire</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form onsubmit="handleReplySubmit(event)">
                        <div class="modal-body p-4">
                            <input type="hidden" id="replyAvisId">
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Votre réponse publique</label>
                                <textarea id="replyText" class="form-control" rows="3" required placeholder="Remerciez le visiteur ou apportez une précision..."></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success rounded-pill px-4">Envoyer la réponse</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Modal Signaler un avis abusif -->
        <div class="modal fade" id="signalementModal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content border-0 shadow" style="border-radius: 16px;">
                    <div class="modal-header bg-danger text-white">
                        <h5 class="modal-title fw-bold"><i class="bi bi-flag-fill me-1"></i>Signaler un avis inapproprié</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form onsubmit="handleSignalementSubmit(event)">
                        <div class="modal-body p-4">
                            <input type="hidden" id="sigAvisId">
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Motif du signalement (modération par le conservateur)</label>
                                <textarea id="sigMotif" class="form-control" rows="3" required placeholder="Propos diffamatoires, insultes, contenu non véridique..."></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-danger rounded-pill px-4">Transmettre au conservateur</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Modal Ajout de Site (Conservateur) (Slide 47) -->
        <div class="modal fade" id="addSiteModal" tabindex="-1">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content border-0 shadow" style="border-radius: 16px;">
                    <div class="modal-header bg-success text-white">
                        <h5 class="modal-title fw-bold"><i class="bi bi-bank me-2"></i>Nouveau Site du Patrimoine</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form onsubmit="handleAddSiteSubmit(event)">
                        <div class="modal-body p-4">
                            <div class="row g-2 mb-3">
                                <div class="col-8">
                                    <label class="form-label fw-semibold">Nom du Patrimoine</label>
                                    <input type="text" id="newSiteNom" class="form-control" required placeholder="Ex: Forêt Sacrée d'Oussouye">
                                </div>
                                <div class="col-4">
                                    <label class="form-label fw-semibold">Code Patrimoine</label>
                                    <input type="text" id="newSiteCode" class="form-control" required placeholder="Ex: PMZ005">
                                </div>
                            </div>
                            <div class="row g-2 mb-3">
                                <div class="col-4">
                                    <label class="form-label fw-semibold">Ville</label>
                                    <input type="text" id="newSiteVille" class="form-control" required placeholder="Ex: Oussouye">
                                </div>
                                <div class="col-4">
                                    <label class="form-label fw-semibold">Type de Site</label>
                                    <select id="newSiteType" class="form-select">
                                        <option value="MONUMENT">Monument</option>
                                        <option value="MUSEE">Musée</option>
                                        <option value="SITE_NATUREL">Site Naturel</option>
                                        <option value="PARC">Parc</option>
                                    </select>
                                </div>
                                <div class="col-4">
                                    <label class="form-label fw-semibold">Capacité d'accueil</label>
                                    <input type="number" id="newSiteCapacite" class="form-control" required value="50">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Adresse / Lieu-dit</label>
                                <input type="text" id="newSiteAdresse" class="form-control" required placeholder="Ex: Entrée sud du bois classé">
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Horaires d'ouverture (Slide 47)</label>
                                <input type="text" id="newSiteHoraires" class="form-control" value="Lun - Sam : 09h00 - 18h00">
                            </div>
                            <div class="row g-2 mb-3">
                                <div class="col-6">
                                    <label class="form-label fw-semibold">Latitude GPS</label>
                                    <input type="number" step="0.0001" id="newSiteLat" class="form-control" value="12.4850">
                                </div>
                                <div class="col-6">
                                    <label class="form-label fw-semibold">Longitude GPS</label>
                                    <input type="number" step="0.0001" id="newSiteLng" class="form-control" value="-16.5400">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">URL de la photo principale</label>
                                <input type="url" id="newSiteImg" class="form-control" value="https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=800&q=80">
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Description</label>
                                <textarea id="newSiteDesc" class="form-control" rows="3" required></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Historique</label>
                                <textarea id="newSiteHist" class="form-control" rows="3"></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary rounded-pill" data-bs-dismiss="modal">Annuler</button>
                            <button type="submit" class="btn btn-success rounded-pill px-4 fw-bold">Enregistrer le site</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    `;
}

// --------------------------------------------------------------------------
// LOGIQUE MODALES ET ACTIONS
// --------------------------------------------------------------------------
function openBookingModal(type, refId, title) {
    document.getElementById('bookingModalTitle').innerText = `Réserver : ${title}`;
    document.getElementById('bookType').value = type;
    document.getElementById('bookRefId').value = refId;
    const modal = new bootstrap.Modal(document.getElementById('bookingModal'));
    modal.show();
}

async function handleBookingSubmit(event) {
    event.preventDefault();
    const type = document.getElementById('bookType').value;
    const refId = parseInt(document.getElementById('bookRefId').value);
    const nom = document.getElementById('bookNom').value;
    const email = document.getElementById('bookEmail').value;
    const date = document.getElementById('bookDate').value;
    const places = parseInt(document.getElementById('bookPlaces').value);

    const bookingDto = {
        typeReservation: type,
        referenceId: refId,
        touristeId: AppState.currentUser ? AppState.currentUser.id : 3,
        nomClient: nom,
        email: email,
        dateVisite: date,
        nombrePlaces: places
    };

    const res = await apiPost(`${getApiUrl('reservations')}`, bookingDto, 'reservations');
    bootstrap.Modal.getInstance(document.getElementById('bookingModal'))?.hide();

    if (res && res.id) {
        showToast("Réservation confirmée avec succès ! Votre ticket QR Code est généré.", "success");
        navigateTo('mes-reservations');
    }
}

function openTicketModal(ticket) {
    const body = document.getElementById('ticketModalBody');
    body.innerHTML = `
        <div class="qr-container mb-3">
            ${generateQrCodeSvg(ticket.qrCodeHash || 'TKT-992B144')}
        </div>
        <h4 class="fw-bold mb-1">${ticket.nomClient}</h4>
        <p class="text-muted small mb-2">${ticket.email}</p>
        <div class="badge bg-success px-3 py-2 rounded-pill fs-6 mb-3">${ticket.statut || 'CONFIRMEE'}</div>

        <div class="bg-light p-3 rounded-3 text-start small">
            <div class="d-flex justify-content-between mb-1">
                <span class="text-muted">Type :</span>
                <strong>${ticket.typeReservation} #${ticket.referenceId}</strong>
            </div>
            <div class="d-flex justify-content-between mb-1">
                <span class="text-muted">Date de visite :</span>
                <strong>${ticket.dateVisite}</strong>
            </div>
            <div class="d-flex justify-content-between mb-1">
                <span class="text-muted">Places :</span>
                <strong>${ticket.nombrePlaces} personne(s)</strong>
            </div>
            <div class="d-flex justify-content-between">
                <span class="text-muted">Code Billet :</span>
                <code>${ticket.qrCodeHash || 'TKT-992B144'}</code>
            </div>
        </div>
    `;
    const modal = new bootstrap.Modal(document.getElementById('ticketModal'));
    modal.show();
}

function openReviewModal(siteId, guideId, targetName) {
    document.getElementById('revSiteId').value = siteId || '';
    document.getElementById('revGuideId').value = guideId || '';
    setReviewRating(5);
    const modal = new bootstrap.Modal(document.getElementById('reviewModal'));
    modal.show();
}

function setReviewRating(n) {
    document.getElementById('revRatingInput').value = n;
    const spans = document.querySelectorAll('#starContainer span');
    spans.forEach((s, idx) => {
        if (idx < n) s.classList.add('active');
        else s.classList.remove('active');
    });
}

async function handleReviewSubmit(event) {
    event.preventDefault();
    const siteId = document.getElementById('revSiteId').value;
    const guideId = document.getElementById('revGuideId').value;
    const note = parseInt(document.getElementById('revRatingInput').value);
    const commentaire = document.getElementById('revComment').value;

    const u = AppState.currentUser;
    const avisDto = {
        siteId: siteId ? parseInt(siteId) : null,
        guideId: guideId ? parseInt(guideId) : null,
        touristeId: u ? u.id : 3,
        touristeNom: u ? `${u.prenom} ${u.nom}` : "Awa Diop",
        note: note,
        commentaire: commentaire
    };

    await apiPost(`${getApiUrl('avis')}`, avisDto, 'avis');
    bootstrap.Modal.getInstance(document.getElementById('reviewModal'))?.hide();
    showToast("Votre avis 5 étoiles a été publié avec succès !", "success");
    renderApp();
}

function openReplyModal(avisId) {
    document.getElementById('replyAvisId').value = avisId;
    const modal = new bootstrap.Modal(document.getElementById('replyModal'));
    modal.show();
}

async function handleReplySubmit(event) {
    event.preventDefault();
    const avisId = document.getElementById('replyAvisId').value;
    const rep = document.getElementById('replyText').value;
    await apiPut(`${getApiUrl('avis')}/${avisId}/repondre`, { reponse: rep });
    bootstrap.Modal.getInstance(document.getElementById('replyModal'))?.hide();
    showToast("Réponse publiée !", "success");
    renderApp();
}

function openSignalementModal(avisId) {
    document.getElementById('sigAvisId').value = avisId;
    const modal = new bootstrap.Modal(document.getElementById('signalementModal'));
    modal.show();
}

async function handleSignalementSubmit(event) {
    event.preventDefault();
    const avisId = document.getElementById('sigAvisId').value;
    const motif = document.getElementById('sigMotif').value;
    const u = AppState.currentUser;

    await apiPost(`${getApiUrl('signalements')}`, {
        avisId: parseInt(avisId),
        signaleurId: u ? u.id : 2,
        signaleurNom: u ? `${u.prenom} ${u.nom}` : 'Guide',
        motif: motif
    }, 'signalements');

    bootstrap.Modal.getInstance(document.getElementById('signalementModal'))?.hide();
    showToast("Signalement transmis au conservateur pour modération.", "warning");
    renderApp();
}

function openAddSiteModal() {
    const modal = new bootstrap.Modal(document.getElementById('addSiteModal'));
    modal.show();
}

async function handleAddSiteSubmit(event) {
    event.preventDefault();
    const newSite = {
        nomPatrimoine: document.getElementById('newSiteNom').value,
        codePatrimoine: document.getElementById('newSiteCode').value,
        ville: document.getElementById('newSiteVille').value,
        typePatrimoine: document.getElementById('newSiteType').value,
        capacitePatrimoine: parseInt(document.getElementById('newSiteCapacite').value),
        adressePatrimoine: document.getElementById('newSiteAdresse').value,
        horaires: document.getElementById('newSiteHoraires').value,
        latitudePatrimoine: parseFloat(document.getElementById('newSiteLat').value),
        longitudePatrimoine: parseFloat(document.getElementById('newSiteLng').value),
        imageUrl: document.getElementById('newSiteImg').value,
        descriptionPatrimoine: document.getElementById('newSiteDesc').value,
        historiquePatrimoine: document.getElementById('newSiteHist').value
    };

    const saved = await apiPost(`${getApiUrl('patrimoines')}`, newSite, 'sites');
    if (saved && saved.id) {
        AppState.sites.push(saved);
    }
    bootstrap.Modal.getInstance(document.getElementById('addSiteModal'))?.hide();
    showToast("Nouveau site patrimonial ajouté avec succès !", "success");
    renderApp();
}

// --------------------------------------------------------------------------
// PIED DE PAGE (FOOTER)
// --------------------------------------------------------------------------
function renderFooter() {
    return `
        <footer class="bg-dark text-white py-4 mt-5 border-top border-secondary">
            <div class="container text-center">
                <div class="row align-items-center">
                    <div class="col-md-6 text-md-start mb-3 mb-md-0">
                        <h5 class="fw-bold mb-1 text-warning"><i class="bi bi-bank2 me-2"></i>Plateforme Patrimoine Touristique</h5>
                        <p class="text-muted small mb-0">Microservices Spring Boot orchestrés & Frontend Angular</p>
                    </div>
                    <div class="col-md-6 text-md-end">
                        <small class="text-muted">Projet de Développement d'Application Web • UFR Sciences & Technologies</small><br>
                        <small class="text-secondary">&copy; 2026 Patrimoine Sénégal - Tous droits réservés</small>
                    </div>
                </div>
            </div>
        </footer>
    `;
}

// Démarrage de l'application
window.addEventListener('DOMContentLoaded', loadInitialData);
