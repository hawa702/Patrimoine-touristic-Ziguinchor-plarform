import { Component, inject, signal } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from './core/auth.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <nav class="navbar navbar-expand-lg app-nav sticky-top">
      <div class="container">
        <a class="navbar-brand" routerLink="/" (click)="menu.set(false)">🏛️ Patrimoine de Ziguinchor</a>
        <button class="navbar-toggler" type="button" aria-label="Menu" (click)="menu.set(!menu())">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" [class.show]="menu()">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            @for (l of liens; track l.chemin) {
              <li class="nav-item">
                <a class="nav-link" [routerLink]="l.chemin" routerLinkActive="active" (click)="menu.set(false)">{{ l.label }}</a>
              </li>
            }
          </ul>
          <div class="d-flex flex-wrap align-items-center gap-2">
            @if (auth.user(); as u) {
              <span class="small text-muted">{{ u.nom }} · {{ libelleRole(u.role) }}</span>
              <a class="btn btn-sm btn-primary" [routerLink]="auth.dashboardPath()" (click)="menu.set(false)">Mon espace</a>
              <button class="btn btn-sm btn-outline-secondary" type="button" (click)="deconnexion()">Déconnexion</button>
            } @else {
              <a class="btn btn-sm btn-outline-primary" routerLink="/login" (click)="menu.set(false)">Connexion</a>
              <a class="btn btn-sm btn-primary" routerLink="/inscription" (click)="menu.set(false)">Créer un compte</a>
            }
          </div>
        </div>
      </div>
    </nav>

    <main class="min-vh-100">
      <router-outlet />
    </main>

    <footer class="app-footer mt-5 py-4">
      <div class="container d-flex flex-wrap justify-content-between gap-2 small">
        <span>© 2026 Patrimoine touristique de Ziguinchor — Casamance, Sénégal</span>
        <span>
          <a routerLink="/inscription-guide">Devenir guide</a> ·
          <a routerLink="/guides">Nos guides</a>
        </span>
      </div>
    </footer>
  `,
})
export class AppComponent {
  auth = inject(AuthService);
  menu = signal(false);

  liens = [
    { chemin: '/sites', label: 'Sites' },
    { chemin: '/circuits', label: 'Circuits' },
    { chemin: '/evenements', label: 'Visites & évènements' },
    { chemin: '/guides', label: 'Guides' },
  ];

  libelleRole(role: string): string {
    switch (role) {
      case 'ADMIN': return 'Conservateur';
      case 'GUIDE': return 'Guide';
      default: return 'Touriste';
    }
  }

  deconnexion(): void {
    this.menu.set(false);
    this.auth.deconnecter();
  }
}
