import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-not-found',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="container py-5 text-center">
      <div style="font-size: 3rem">🧭</div>
      <h1 class="h3">Page introuvable</h1>
      <p class="text-muted">Cette adresse n'existe pas.</p>
      <a class="btn btn-primary" routerLink="/">Retour à l'accueil</a>
    </div>
  `,
})
export class NotFoundComponent {}
