import { Component, OnInit, inject, signal } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { Circuit } from '../../core/models';
import { dureeLisible, messageErreur } from '../../core/util';

@Component({
  selector: 'app-circuit-detail',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="container py-4">
      <a routerLink="/circuits" class="small">← Tous les circuits</a>
      @if (erreur()) {
        <div class="alert alert-danger mt-3">{{ erreur() }}</div>
      }
      @if (circuit(); as c) {
        <div class="row g-4 mt-1">
          <div class="col-12 col-lg-8">
            <span class="badge text-bg-light border mb-2">{{ c.difficulte }}</span>
            <h1 class="h2">{{ c.nomCircuit }}</h1>
            <p>{{ c.descriptionCircuit }}</p>

            <h2 class="h4 mt-4 mb-3">Les étapes</h2>
            <div class="timeline">
              @for (e of c.etapes; track e.id) {
                <div class="step">
                  <div class="fw-semibold">Étape {{ e.position }}
                    <span class="text-muted fw-normal small">· {{ duree(e.dureeEstime) }}</span>
                  </div>
                  @if (e.patrimoine; as p) {
                    <a [routerLink]="['/sites', p.id]">{{ p.nomPatrimoine }}</a>
                    <div class="small text-muted">{{ p.villePatrimoine }}</div>
                  } @else {
                    <span class="text-muted small">Site n°{{ e.patrimoineId }} (informations momentanément indisponibles)</span>
                  }
                </div>
              } @empty {
                <p class="text-muted">Les étapes ne sont pas encore renseignées.</p>
              }
            </div>
          </div>

          <div class="col-12 col-lg-4">
            <div class="panel">
              <ul class="list-unstyled small">
                <li class="mb-2">⏱ Durée : <strong>{{ duree(c.dureeTotale) }}</strong></li>
                <li class="mb-2">📍 Distance : <strong>{{ c.distanceTotale }} km</strong></li>
                <li class="mb-2">👥 Capacité : <strong>{{ c.capaciteMax }} personnes par date</strong></li>
              </ul>
              <a class="btn btn-accent w-100" [routerLink]="['/reserver', 'CIRCUIT', c.id]">Réserver ce circuit</a>
              <div class="small text-muted mt-2">Un compte touriste est nécessaire pour réserver.</div>
            </div>
          </div>
        </div>
      }
    </div>
  `,
})
export class CircuitDetailComponent implements OnInit {
  private api = inject(ApiService);
  private route = inject(ActivatedRoute);
  circuit = signal<Circuit | null>(null);
  erreur = signal('');
  duree = dureeLisible;

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.api.circuit(id).subscribe({
      next: (c) => this.circuit.set(c),
      error: (e) => this.erreur.set(messageErreur(e, 'Circuit introuvable.')),
    });
  }
}
