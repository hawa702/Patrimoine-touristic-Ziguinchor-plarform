import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth.service';
import { messageErreur } from '../../core/util';

@Component({
  selector: 'app-register-guide',
  standalone: true,
  imports: [FormsModule, RouterLink],
  template: `
    <div class="container py-5" style="max-width: 560px">
      <div class="panel">
        <h1 class="h3 mb-1">Inscription guide</h1>
        <p class="text-muted small">Votre compte sera <strong>validé par le conservateur</strong> avant d'apparaître dans l'annuaire et de pouvoir recevoir des visites.</p>
        @if (erreur()) {
          <div class="alert alert-danger py-2">{{ erreur() }}</div>
        }
        <form (ngSubmit)="inscrire()" #f="ngForm">
          <div class="row g-3">
            <div class="col-12 col-md-6">
              <label class="form-label" for="nom">Nom complet</label>
              <input id="nom" class="form-control" name="nom" [(ngModel)]="d.nom" required>
            </div>
            <div class="col-12 col-md-6">
              <label class="form-label" for="lic">Numéro de licence</label>
              <input id="lic" class="form-control" name="numeroLicence" [(ngModel)]="d.numeroLicence" required>
            </div>
            <div class="col-12 col-md-6">
              <label class="form-label" for="email">Email</label>
              <input id="email" class="form-control" type="email" name="email" [(ngModel)]="d.email" required>
            </div>
            <div class="col-12 col-md-6">
              <label class="form-label" for="pwd">Mot de passe (6 min.)</label>
              <input id="pwd" class="form-control" type="password" name="password" [(ngModel)]="d.password" required minlength="6" autocomplete="new-password">
            </div>
            <div class="col-12">
              <label class="form-label" for="lang">Langues parlées</label>
              <input id="lang" class="form-control" name="langues" [(ngModel)]="d.langues" placeholder="Français, Anglais, Diola…">
            </div>
            <div class="col-12">
              <label class="form-label" for="bio">Présentation</label>
              <textarea id="bio" class="form-control" rows="3" name="biographie" [(ngModel)]="d.biographie" maxlength="2000"></textarea>
            </div>
          </div>
          <button class="btn btn-primary w-100 mt-3" type="submit" [disabled]="f.invalid || envoi()">Envoyer ma demande</button>
        </form>
        <hr>
        <div class="small">Déjà inscrit ? <a routerLink="/login">Se connecter</a></div>
      </div>
    </div>
  `,
})
export class RegisterGuideComponent {
  private auth = inject(AuthService);
  private router = inject(Router);
  d = { nom: '', email: '', password: '', numeroLicence: '', biographie: '', langues: '' };
  envoi = signal(false);
  erreur = signal('');

  inscrire(): void {
    this.erreur.set('');
    this.envoi.set(true);
    this.auth.inscrireGuide(this.d).subscribe({
      next: () => void this.router.navigateByUrl(this.auth.dashboardPath()),
      error: (e) => {
        this.envoi.set(false);
        this.erreur.set(messageErreur(e, 'Inscription impossible.'));
      },
    });
  }
}
