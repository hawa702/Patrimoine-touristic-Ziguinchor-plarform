import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { Evenement, GuidePublic } from '../../core/models';
import { messageErreur } from '../../core/util';
import { AvisSectionComponent } from '../../shared/avis-section.component';

@Component({
  selector: 'app-guide-detail',
  standalone: true,
  imports: [RouterLink, DatePipe, AvisSectionComponent],
  template: `
    <div class="container py-4">
      <a routerLink="/guides" class="small">← Tous les guides</a>
      @if (erreur()) {
        <div class="alert alert-danger mt-3">{{ erreur() }}</div>
      }
      @if (guide(); as g) {
        <div class="row g-4 mt-1">
          <div class="col-12 col-lg-7">
            <h1 class="h2">🧑‍🏫 {{ g.nom }}</h1>
            @if (g.langues) { <p class="text-muted">Langues : {{ g.langues }}</p> }
            <p>{{ g.biographie || 'Biographie non renseignée.' }}</p>
          </div>
          <div class="col-12 col-lg-5">
            <div class="panel">
              <h2 class="h5">Prochaines visites</h2>
              @for (e of visites(); track e.id) {
                <a class="d-block py-2 border-bottom text-decoration-none" [routerLink]="['/evenements', e.id]">
                  <strong>{{ e.titre }}</strong>
                  <div class="small text-muted">{{ e.dateDebut | date: 'EEEE d MMMM y, HH:mm' }}</div>
                </a>
              } @empty {
                <p class="small text-muted mb-0">Aucune visite programmée.</p>
              }
            </div>
          </div>
        </div>
        <div class="mt-4">
          <app-avis-section [cibleType]="'GUIDE'" [cibleId]="g.id" />
        </div>
      }
    </div>
  `,
})
export class GuideDetailComponent implements OnInit {
  private api = inject(ApiService);
  private route = inject(ActivatedRoute);
  guide = signal<GuidePublic | null>(null);
  visites = signal<Evenement[]>([]);
  erreur = signal('');

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.api.guide(id).subscribe({
      next: (g) => this.guide.set(g),
      error: (e) => this.erreur.set(messageErreur(e, 'Guide introuvable.')),
    });
    this.api.evenements({ guideId: id }).subscribe({
      next: (l) => this.visites.set(l.filter((e) => new Date(e.dateDebut).getTime() >= Date.now())),
    });
  }
}
