import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { Moyenne, Patrimoine } from '../../core/models';
import { TYPES_SITE, distanceKm, messageErreur, versDictionnaire } from '../../core/util';
import { PaginationComponent } from '../../shared/pagination.component';
import { SiteCardComponent } from '../../shared/site-card.component';

const PAR_PAGE = 6;

/** Recherche par mot-clé, ville, type, et tri par proximité GPS + pagination. */
@Component({
  selector: 'app-sites-list',
  standalone: true,
  imports: [FormsModule, SiteCardComponent, PaginationComponent],
  template: `
    <div class="page-head">
      <div class="container">
        <h1>Sites du patrimoine</h1>
        <p class="text-muted mb-0">Monuments, musées, parcs et sites naturels de la région.</p>
      </div>
    </div>

    <div class="container">
      <div class="panel mb-4">
        <div class="row g-3 align-items-end">
          <div class="col-12 col-md-4">
            <label class="form-label small fw-semibold" for="mc">Mot-clé</label>
            <input id="mc" class="form-control" placeholder="Nom, description, adresse…" [ngModel]="motCle()" (ngModelChange)="motCle.set($event); page.set(0)">
          </div>
          <div class="col-6 col-md-3">
            <label class="form-label small fw-semibold" for="ville">Ville</label>
            <select id="ville" class="form-select" [ngModel]="ville()" (ngModelChange)="ville.set($event); page.set(0)">
              <option value="">Toutes</option>
              @for (v of villes(); track v) { <option [value]="v">{{ v }}</option> }
            </select>
          </div>
          <div class="col-6 col-md-3">
            <label class="form-label small fw-semibold" for="type">Type</label>
            <select id="type" class="form-select" [ngModel]="type()" (ngModelChange)="type.set($event); page.set(0)">
              <option value="">Tous</option>
              @for (t of types; track t.value) { <option [value]="t.value">{{ t.label }}</option> }
            </select>
          </div>
          <div class="col-12 col-md-2 d-grid">
            @if (position()) {
              <button type="button" class="btn btn-outline-secondary" (click)="position.set(null)">✕ Proximité</button>
            } @else {
              <button type="button" class="btn btn-outline-primary" (click)="localiser()" [disabled]="localisation()">📍 Près de moi</button>
            }
          </div>
        </div>
        @if (messageGps()) {
          <div class="small text-danger mt-2">{{ messageGps() }}</div>
        }
      </div>

      @if (erreur()) {
        <div class="alert alert-danger">{{ erreur() }}</div>
      }

      <p class="text-muted small">{{ resultats().length }} site(s) trouvé(s)@if (position()) { — triés du plus proche au plus éloigné }</p>

      <div class="row g-4 mb-4">
        @for (s of pageCourante(); track s.id) {
          <div class="col-12 col-md-6 col-lg-4">
            <app-site-card [site]="s" [moyenne]="moy(s)" [distance]="distance(s)" />
          </div>
        } @empty {
          <p class="text-muted">Aucun site ne correspond à votre recherche.</p>
        }
      </div>

      <app-pagination [page]="page()" [nombrePages]="nombrePages()" (changer)="page.set($event)" />
    </div>
  `,
})
export class SitesListComponent implements OnInit {
  private api = inject(ApiService);

  types = TYPES_SITE;
  sites = signal<Patrimoine[]>([]);
  moyennes = signal<Record<number, Moyenne>>({});
  erreur = signal('');

  motCle = signal('');
  ville = signal('');
  type = signal('');
  page = signal(0);

  position = signal<{ lat: number; lng: number } | null>(null);
  localisation = signal(false);
  messageGps = signal('');

  villes = computed(() =>
    [...new Set(this.sites().map((s) => s.villePatrimoine).filter((v): v is string => !!v))].sort(),
  );

  resultats = computed(() => {
    const mc = this.motCle().trim().toLowerCase();
    const v = this.ville();
    const t = this.type();
    const pos = this.position();
    const liste = this.sites().filter(
      (s) =>
        (!mc ||
          [s.nomPatrimoine, s.descriptionPatrimoine, s.adressePatrimoine, s.villePatrimoine].some((x) =>
            (x ?? '').toLowerCase().includes(mc),
          )) &&
        (!v || s.villePatrimoine === v) &&
        (!t || s.typePatrimoine === t),
    );
    if (pos) {
      return [...liste].sort(
        (a, b) =>
          distanceKm(pos.lat, pos.lng, a.latitudePatrimoine, a.longitudePatrimoine) -
          distanceKm(pos.lat, pos.lng, b.latitudePatrimoine, b.longitudePatrimoine),
      );
    }
    return liste;
  });

  nombrePages = computed(() => Math.ceil(this.resultats().length / PAR_PAGE));
  pageCourante = computed(() => this.resultats().slice(this.page() * PAR_PAGE, (this.page() + 1) * PAR_PAGE));

  ngOnInit(): void {
    this.api.patrimoines().subscribe({
      next: (l) => this.sites.set(l),
      error: (e) => this.erreur.set(messageErreur(e)),
    });
    this.api.moyennes('SITE').subscribe({ next: (m) => this.moyennes.set(versDictionnaire(m)) });
  }

  moy(s: Patrimoine): Moyenne | undefined {
    return s.id === undefined ? undefined : this.moyennes()[s.id];
  }

  distance(s: Patrimoine): number | null {
    const pos = this.position();
    if (!pos) return null;
    return Math.round(distanceKm(pos.lat, pos.lng, s.latitudePatrimoine, s.longitudePatrimoine) * 10) / 10;
  }

  localiser(): void {
    this.messageGps.set('');
    if (!('geolocation' in navigator)) {
      this.messageGps.set("La géolocalisation n'est pas disponible sur ce navigateur.");
      return;
    }
    this.localisation.set(true);
    navigator.geolocation.getCurrentPosition(
      (p) => {
        this.localisation.set(false);
        this.position.set({ lat: p.coords.latitude, lng: p.coords.longitude });
        this.page.set(0);
      },
      () => {
        this.localisation.set(false);
        this.messageGps.set("Impossible d'obtenir votre position (autorisation refusée ?).");
      },
      { timeout: 10000 },
    );
  }
}
