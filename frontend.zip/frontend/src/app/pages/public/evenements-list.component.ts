import { DatePipe } from '@angular/common';
import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { Evenement, TypeEvenement } from '../../core/models';
import { messageErreur } from '../../core/util';

@Component({
  selector: 'app-evenements-list',
  standalone: true,
  imports: [RouterLink, DatePipe],
  template: `
    <div class="page-head">
      <div class="container">
        <h1>Visites guidées & évènements</h1>
        <p class="text-muted mb-0">Le programme à venir : visites avec guide, expositions et ateliers.</p>
      </div>
    </div>
    <div class="container">
      <div class="d-flex flex-wrap gap-2 mb-4">
        @for (f of filtres; track f.valeur) {
          <button type="button" class="btn btn-sm" [class.btn-primary]="filtre() === f.valeur" [class.btn-outline-primary]="filtre() !== f.valeur" (click)="filtre.set(f.valeur)">{{ f.label }}</button>
        }
      </div>
      @if (erreur()) {
        <div class="alert alert-danger">{{ erreur() }}</div>
      }
      <div class="row g-4">
        @for (e of affiches(); track e.id) {
          <div class="col-12 col-md-6 col-lg-4">
            <a class="panel d-block h-100 text-decoration-none text-reset site-card" [routerLink]="['/evenements', e.id]">
              <span class="badge text-bg-light border mb-2">{{ libelle(e.type) }}</span>
              <h5 class="display-font">{{ e.titre }}</h5>
              <div class="small text-accent fw-semibold">{{ e.dateDebut | date: 'EEEE d MMMM y, HH:mm' }}</div>
              <div class="small text-muted mb-2">{{ e.lieu }}</div>
              @if (e.guideNom) { <div class="small">🧑‍🏫 Guide : {{ e.guideNom }}</div> }
              <div class="small">👥 {{ e.placesMax }} places</div>
            </a>
          </div>
        } @empty {
          <p class="text-muted">Aucun évènement à venir dans cette catégorie.</p>
        }
      </div>
    </div>
  `,
})
export class EvenementsListComponent implements OnInit {
  private api = inject(ApiService);
  evenements = signal<Evenement[]>([]);
  erreur = signal('');
  filtre = signal<TypeEvenement | ''>('');

  filtres: { valeur: TypeEvenement | ''; label: string }[] = [
    { valeur: '', label: 'Tout' },
    { valeur: 'VISITE_GUIDEE', label: 'Visites guidées' },
    { valeur: 'EXPOSITION', label: 'Expositions' },
    { valeur: 'ATELIER', label: 'Ateliers' },
  ];

  affiches = computed(() =>
    this.evenements()
      .filter((e) => new Date(e.dateDebut).getTime() >= Date.now())
      .filter((e) => !this.filtre() || e.type === this.filtre())
      .sort((a, b) => a.dateDebut.localeCompare(b.dateDebut)),
  );

  libelle(t: string): string {
    return t === 'VISITE_GUIDEE' ? 'Visite guidée' : t === 'ATELIER' ? 'Atelier' : 'Exposition';
  }

  ngOnInit(): void {
    this.api.evenements().subscribe({
      next: (l) => this.evenements.set(l),
      error: (e) => this.erreur.set(messageErreur(e)),
    });
  }
}
