import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { Disponibilite, Evenement } from '../../core/models';
import { messageErreur } from '../../core/util';

@Component({
  selector: 'app-evenement-detail',
  standalone: true,
  imports: [RouterLink, DatePipe],
  template: `
    <div class="container py-4">
      <a routerLink="/evenements" class="small">← Tout le programme</a>
      @if (erreur()) {
        <div class="alert alert-danger mt-3">{{ erreur() }}</div>
      }
      @if (evenement(); as e) {
        <div class="row g-4 mt-1">
          <div class="col-12 col-lg-8">
            <span class="badge text-bg-light border mb-2">{{ libelle(e.type) }}</span>
            <h1 class="h2">{{ e.titre }}</h1>
            <p>{{ e.description }}</p>
            <ul class="list-unstyled">
              <li class="mb-1">📅 {{ e.dateDebut | date: 'EEEE d MMMM y, HH:mm' }} → {{ e.dateFin | date: 'HH:mm' }}</li>
              @if (e.lieu) { <li class="mb-1">📍 {{ e.lieu }}</li> }
              @if (e.patrimoineId) { <li class="mb-1">🏛️ <a [routerLink]="['/sites', e.patrimoineId]">Voir le site qui accueille l'évènement</a></li> }
              @if (e.guideId) { <li class="mb-1">🧑‍🏫 Guide : <a [routerLink]="['/guides', e.guideId]">{{ e.guideNom }}</a></li> }
            </ul>
          </div>
          <div class="col-12 col-lg-4">
            <div class="panel">
              @if (dispo(); as d) {
                <div class="stat mb-3">
                  <div class="n">{{ d.placesRestantes }}</div>
                  <div class="small text-muted">place(s) restante(s) sur {{ d.capacite }}</div>
                </div>
                @if (d.disponible) {
                  <a class="btn btn-accent w-100" [routerLink]="['/reserver', 'EVENEMENT', e.id]">Réserver ma place</a>
                  <div class="small text-muted mt-2">Un compte touriste est nécessaire pour réserver.</div>
                } @else {
                  <div class="alert alert-warning mb-0">Complet : plus de place disponible.</div>
                }
              } @else {
                <p class="text-muted small mb-0">Disponibilité en cours de chargement…</p>
              }
            </div>
          </div>
        </div>
      }
    </div>
  `,
})
export class EvenementDetailComponent implements OnInit {
  private api = inject(ApiService);
  private route = inject(ActivatedRoute);
  evenement = signal<Evenement | null>(null);
  dispo = signal<Disponibilite | null>(null);
  erreur = signal('');

  libelle(t: string): string {
    return t === 'VISITE_GUIDEE' ? 'Visite guidée' : t === 'ATELIER' ? 'Atelier' : 'Exposition';
  }

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.api.evenement(id).subscribe({
      next: (e) => this.evenement.set(e),
      error: (e) => this.erreur.set(messageErreur(e, 'Évènement introuvable.')),
    });
    this.api.disponibilite('EVENEMENT', id).subscribe({ next: (d) => this.dispo.set(d) });
  }
}
