import { DatePipe } from '@angular/common';
import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { Evenement, Patrimoine } from '../../core/models';
import { IMAGE_PAR_DEFAUT, libelleType, messageErreur } from '../../core/util';
import { AvisSectionComponent } from '../../shared/avis-section.component';

@Component({
  selector: 'app-site-detail',
  standalone: true,
  imports: [RouterLink, DatePipe, AvisSectionComponent],
  template: `
    <div class="container py-4">
      <a routerLink="/sites" class="small">← Tous les sites</a>

      @if (erreur()) {
        <div class="alert alert-danger mt-3">{{ erreur() }}</div>
      }

      @if (site(); as s) {
        <div class="row g-4 mt-1">
          <div class="col-12 col-lg-7">
            <img class="hero-img mb-3" [src]="s.imageUrl || imageDefaut" [alt]="s.nomPatrimoine">
            <span class="badge text-bg-light border mb-2">{{ libelleType(s.typePatrimoine) }}</span>
            <h1 class="h2">{{ s.nomPatrimoine }}</h1>
            <p>{{ s.descriptionPatrimoine }}</p>
            @if (s.historiquePatrimoine) {
              <h2 class="h5 mt-4">Histoire</h2>
              <p>{{ s.historiquePatrimoine }}</p>
            }
          </div>

          <div class="col-12 col-lg-5">
            <div class="panel mb-3">
              <h2 class="h5">Informations pratiques</h2>
              <ul class="list-unstyled mb-0 small">
                @if (s.adressePatrimoine) { <li class="mb-1">📍 {{ s.adressePatrimoine }}@if (s.villePatrimoine) { , {{ s.villePatrimoine }} }</li> }
                @if (s.horairesPatrimoine) { <li class="mb-1">🕒 {{ s.horairesPatrimoine }}</li> }
                <li class="mb-1">👥 Capacité d'accueil : {{ s.capacitePatrimoine }} personnes</li>
                @if (aGps()) { <li>🧭 GPS : {{ s.latitudePatrimoine }}, {{ s.longitudePatrimoine }}</li> }
              </ul>
            </div>
            @if (carte(); as c) {
              <iframe class="map-frame mb-3" [src]="c" title="Carte du site" loading="lazy"></iframe>
            }
            <div class="panel">
              <h2 class="h5">Visites et évènements ici</h2>
              @for (e of evenements(); track e.id) {
                <a class="d-block py-2 border-bottom text-decoration-none" [routerLink]="['/evenements', e.id]">
                  <strong>{{ e.titre }}</strong>
                  <div class="small text-muted">{{ e.dateDebut | date: 'EEEE d MMMM y, HH:mm' }}</div>
                </a>
              } @empty {
                <p class="small text-muted mb-0">Aucune visite programmée pour le moment.</p>
              }
            </div>
          </div>
        </div>

        <div class="mt-4">
          <app-avis-section [cibleType]="'SITE'" [cibleId]="s.id!" />
        </div>
      }
    </div>
  `,
})
export class SiteDetailComponent implements OnInit {
  private api = inject(ApiService);
  private route = inject(ActivatedRoute);
  private san = inject(DomSanitizer);

  imageDefaut = IMAGE_PAR_DEFAUT;
  libelleType = libelleType;

  site = signal<Patrimoine | null>(null);
  evenements = signal<Evenement[]>([]);
  erreur = signal('');

  aGps = computed(() => {
    const s = this.site();
    return !!s && (s.latitudePatrimoine !== 0 || s.longitudePatrimoine !== 0);
  });

  /** Carte OpenStreetMap intégrée autour des coordonnées GPS du site. */
  carte = computed(() => {
    const s = this.site();
    if (!s || !this.aGps()) return null;
    const d = 0.01;
    const bbox = `${s.longitudePatrimoine - d},${s.latitudePatrimoine - d},${s.longitudePatrimoine + d},${s.latitudePatrimoine + d}`;
    return this.san.bypassSecurityTrustResourceUrl(
      `https://www.openstreetmap.org/export/embed.html?bbox=${bbox}&layer=mapnik&marker=${s.latitudePatrimoine},${s.longitudePatrimoine}`,
    );
  });

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.api.patrimoine(id).subscribe({
      next: (s) => this.site.set(s),
      error: (e) => this.erreur.set(messageErreur(e, 'Site introuvable.')),
    });
    this.api.evenements({ patrimoineId: id }).subscribe({
      next: (l) =>
        this.evenements.set(
          l.filter((e) => new Date(e.dateDebut).getTime() >= Date.now()).sort((a, b) => a.dateDebut.localeCompare(b.dateDebut)),
        ),
    });
  }
}
