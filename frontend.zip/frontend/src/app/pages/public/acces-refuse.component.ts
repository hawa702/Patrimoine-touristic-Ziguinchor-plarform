import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth.service';

@Component({
  selector: 'app-acces-refuse',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="container py-5 text-center">
      <div style="font-size: 3rem">🔒</div>
      <h1 class="h3">Accès refusé</h1>
      <p class="text-muted">Vous n'avez pas les droits nécessaires pour consulter cette page.</p>
      <a class="btn btn-primary" [routerLink]="auth.isLoggedIn() ? auth.dashboardPath() : '/'">Retour</a>
    </div>
  `,
})
export class AccesRefuseComponent {
  auth = inject(AuthService);
}
