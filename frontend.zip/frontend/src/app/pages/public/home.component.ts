import { DatePipe } from '@angular/common';
import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { Circuit, Evenement, Moyenne, Patrimoine } from '../../core/models';
import { dureeLisible, messageErreur, versDictionnaire } from '../../core/util';
import { SiteCardComponent } from '../../shared/site-card.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterLink, DatePipe, SiteCardComponent],
  template: `
    <section class="hero">
      <div class="container">
        <h1 class="mb-3">Découvrez le patrimoine de Ziguinchor et de la Casamance</h1>
        <p class="lead mb-4">Monuments, musées, sites naturels : parcourez les sites, réservez une visite guidée et partagez votre expérience.</p>
        <div class="d-flex flex-wrap gap-2">
          <a class="btn btn-accent btn-lg" routerLink="/sites">Explorer les sites</a>
          <a class="btn btn-light btn-lg" routerLink="/circuits">Voir les circuits</a>
        </div>
      </div>
    </section>

    <div class="container py-5">
      @if (erreur()) {
        <div class="alert alert-danger">{{ erreur() }}</div>
      }

      <div class="d-flex justify-content-between align-items-end mb-3">
        <h2 class="mb-0">Sites à découvrir</h2>
        <a routerLink="/sites">Tous les sites →</a>
      </div>
      <div class="row g-4 mb-5">
        @for (s of vedettes(); track s.id) {
          <div class="col-12 col-md-6 col-lg-4">
            <app-site-card [site]="s" [moyenne]="moy(s)" />
          </div>
        } @empty {
          <p class="text-muted">Aucun site pour le moment.</p>
        }
      </div>

      <div class="d-flex justify-content-between align-items-end mb-3">
        <h2 class="mb-0">Circuits</h2>
        <a routerLink="/circuits">Tous les circuits →</a>
      </div>
      <div class="row g-4 mb-5">
        @for (c of circuitsVedettes(); track c.id) {
          <div class="col-12 col-md-6 col-lg-4">
            <a class="panel d-block h-100 text-decoration-none text-reset site-card" [routerLink]="['/circuits', c.id]">
              <span class="badge text-bg-light border mb-2">{{ c.difficulte }}</span>
              <h5 class="display-font">{{ c.nomCircuit }}</h5>
              <p class="small text-muted mb-2">{{ c.descriptionCircuit }}</p>
              <div class="small">⏱ {{ duree(c.dureeTotale) }} · 📍 {{ c.distanceTotale }} km · 👥 {{ c.capaciteMax }} pers. max</div>
            </a>
          </div>
        } @empty {
          <p class="text-muted">Aucun circuit pour le moment.</p>
        }
      </div>

      <div class="d-flex justify-content-between align-items-end mb-3">
        <h2 class="mb-0">Prochaines visites & évènements</h2>
        <a routerLink="/evenements">Tout le programme →</a>
      </div>
      <div class="row g-4 mb-5">
        @for (e of prochains(); track e.id) {
          <div class="col-12 col-md-6 col-lg-4">
            <a class="panel d-block h-100 text-decoration-none text-reset site-card" [routerLink]="['/evenements', e.id]">
              <span class="badge text-bg-light border mb-2">{{ libelleType(e.type) }}</span>
              <h5 class="display-font">{{ e.titre }}</h5>
              <div class="small text-accent fw-semibold">{{ e.dateDebut | date: 'EEEE d MMMM y, HH:mm' }}</div>
              <div class="small text-muted">{{ e.lieu }}</div>
            </a>
          </div>
        } @empty {
          <p class="text-muted">Aucun évènement à venir.</p>
        }
      </div>

      <div class="panel bg-sand d-flex flex-wrap justify-content-between align-items-center gap-3">
        <div>
          <h3 class="h4 mb-1">Vous êtes guide professionnel ?</h3>
          <p class="mb-0 text-muted">Créez votre compte : après validation par le conservateur, vous recevrez vos visites et vos avis.</p>
        </div>
        <a class="btn btn-primary" routerLink="/inscription-guide">Devenir guide</a>
      </div>
    </div>
  `,
})
export class HomeComponent implements OnInit {
  private api = inject(ApiService);

  sites = signal<Patrimoine[]>([]);
  circuits = signal<Circuit[]>([]);
  evenements = signal<Evenement[]>([]);
  moyennes = signal<Record<number, Moyenne>>({});
  erreur = signal('');

  vedettes = computed(() => this.sites().slice(0, 3));
  circuitsVedettes = computed(() => this.circuits().slice(0, 3));
  prochains = computed(() =>
    this.evenements()
      .filter((e) => new Date(e.dateDebut).getTime() >= Date.now())
      .sort((a, b) => a.dateDebut.localeCompare(b.dateDebut))
      .slice(0, 3),
  );

  duree = dureeLisible;
  libelleType(t: string): string {
    return t === 'VISITE_GUIDEE' ? 'Visite guidée' : t === 'ATELIER' ? 'Atelier' : 'Exposition';
  }

  moy(s: Patrimoine): Moyenne | undefined {
    return s.id === undefined ? undefined : this.moyennes()[s.id];
  }

  ngOnInit(): void {
    this.api.patrimoines().subscribe({
      next: (l) => this.sites.set(l),
      error: (e) => this.erreur.set(messageErreur(e)),
    });
    this.api.circuits().subscribe({ next: (l) => this.circuits.set(l) });
    this.api.evenements().subscribe({ next: (l) => this.evenements.set(l) });
    this.api.moyennes('SITE').subscribe({ next: (m) => this.moyennes.set(versDictionnaire(m)) });
  }
}
