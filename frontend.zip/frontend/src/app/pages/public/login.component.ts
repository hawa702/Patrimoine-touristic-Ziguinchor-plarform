import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth.service';
import { messageErreur } from '../../core/util';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, RouterLink],
  template: `
    <div class="container py-5" style="max-width: 460px">
      <div class="panel">
        <h1 class="h3 mb-3">Connexion</h1>

        @if (expire) {
          <div class="alert alert-warning py-2">Votre session a expiré, merci de vous reconnecter.</div>
        }
        @if (erreur()) {
          <div class="alert alert-danger py-2">{{ erreur() }}</div>
        }

        <form (ngSubmit)="connecter()" #f="ngForm">
          <div class="mb-3">
            <label class="form-label" for="email">Email</label>
            <input id="email" class="form-control" type="email" name="email" [(ngModel)]="email" required autocomplete="username">
          </div>
          <div class="mb-3">
            <label class="form-label" for="pwd">Mot de passe</label>
            <input id="pwd" class="form-control" type="password" name="password" [(ngModel)]="password" required autocomplete="current-password">
          </div>
          <button class="btn btn-primary w-100" type="submit" [disabled]="f.invalid || envoi()">Se connecter</button>
        </form>

        <hr>
        <div class="small">
          Pas encore de compte ?
          <a routerLink="/inscription">Touriste</a> ·
          <a routerLink="/inscription-guide">Guide</a>
        </div>

        <div class="small text-muted mt-3">
          <div class="mb-1">Comptes de démonstration (mot de passe : <code>password123</code>) :</div>
          <div class="d-flex flex-wrap gap-1">
            <button type="button" class="btn btn-sm btn-outline-secondary" (click)="remplir('touriste@patrimoine.sn')">Touriste</button>
            <button type="button" class="btn btn-sm btn-outline-secondary" (click)="remplir('guide@patrimoine.sn')">Guide</button>
            <button type="button" class="btn btn-sm btn-outline-secondary" (click)="remplir('conservateur@patrimoine.sn')">Conservateur</button>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class LoginComponent {
  private auth = inject(AuthService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);

  email = '';
  password = '';
  envoi = signal(false);
  erreur = signal('');
  expire = this.route.snapshot.queryParamMap.get('expire') === '1';

  remplir(email: string): void {
    this.email = email;
    this.password = 'password123';
  }

  connecter(): void {
    this.erreur.set('');
    this.envoi.set(true);
    this.auth.login(this.email, this.password).subscribe({
      next: () => {
        const redirect = this.route.snapshot.queryParamMap.get('redirect');
        void this.router.navigateByUrl(redirect && redirect.startsWith('/') ? redirect : this.auth.dashboardPath());
      },
      error: (e) => {
        this.envoi.set(false);
        this.erreur.set(messageErreur(e, 'Connexion impossible.'));
      },
    });
  }
}
