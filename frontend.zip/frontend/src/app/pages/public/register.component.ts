import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth.service';
import { messageErreur } from '../../core/util';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule, RouterLink],
  template: `
    <div class="container py-5" style="max-width: 460px">
      <div class="panel">
        <h1 class="h3 mb-1">Créer un compte touriste</h1>
        <p class="text-muted small">Réservez des visites, annulez-les et donnez votre avis.</p>
        @if (erreur()) {
          <div class="alert alert-danger py-2">{{ erreur() }}</div>
        }
        <form (ngSubmit)="inscrire()" #f="ngForm">
          <div class="mb-3">
            <label class="form-label" for="nom">Nom complet</label>
            <input id="nom" class="form-control" name="nom" [(ngModel)]="nom" required>
          </div>
          <div class="mb-3">
            <label class="form-label" for="email">Email</label>
            <input id="email" class="form-control" type="email" name="email" [(ngModel)]="email" required>
          </div>
          <div class="mb-3">
            <label class="form-label" for="pwd">Mot de passe (6 caractères minimum)</label>
            <input id="pwd" class="form-control" type="password" name="password" [(ngModel)]="password" required minlength="6" autocomplete="new-password">
          </div>
          <button class="btn btn-primary w-100" type="submit" [disabled]="f.invalid || envoi()">Créer mon compte</button>
        </form>
        <hr>
        <div class="small">Déjà inscrit ? <a routerLink="/login">Se connecter</a> · Vous êtes guide ? <a routerLink="/inscription-guide">Inscription guide</a></div>
      </div>
    </div>
  `,
})
export class RegisterComponent {
  private auth = inject(AuthService);
  private router = inject(Router);
  nom = '';
  email = '';
  password = '';
  envoi = signal(false);
  erreur = signal('');

  inscrire(): void {
    this.erreur.set('');
    this.envoi.set(true);
    this.auth.inscrireTouriste(this.nom, this.email, this.password).subscribe({
      next: () => void this.router.navigateByUrl(this.auth.dashboardPath()),
      error: (e) => {
        this.envoi.set(false);
        this.erreur.set(messageErreur(e, 'Inscription impossible.'));
      },
    });
  }
}
