import { Component, OnInit, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { Circuit } from '../../core/models';
import { dureeLisible, messageErreur } from '../../core/util';

@Component({
  selector: 'app-circuits-list',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="page-head">
      <div class="container">
        <h1>Circuits touristiques</h1>
        <p class="text-muted mb-0">Des parcours qui relient plusieurs sites du patrimoine.</p>
      </div>
    </div>
    <div class="container">
      @if (erreur()) {
        <div class="alert alert-danger">{{ erreur() }}</div>
      }
      <div class="row g-4">
        @for (c of circuits(); track c.id) {
          <div class="col-12 col-md-6 col-lg-4">
            <a class="panel d-block h-100 text-decoration-none text-reset site-card" [routerLink]="['/circuits', c.id]">
              <div class="d-flex justify-content-between">
                <span class="badge text-bg-light border">{{ c.difficulte }}</span>
                <small class="text-muted">{{ c.codeCircuit }}</small>
              </div>
              <h5 class="display-font mt-2">{{ c.nomCircuit }}</h5>
              <p class="small text-muted">{{ c.descriptionCircuit }}</p>
              <div class="small mb-1">⏱ {{ duree(c.dureeTotale) }} · 📍 {{ c.distanceTotale }} km</div>
              <div class="small">🧭 {{ c.etapes.length }} étape(s) · 👥 {{ c.capaciteMax }} personnes max</div>
            </a>
          </div>
        } @empty {
          <p class="text-muted">Aucun circuit disponible pour le moment.</p>
        }
      </div>
    </div>
  `,
})
export class CircuitsListComponent implements OnInit {
  private api = inject(ApiService);
  circuits = signal<Circuit[]>([]);
  erreur = signal('');
  duree = dureeLisible;

  ngOnInit(): void {
    this.api.circuits().subscribe({
      next: (l) => this.circuits.set(l),
      error: (e) => this.erreur.set(messageErreur(e)),
    });
  }
}
