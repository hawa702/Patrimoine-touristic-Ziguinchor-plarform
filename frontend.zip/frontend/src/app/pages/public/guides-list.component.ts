import { Component, OnInit, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { GuidePublic, Moyenne } from '../../core/models';
import { messageErreur, resume, versDictionnaire } from '../../core/util';
import { StarsComponent } from '../../shared/stars.component';

@Component({
  selector: 'app-guides-list',
  standalone: true,
  imports: [RouterLink, StarsComponent],
  template: `
    <div class="page-head">
      <div class="container">
        <h1>Nos guides</h1>
        <p class="text-muted mb-0">Des guides professionnels validés par le conservateur.</p>
      </div>
    </div>
    <div class="container">
      @if (erreur()) {
        <div class="alert alert-danger">{{ erreur() }}</div>
      }
      <div class="row g-4">
        @for (g of guides(); track g.id) {
          <div class="col-12 col-md-6 col-lg-4">
            <a class="panel d-block h-100 text-decoration-none text-reset site-card" [routerLink]="['/guides', g.id]">
              <h5 class="display-font mb-1">🧑‍🏫 {{ g.nom }}</h5>
              @if (g.langues) { <div class="small text-muted mb-2">Langues : {{ g.langues }}</div> }
              <p class="small">{{ extrait(g.biographie) }}</p>
              <app-stars [valeur]="moyennes()[g.id]?.moyenne ?? 0" [nombre]="moyennes()[g.id]?.nombre ?? 0" />
            </a>
          </div>
        } @empty {
          <p class="text-muted">Aucun guide validé pour le moment.</p>
        }
      </div>
    </div>
  `,
})
export class GuidesListComponent implements OnInit {
  private api = inject(ApiService);
  guides = signal<GuidePublic[]>([]);
  moyennes = signal<Record<number, Moyenne>>({});
  erreur = signal('');
  extrait = (t?: string) => resume(t, 120);

  ngOnInit(): void {
    this.api.guides().subscribe({
      next: (l) => this.guides.set(l),
      error: (e) => this.erreur.set(messageErreur(e)),
    });
    this.api.moyennes('GUIDE').subscribe({ next: (m) => this.moyennes.set(versDictionnaire(m)) });
  }
}
