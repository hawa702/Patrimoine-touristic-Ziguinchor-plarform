import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { Reservation } from '../../core/models';
import { messageErreur } from '../../core/util';

@Component({
  selector: 'app-tourist-dashboard',
  standalone: true,
  imports: [RouterLink, DatePipe],
  template: `
    <div class="container py-4">
      <h1 class="h3">Bonjour {{ auth.user()?.nom }} 👋</h1>
      <p class="text-muted">Vos réservations de circuits et de visites.</p>
      <div class="mb-3 d-flex gap-2 flex-wrap">
        <a class="btn btn-primary btn-sm" routerLink="/circuits">Voir les circuits</a>
        <a class="btn btn-outline-primary btn-sm" routerLink="/evenements">Voir le programme</a>
      </div>

      @if (erreur()) { <div class="alert alert-danger">{{ erreur() }}</div> }

      <div class="row g-3">
        @for (r of reservations(); track r.id) {
          <div class="col-12 col-lg-6">
            <div class="panel h-100">
              <div class="d-flex justify-content-between">
                <strong>{{ nom(r) }}</strong>
                <span class="badge" [class.text-bg-success]="r.statut === 'CONFIRMEE'" [class.text-bg-warning]="r.statut === 'EN_ATTENTE'" [class.text-bg-secondary]="r.statut === 'ANNULEE'">{{ r.statut }}</span>
              </div>
              <div class="small text-muted">
                {{ r.nombrePlaces }} place(s)
                @if (r.dateVisite) { · le {{ r.dateVisite | date: 'd MMMM y' }} }
              </div>
              <div class="mt-2 d-flex gap-2 flex-wrap">
                @if (r.statut === 'EN_ATTENTE') {
                  <button class="btn btn-sm btn-success" (click)="confirmer(r)">Confirmer</button>
                }
                @if (r.statut !== 'ANNULEE') {
                  <button class="btn btn-sm btn-outline-danger" (click)="annuler(r)">Annuler</button>
                }
                @if (r.statut === 'CONFIRMEE') {
                  <button class="btn btn-sm btn-outline-secondary" (click)="afficherQr(r)">QR code</button>
                }
                @if (r.typeReservation === 'CIRCUIT') {
                  <a class="btn btn-sm btn-link" [routerLink]="['/circuits', r.referenceId]">Voir</a>
                } @else {
                  <a class="btn btn-sm btn-link" [routerLink]="['/evenements', r.referenceId]">Voir</a>
                }
              </div>
              @if (qr()[r.id!]; as img) {
                <div class="mt-3 text-center"><img [src]="img" alt="QR code de la réservation" width="180" height="180"></div>
              }
            </div>
          </div>
        } @empty {
          <p class="text-muted">Vous n'avez pas encore de réservation.</p>
        }
      </div>
    </div>
  `,
})
export class TouristDashboardComponent implements OnInit {
  private api = inject(ApiService);
  auth = inject(AuthService);
  reservations = signal<Reservation[]>([]);
  noms = signal<Record<string, string>>({});
  qr = signal<Record<number, string>>({});
  erreur = signal('');

  nom(r: Reservation): string {
    return this.noms()[`${r.typeReservation}-${r.referenceId}`] ?? `${r.typeReservation === 'CIRCUIT' ? 'Circuit' : 'Évènement'} n°${r.referenceId}`;
  }

  ngOnInit(): void {
    this.charger();
    this.api.circuits().subscribe((l) => this.ajouterNoms('CIRCUIT', l.map((c) => [c.id!, c.nomCircuit])));
    this.api.evenements().subscribe((l) => this.ajouterNoms('EVENEMENT', l.map((e) => [e.id!, e.titre])));
  }

  private ajouterNoms(type: string, paires: (string | number)[][]): void {
    const copie = { ...this.noms() };
    for (const [id, titre] of paires) copie[`${type}-${id}`] = String(titre);
    this.noms.set(copie);
  }

  charger(): void {
    this.api.mesReservations().subscribe({
      next: (l) => this.reservations.set(l),
      error: (e) => this.erreur.set(messageErreur(e)),
    });
  }

  confirmer(r: Reservation): void {
    this.erreur.set('');
    this.api.confirmerReservation(r.id!).subscribe({ next: () => this.charger(), error: (e) => this.erreur.set(messageErreur(e)) });
  }

  annuler(r: Reservation): void {
    this.erreur.set('');
    this.api.annulerReservation(r.id!).subscribe({ next: () => this.charger(), error: (e) => this.erreur.set(messageErreur(e)) });
  }

  afficherQr(r: Reservation): void {
    this.api.qrCode(r.id!).subscribe({
      next: (q) => this.qr.set({ ...this.qr(), [r.id!]: q.qrCode }),
      error: (e) => this.erreur.set(messageErreur(e)),
    });
  }
}
