import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { Disponibilite, TypeReservation } from '../../core/models';
import { aujourdhui, messageErreur } from '../../core/util';

@Component({
  selector: 'app-reserver',
  standalone: true,
  imports: [FormsModule, RouterLink],
  template: `
    <div class="container py-4" style="max-width: 560px">
      <div class="panel">
        <h1 class="h3 mb-1">Réserver</h1>
        <p class="text-muted">{{ titre() }}</p>

        @if (erreur()) {
          <div class="alert alert-danger py-2">{{ erreur() }}</div>
        }

        <form (ngSubmit)="envoyer()" #f="ngForm">
          @if (type === 'CIRCUIT') {
            <div class="mb-3">
              <label class="form-label" for="date">Date de la visite</label>
              <input id="date" type="date" class="form-control" name="date" [(ngModel)]="date" [min]="min" required (ngModelChange)="majDispo()">
            </div>
          }
          <div class="mb-3">
            <label class="form-label" for="n">Nombre de places</label>
            <input id="n" type="number" class="form-control" name="places" [(ngModel)]="places" min="1" required (ngModelChange)="majDispo()">
          </div>

          @if (dispo(); as d) {
            <div class="alert py-2" [class.alert-success]="peutReserver()" [class.alert-warning]="!peutReserver()">
              {{ d.placesRestantes }} place(s) restante(s) sur {{ d.capacite }}.
              @if (!peutReserver()) { <br>Pas assez de places pour votre demande. }
            </div>
          }

          <button class="btn btn-accent w-100" type="submit" [disabled]="f.invalid || envoi() || !peutReserver()">Confirmer la demande</button>
          <div class="small text-muted mt-2">Votre réservation sera créée « en attente » ; vous pourrez la confirmer depuis votre espace pour obtenir votre QR code.</div>
        </form>
        <a class="small d-block mt-3" routerLink="/touriste">← Mon espace</a>
      </div>
    </div>
  `,
})
export class ReserverComponent implements OnInit {
  private api = inject(ApiService);
  private auth = inject(AuthService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  type: TypeReservation = 'EVENEMENT';
  refId = 0;
  min = aujourdhui();
  date = '';
  places = 1;
  titre = signal('');
  dispo = signal<Disponibilite | null>(null);
  envoi = signal(false);
  erreur = signal('');
  peutReserver = computed(() => {
    const d = this.dispo();
    return !d || (d.disponible && this.placesDemandees() <= d.placesRestantes);
  });
  private placesDemandees = signal(1);

  ngOnInit(): void {
    const p = this.route.snapshot.paramMap;
    this.type = p.get('type') === 'CIRCUIT' ? 'CIRCUIT' : 'EVENEMENT';
    this.refId = Number(p.get('id'));
    if (this.type === 'CIRCUIT') {
      this.api.circuit(this.refId).subscribe({
        next: (c) => this.titre.set(`Circuit : ${c.nomCircuit}`),
        error: (e) => this.erreur.set(messageErreur(e, 'Circuit introuvable.')),
      });
    } else {
      this.api.evenement(this.refId).subscribe({
        next: (e) => this.titre.set(`Évènement : ${e.titre}`),
        error: (e) => this.erreur.set(messageErreur(e, 'Évènement introuvable.')),
      });
      this.majDispo();
    }
  }

  majDispo(): void {
    this.placesDemandees.set(Number(this.places) || 1);
    if (this.type === 'CIRCUIT' && !this.date) return;
    this.api.disponibilite(this.type, this.refId, this.type === 'CIRCUIT' ? this.date : undefined).subscribe({
      next: (d) => this.dispo.set(d),
      error: () => this.dispo.set(null),
    });
  }

  envoyer(): void {
    this.erreur.set('');
    this.envoi.set(true);
    this.api
      .creerReservation({
        typeReservation: this.type,
        referenceId: this.refId,
        nomClient: this.auth.user()?.nom ?? '',
        nombrePlaces: Number(this.places),
        dateVisite: this.type === 'CIRCUIT' ? this.date : null,
      })
      .subscribe({
        next: () => void this.router.navigateByUrl('/touriste'),
        error: (e) => {
          this.envoi.set(false);
          this.erreur.set(messageErreur(e, 'Réservation impossible.'));
        },
      });
  }
}
