import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { GuideAdmin } from '../../core/models';
import { messageErreur } from '../../core/util';
import { AdminNavComponent } from '../../shared/space-nav.component';

@Component({
  selector: 'app-admin-guides',
  standalone: true,
  imports: [DatePipe, AdminNavComponent],
  template: `
    <div class="container py-4">
      <h1 class="h3 mb-3">Validation des guides</h1>
      <app-admin-nav />
      @if (erreur()) { <div class="alert alert-danger">{{ erreur() }}</div> }
      <div class="row g-3">
        @for (g of guides(); track g.id) {
          <div class="col-12 col-lg-6">
            <div class="panel">
              <strong>{{ g.nom }}</strong> <span class="text-muted small">{{ g.email }}</span>
              <div class="small">Licence : {{ g.numeroLicence }} @if (g.langues) { · {{ g.langues }} }</div>
              @if (g.dateCreation) { <div class="small text-muted">Inscrit le {{ g.dateCreation | date: 'd MMM y' }}</div> }
              <p class="small mt-2 mb-2">{{ g.biographie }}</p>
              <button class="btn btn-sm btn-success" (click)="valider(g)">Valider</button>
              <button class="btn btn-sm btn-outline-danger ms-1" (click)="refuser(g)">Refuser</button>
            </div>
          </div>
        } @empty {
          <p class="text-muted">Aucune demande en attente.</p>
        }
      </div>
    </div>
  `,
})
export class AdminGuidesComponent implements OnInit {
  private api = inject(ApiService);
  guides = signal<GuideAdmin[]>([]);
  erreur = signal('');

  ngOnInit(): void {
    this.charger();
  }

  charger(): void {
    this.api.guidesEnAttente().subscribe({ next: (l) => this.guides.set(l), error: (e) => this.erreur.set(messageErreur(e)) });
  }

  valider(g: GuideAdmin): void {
    this.api.validerGuide(g.id).subscribe({ next: () => this.charger(), error: (e) => this.erreur.set(messageErreur(e)) });
  }

  refuser(g: GuideAdmin): void {
    if (!confirm(`Refuser ${g.nom} ? Son compte sera désactivé.`)) return;
    this.api.refuserGuide(g.id).subscribe({ next: () => this.charger(), error: (e) => this.erreur.set(messageErreur(e)) });
  }
}
