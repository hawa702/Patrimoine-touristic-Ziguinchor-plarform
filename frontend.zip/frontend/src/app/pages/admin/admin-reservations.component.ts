import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { Reservation } from '../../core/models';
import { messageErreur } from '../../core/util';
import { AdminNavComponent } from '../../shared/space-nav.component';

@Component({
  selector: 'app-admin-reservations',
  standalone: true,
  imports: [DatePipe, AdminNavComponent],
  template: `
    <div class="container py-4">
      <h1 class="h3 mb-3">Réservations</h1>
      <app-admin-nav />
      @if (erreur()) { <div class="alert alert-danger">{{ erreur() }}</div> }
      <div class="table-responsive panel">
        <table class="table table-sm align-middle mb-0">
          <thead><tr><th>#</th><th>Client</th><th>Objet</th><th>Places</th><th>Date</th><th>Statut</th><th></th></tr></thead>
          <tbody>
            @for (r of reservations(); track r.id) {
              <tr>
                <td>{{ r.id }}</td>
                <td>{{ r.nomClient }}<div class="small text-muted">{{ r.email }}</div></td>
                <td>{{ r.typeReservation }} n°{{ r.referenceId }}</td>
                <td>{{ r.nombrePlaces }}</td>
                <td>{{ r.dateVisite ? (r.dateVisite | date: 'd/MM/y') : '—' }}</td>
                <td><span class="badge" [class.text-bg-success]="r.statut === 'CONFIRMEE'" [class.text-bg-warning]="r.statut === 'EN_ATTENTE'" [class.text-bg-secondary]="r.statut === 'ANNULEE'">{{ r.statut }}</span></td>
                <td class="text-end text-nowrap">
                  @if (r.statut === 'EN_ATTENTE') { <button class="btn btn-sm btn-outline-success" (click)="confirmer(r)">Confirmer</button> }
                  @if (r.statut !== 'ANNULEE') { <button class="btn btn-sm btn-outline-danger ms-1" (click)="annuler(r)">Annuler</button> }
                </td>
              </tr>
            } @empty {
              <tr><td colspan="7" class="text-muted">Aucune réservation.</td></tr>
            }
          </tbody>
        </table>
      </div>
    </div>
  `,
})
export class AdminReservationsComponent implements OnInit {
  private api = inject(ApiService);
  reservations = signal<Reservation[]>([]);
  erreur = signal('');

  ngOnInit(): void {
    this.charger();
  }

  charger(): void {
    this.api.toutesLesReservations().subscribe({
      next: (l) => this.reservations.set([...l].sort((a, b) => (b.id ?? 0) - (a.id ?? 0))),
      error: (e) => this.erreur.set(messageErreur(e)),
    });
  }

  confirmer(r: Reservation): void {
    this.api.confirmerReservation(r.id!).subscribe({ next: () => this.charger(), error: (e) => this.erreur.set(messageErreur(e)) });
  }

  annuler(r: Reservation): void {
    this.api.annulerReservation(r.id!).subscribe({ next: () => this.charger(), error: (e) => this.erreur.set(messageErreur(e)) });
  }
}
