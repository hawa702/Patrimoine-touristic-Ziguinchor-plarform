import { DatePipe } from '@angular/common';
import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { Signalement } from '../../core/models';
import { messageErreur } from '../../core/util';
import { AdminNavComponent } from '../../shared/space-nav.component';

@Component({
  selector: 'app-admin-moderation',
  standalone: true,
  imports: [DatePipe, AdminNavComponent],
  template: `
    <div class="container py-4">
      <h1 class="h3 mb-3">Modération des avis</h1>
      <app-admin-nav />
      @if (erreur()) { <div class="alert alert-danger">{{ erreur() }}</div> }
      @for (s of enAttente(); track s.id) {
        <div class="panel mb-3">
          <div class="small text-muted">Signalé le {{ s.dateSignalement | date: 'd MMM y' }}</div>
          <div class="mb-2"><strong>Motif :</strong> {{ s.motif }}</div>
          @if (s.avis; as a) {
            <blockquote class="border-start border-3 ps-3 mb-2">
              <div class="small text-muted">{{ a.auteurNom }} — {{ a.cibleType }} n°{{ a.cibleId }} — note {{ a.note }}/5</div>
              {{ a.commentaire }}
            </blockquote>
          } @else {
            <div class="small text-muted mb-2">L'avis n'existe plus.</div>
          }
          <button class="btn btn-sm btn-danger" (click)="resoudre(s, true)" [disabled]="!s.avis">Supprimer l'avis</button>
          <button class="btn btn-sm btn-outline-secondary ms-1" (click)="resoudre(s, false)">Conserver l'avis</button>
        </div>
      } @empty {
        <p class="text-muted">Aucun signalement en attente.</p>
      }
    </div>
  `,
})
export class AdminModerationComponent implements OnInit {
  private api = inject(ApiService);
  signalements = signal<Signalement[]>([]);
  enAttente = computed(() => this.signalements().filter((s) => s.statut === 'EN_ATTENTE'));
  erreur = signal('');

  ngOnInit(): void {
    this.charger();
  }

  charger(): void {
    this.api.signalements().subscribe({ next: (l) => this.signalements.set(l), error: (e) => this.erreur.set(messageErreur(e)) });
  }

  resoudre(s: Signalement, supprimer: boolean): void {
    this.api.resoudreSignalement(s.id, supprimer).subscribe({ next: () => this.charger(), error: (e) => this.erreur.set(messageErreur(e)) });
  }
}
