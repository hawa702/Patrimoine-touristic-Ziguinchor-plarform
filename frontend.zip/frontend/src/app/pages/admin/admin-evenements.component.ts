import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { Evenement, GuidePublic, Patrimoine } from '../../core/models';
import { messageErreur } from '../../core/util';
import { AdminNavComponent } from '../../shared/space-nav.component';

const vide = (): Evenement => ({
  titre: '', description: '', type: 'VISITE_GUIDEE', dateDebut: '', dateFin: '', lieu: '',
  patrimoineId: null, placesMax: 20, guideId: null, guideNom: null,
});

@Component({
  selector: 'app-admin-evenements',
  standalone: true,
  imports: [FormsModule, DatePipe, AdminNavComponent],
  template: `
    <div class="container py-4">
      <h1 class="h3 mb-3">Visites guidées & évènements</h1>
      <app-admin-nav />
      @if (erreur()) { <div class="alert alert-danger">{{ erreur() }}</div> }
      @if (info()) { <div class="alert alert-success">{{ info() }}</div> }

      <div class="row g-4">
        <div class="col-12 col-lg-5">
          <div class="panel">
            <h2 class="h5">{{ form.id ? 'Modifier' : 'Nouvel évènement' }}</h2>
            <form (ngSubmit)="enregistrer()" #f="ngForm">
              <div class="mb-2"><label class="form-label small" for="titre">Titre</label>
                <input id="titre" class="form-control form-control-sm" name="titre" [(ngModel)]="form.titre" required></div>
              <div class="row g-2 mb-2">
                <div class="col-6"><label class="form-label small" for="type">Type</label>
                  <select id="type" class="form-select form-select-sm" name="type" [(ngModel)]="form.type">
                    <option value="VISITE_GUIDEE">Visite guidée</option>
                    <option value="EXPOSITION">Exposition</option>
                    <option value="ATELIER">Atelier</option>
                  </select></div>
                <div class="col-6"><label class="form-label small" for="pl">Places max</label>
                  <input id="pl" type="number" min="1" class="form-control form-control-sm" name="pl" [(ngModel)]="form.placesMax" required></div>
              </div>
              <div class="row g-2 mb-2">
                <div class="col-6"><label class="form-label small" for="d1">Début</label>
                  <input id="d1" type="datetime-local" class="form-control form-control-sm" name="d1" [(ngModel)]="form.dateDebut" required></div>
                <div class="col-6"><label class="form-label small" for="d2">Fin</label>
                  <input id="d2" type="datetime-local" class="form-control form-control-sm" name="d2" [(ngModel)]="form.dateFin" required></div>
              </div>
              <div class="mb-2"><label class="form-label small" for="lieu">Lieu</label>
                <input id="lieu" class="form-control form-control-sm" name="lieu" [(ngModel)]="form.lieu"></div>
              <div class="mb-2"><label class="form-label small" for="site">Site associé</label>
                <select id="site" class="form-select form-select-sm" name="site" [(ngModel)]="form.patrimoineId">
                  <option [ngValue]="null">— Aucun —</option>
                  @for (s of sites(); track s.id) { <option [ngValue]="s.id">{{ s.nomPatrimoine }}</option> }
                </select></div>
              @if (form.type === 'VISITE_GUIDEE') {
                <div class="mb-2"><label class="form-label small" for="guide">Guide affecté</label>
                  <select id="guide" class="form-select form-select-sm" name="guide" [(ngModel)]="form.guideId" (ngModelChange)="choisirGuide($event)">
                    <option [ngValue]="null">— Non affecté —</option>
                    @for (g of guides(); track g.id) { <option [ngValue]="g.id">{{ g.nom }}</option> }
                  </select></div>
              }
              <div class="mb-3"><label class="form-label small" for="desc">Description</label>
                <textarea id="desc" rows="3" class="form-control form-control-sm" name="desc" [(ngModel)]="form.description" maxlength="2000"></textarea></div>
              <button class="btn btn-primary btn-sm" type="submit" [disabled]="f.invalid">{{ form.id ? 'Enregistrer' : 'Créer' }}</button>
              @if (form.id) { <button class="btn btn-link btn-sm" type="button" (click)="nouveau()">Annuler</button> }
            </form>
          </div>
        </div>
        <div class="col-12 col-lg-7">
          <div class="table-responsive panel">
            <table class="table table-sm align-middle mb-0">
              <thead><tr><th>Titre</th><th>Date</th><th>Guide</th><th></th></tr></thead>
              <tbody>
                @for (e of evenements(); track e.id) {
                  <tr>
                    <td>{{ e.titre }}<div class="small text-muted">{{ e.type }}</div></td>
                    <td class="small">{{ e.dateDebut | date: 'd/MM/y HH:mm' }}</td>
                    <td class="small">{{ e.guideNom ?? '—' }}</td>
                    <td class="text-end text-nowrap">
                      <button class="btn btn-sm btn-outline-secondary" (click)="editer(e)">Modifier</button>
                      <button class="btn btn-sm btn-outline-danger" (click)="supprimer(e)">Supprimer</button>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class AdminEvenementsComponent implements OnInit {
  private api = inject(ApiService);
  evenements = signal<Evenement[]>([]);
  sites = signal<Patrimoine[]>([]);
  guides = signal<GuidePublic[]>([]);
  erreur = signal('');
  info = signal('');
  form: Evenement = vide();

  ngOnInit(): void {
    this.charger();
    this.api.patrimoines().subscribe({ next: (l) => this.sites.set(l) });
    this.api.guides().subscribe({ next: (l) => this.guides.set(l) });
  }

  charger(): void {
    this.api.evenements().subscribe({
      next: (l) => this.evenements.set([...l].sort((a, b) => b.dateDebut.localeCompare(a.dateDebut))),
      error: (e) => this.erreur.set(messageErreur(e)),
    });
  }

  choisirGuide(id: number | null): void {
    this.form.guideNom = this.guides().find((g) => g.id === id)?.nom ?? null;
  }

  nouveau(): void {
    this.form = vide();
  }

  editer(e: Evenement): void {
    // datetime-local attend yyyy-MM-ddTHH:mm
    this.form = { ...e, dateDebut: e.dateDebut.slice(0, 16), dateFin: e.dateFin.slice(0, 16) };
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  enregistrer(): void {
    this.erreur.set('');
    this.info.set('');
    const p: Evenement = {
      ...this.form,
      guideId: this.form.type === 'VISITE_GUIDEE' ? this.form.guideId : null,
      guideNom: this.form.type === 'VISITE_GUIDEE' ? this.form.guideNom : null,
    };
    const appel = p.id ? this.api.modifierEvenement(p.id, p) : this.api.creerEvenement(p);
    appel.subscribe({
      next: () => {
        this.info.set('Évènement enregistré.');
        this.nouveau();
        this.charger();
      },
      error: (e) => this.erreur.set(messageErreur(e)),
    });
  }

  supprimer(e: Evenement): void {
    if (!confirm(`Supprimer « ${e.titre} » ?`)) return;
    this.api.supprimerEvenement(e.id!).subscribe({ next: () => this.charger(), error: (x) => this.erreur.set(messageErreur(x)) });
  }
}
