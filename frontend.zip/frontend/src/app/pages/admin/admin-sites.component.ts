import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { Patrimoine } from '../../core/models';
import { TYPES_SITE, messageErreur } from '../../core/util';
import { AdminNavComponent } from '../../shared/space-nav.component';

const VIDE: Patrimoine = {
  nomPatrimoine: '', codePatrimoine: '', descriptionPatrimoine: '', historiquePatrimoine: '', adressePatrimoine: '',
  capacitePatrimoine: 50, latitudePatrimoine: 12.5833, longitudePatrimoine: -16.2719,
  villePatrimoine: 'Ziguinchor', typePatrimoine: 'MONUMENT', horairesPatrimoine: '', imageUrl: '',
};

@Component({
  selector: 'app-admin-sites',
  standalone: true,
  imports: [FormsModule, AdminNavComponent],
  template: `
    <div class="container py-4">
      <h1 class="h3 mb-3">Sites du patrimoine</h1>
      <app-admin-nav />
      @if (erreur()) { <div class="alert alert-danger">{{ erreur() }}</div> }
      @if (info()) { <div class="alert alert-success">{{ info() }}</div> }

      <div class="row g-4">
        <div class="col-12 col-lg-5">
          <div class="panel">
            <h2 class="h5">{{ form.id ? 'Modifier le site' : 'Nouveau site' }}</h2>
            <form (ngSubmit)="enregistrer()" #f="ngForm">
              <div class="mb-2"><label class="form-label small" for="nom">Nom</label>
                <input id="nom" class="form-control form-control-sm" name="nom" [(ngModel)]="form.nomPatrimoine" required></div>
              <div class="row g-2 mb-2">
                <div class="col-6"><label class="form-label small" for="code">Code</label>
                  <input id="code" class="form-control form-control-sm" name="code" [(ngModel)]="form.codePatrimoine"></div>
                <div class="col-6"><label class="form-label small" for="type">Type</label>
                  <select id="type" class="form-select form-select-sm" name="type" [(ngModel)]="form.typePatrimoine">
                    @for (t of types; track t.value) { <option [value]="t.value">{{ t.label }}</option> }
                  </select></div>
              </div>
              <div class="row g-2 mb-2">
                <div class="col-6"><label class="form-label small" for="ville">Ville</label>
                  <input id="ville" class="form-control form-control-sm" name="ville" [(ngModel)]="form.villePatrimoine"></div>
                <div class="col-6"><label class="form-label small" for="cap">Capacité</label>
                  <input id="cap" type="number" min="1" class="form-control form-control-sm" name="cap" [(ngModel)]="form.capacitePatrimoine" required></div>
              </div>
              <div class="mb-2"><label class="form-label small" for="adr">Adresse</label>
                <input id="adr" class="form-control form-control-sm" name="adr" [(ngModel)]="form.adressePatrimoine"></div>
              <div class="row g-2 mb-2">
                <div class="col-6"><label class="form-label small" for="lat">Latitude</label>
                  <input id="lat" type="number" step="any" class="form-control form-control-sm" name="lat" [(ngModel)]="form.latitudePatrimoine" required></div>
                <div class="col-6"><label class="form-label small" for="lon">Longitude</label>
                  <input id="lon" type="number" step="any" class="form-control form-control-sm" name="lon" [(ngModel)]="form.longitudePatrimoine" required></div>
              </div>
              <div class="mb-2"><label class="form-label small" for="hor">Horaires d'ouverture</label>
                <input id="hor" class="form-control form-control-sm" name="hor" [(ngModel)]="form.horairesPatrimoine" placeholder="Lun-Sam 9h-17h"></div>
              <div class="mb-2"><label class="form-label small" for="img">Image (URL)</label>
                <input id="img" class="form-control form-control-sm" name="img" [(ngModel)]="form.imageUrl" placeholder="/images/… ou https://…"></div>
              <div class="mb-2"><label class="form-label small" for="desc">Description</label>
                <textarea id="desc" rows="3" class="form-control form-control-sm" name="desc" [(ngModel)]="form.descriptionPatrimoine" maxlength="2000"></textarea></div>
              <div class="mb-3"><label class="form-label small" for="hist">Historique</label>
                <textarea id="hist" rows="4" class="form-control form-control-sm" name="hist" [(ngModel)]="form.historiquePatrimoine" maxlength="4000"></textarea></div>
              <button class="btn btn-primary btn-sm" type="submit" [disabled]="f.invalid">{{ form.id ? 'Enregistrer' : 'Créer' }}</button>
              @if (form.id) { <button class="btn btn-link btn-sm" type="button" (click)="nouveau()">Annuler</button> }
            </form>
          </div>
        </div>
        <div class="col-12 col-lg-7">
          <div class="table-responsive panel">
            <table class="table table-sm align-middle mb-0">
              <thead><tr><th>Nom</th><th>Ville</th><th>Type</th><th></th></tr></thead>
              <tbody>
                @for (s of sites(); track s.id) {
                  <tr>
                    <td>{{ s.nomPatrimoine }}</td><td>{{ s.villePatrimoine }}</td><td>{{ s.typePatrimoine }}</td>
                    <td class="text-end text-nowrap">
                      <button class="btn btn-sm btn-outline-secondary" (click)="editer(s)">Modifier</button>
                      <button class="btn btn-sm btn-outline-danger" (click)="supprimer(s)">Supprimer</button>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class AdminSitesComponent implements OnInit {
  private api = inject(ApiService);
  sites = signal<Patrimoine[]>([]);
  erreur = signal('');
  info = signal('');
  types = TYPES_SITE;
  form: Patrimoine = { ...VIDE };

  ngOnInit(): void {
    this.charger();
  }

  charger(): void {
    this.api.patrimoines().subscribe({ next: (l) => this.sites.set(l), error: (e) => this.erreur.set(messageErreur(e)) });
  }

  nouveau(): void {
    this.form = { ...VIDE };
  }

  editer(s: Patrimoine): void {
    this.form = { ...s };
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  enregistrer(): void {
    this.erreur.set('');
    this.info.set('');
    const appel = this.form.id ? this.api.modifierPatrimoine(this.form.id, this.form) : this.api.creerPatrimoine(this.form);
    appel.subscribe({
      next: () => {
        this.info.set('Site enregistré.');
        this.nouveau();
        this.charger();
      },
      error: (e) => this.erreur.set(messageErreur(e)),
    });
  }

  supprimer(s: Patrimoine): void {
    if (!confirm(`Supprimer « ${s.nomPatrimoine} » ?`)) return;
    this.api.supprimerPatrimoine(s.id!).subscribe({
      next: () => this.charger(),
      error: (e) => this.erreur.set(messageErreur(e)),
    });
  }
}
