import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { Circuit, Difficulte, Patrimoine } from '../../core/models';
import { messageErreur } from '../../core/util';
import { AdminNavComponent } from '../../shared/space-nav.component';

const vide = (): Circuit => ({
  codeCircuit: '', nomCircuit: '', descriptionCircuit: '', dureeTotale: 120, distanceTotale: 5,
  difficulte: 'FACILE', capaciteMax: 20, etapes: [],
});

@Component({
  selector: 'app-admin-circuits',
  standalone: true,
  imports: [FormsModule, AdminNavComponent],
  template: `
    <div class="container py-4">
      <h1 class="h3 mb-3">Circuits</h1>
      <app-admin-nav />
      @if (erreur()) { <div class="alert alert-danger">{{ erreur() }}</div> }
      @if (info()) { <div class="alert alert-success">{{ info() }}</div> }

      <div class="row g-4">
        <div class="col-12 col-lg-6">
          <div class="panel">
            <h2 class="h5">{{ form.id ? 'Modifier le circuit' : 'Nouveau circuit' }}</h2>
            <form (ngSubmit)="enregistrer()" #f="ngForm">
              <div class="row g-2 mb-2">
                <div class="col-4"><label class="form-label small" for="code">Code</label>
                  <input id="code" class="form-control form-control-sm" name="code" [(ngModel)]="form.codeCircuit" required></div>
                <div class="col-8"><label class="form-label small" for="nom">Nom</label>
                  <input id="nom" class="form-control form-control-sm" name="nom" [(ngModel)]="form.nomCircuit" required></div>
              </div>
              <div class="mb-2"><label class="form-label small" for="desc">Description</label>
                <textarea id="desc" rows="2" class="form-control form-control-sm" name="desc" [(ngModel)]="form.descriptionCircuit"></textarea></div>
              <div class="row g-2 mb-2">
                <div class="col-6 col-md-3"><label class="form-label small" for="dur">Durée (min)</label>
                  <input id="dur" type="number" min="1" class="form-control form-control-sm" name="dur" [(ngModel)]="form.dureeTotale" required></div>
                <div class="col-6 col-md-3"><label class="form-label small" for="dist">Distance (km)</label>
                  <input id="dist" type="number" min="0" step="any" class="form-control form-control-sm" name="dist" [(ngModel)]="form.distanceTotale" required></div>
                <div class="col-6 col-md-3"><label class="form-label small" for="dif">Difficulté</label>
                  <select id="dif" class="form-select form-select-sm" name="dif" [(ngModel)]="form.difficulte">
                    @for (d of difficultes; track d) { <option [value]="d">{{ d }}</option> }
                  </select></div>
                <div class="col-6 col-md-3"><label class="form-label small" for="cap">Capacité</label>
                  <input id="cap" type="number" min="1" class="form-control form-control-sm" name="cap" [(ngModel)]="form.capaciteMax" required></div>
              </div>

              <h3 class="h6 mt-3">Étapes</h3>
              @for (e of form.etapes; track $index; let i = $index) {
                <div class="row g-2 mb-2 align-items-end">
                  <div class="col-7">
                    <select class="form-select form-select-sm" [name]="'site' + i" [(ngModel)]="e.patrimoineId" required>
                      <option [ngValue]="0" disabled>Choisir un site…</option>
                      @for (s of sites(); track s.id) { <option [ngValue]="s.id">{{ s.nomPatrimoine }}</option> }
                    </select>
                  </div>
                  <div class="col-3">
                    <input type="number" min="1" class="form-control form-control-sm" [name]="'dur' + i" [(ngModel)]="e.dureeEstime" title="Durée (min)" required>
                  </div>
                  <div class="col-2"><button class="btn btn-sm btn-outline-danger w-100" type="button" (click)="retirer(i)">✕</button></div>
                </div>
              }
              <button class="btn btn-sm btn-outline-secondary mb-3" type="button" (click)="ajouterEtape()">+ Ajouter une étape</button>
              <div>
                <button class="btn btn-primary btn-sm" type="submit" [disabled]="f.invalid">{{ form.id ? 'Enregistrer' : 'Créer' }}</button>
                @if (form.id) { <button class="btn btn-link btn-sm" type="button" (click)="nouveau()">Annuler</button> }
              </div>
            </form>
          </div>
        </div>
        <div class="col-12 col-lg-6">
          <div class="table-responsive panel">
            <table class="table table-sm align-middle mb-0">
              <thead><tr><th>Circuit</th><th>Étapes</th><th></th></tr></thead>
              <tbody>
                @for (c of circuits(); track c.id) {
                  <tr>
                    <td>{{ c.nomCircuit }}<div class="small text-muted">{{ c.codeCircuit }}</div></td>
                    <td>{{ c.etapes.length }}</td>
                    <td class="text-end text-nowrap">
                      <button class="btn btn-sm btn-outline-secondary" (click)="editer(c)">Modifier</button>
                      <button class="btn btn-sm btn-outline-danger" (click)="supprimer(c)">Supprimer</button>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class AdminCircuitsComponent implements OnInit {
  private api = inject(ApiService);
  circuits = signal<Circuit[]>([]);
  sites = signal<Patrimoine[]>([]);
  erreur = signal('');
  info = signal('');
  difficultes: Difficulte[] = ['FACILE', 'MOYEN', 'DIFFICILE'];
  form: Circuit = vide();

  ngOnInit(): void {
    this.charger();
    this.api.patrimoines().subscribe({ next: (l) => this.sites.set(l) });
  }

  charger(): void {
    this.api.circuits().subscribe({ next: (l) => this.circuits.set(l), error: (e) => this.erreur.set(messageErreur(e)) });
  }

  nouveau(): void {
    this.form = vide();
  }

  editer(c: Circuit): void {
    this.form = { ...c, etapes: c.etapes.map((e) => ({ ...e })) };
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  ajouterEtape(): void {
    this.form.etapes = [...this.form.etapes, { position: this.form.etapes.length + 1, dureeEstime: 30, patrimoineId: 0 }];
  }

  retirer(i: number): void {
    this.form.etapes = this.form.etapes.filter((_, k) => k !== i);
  }

  enregistrer(): void {
    this.erreur.set('');
    this.info.set('');
    const payload: Circuit = {
      ...this.form,
      etapes: this.form.etapes.map((e, i) => ({ position: i + 1, dureeEstime: Number(e.dureeEstime), patrimoineId: Number(e.patrimoineId) })),
    };
    const appel = this.form.id ? this.api.modifierCircuit(this.form.id, payload) : this.api.creerCircuit(payload);
    appel.subscribe({
      next: () => {
        this.info.set('Circuit enregistré.');
        this.nouveau();
        this.charger();
      },
      error: (e) => this.erreur.set(messageErreur(e)),
    });
  }

  supprimer(c: Circuit): void {
    if (!confirm(`Supprimer le circuit « ${c.nomCircuit} » ?`)) return;
    this.api.supprimerCircuit(c.id!).subscribe({ next: () => this.charger(), error: (e) => this.erreur.set(messageErreur(e)) });
  }
}
