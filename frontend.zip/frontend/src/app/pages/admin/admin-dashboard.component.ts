import { Component, OnInit, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { forkJoin } from 'rxjs';
import { ApiService } from '../../core/api.service';
import { dansNJours, messageErreur } from '../../core/util';
import { AdminNavComponent } from '../../shared/space-nav.component';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [RouterLink, AdminNavComponent],
  template: `
    <div class="container py-4">
      <h1 class="h3 mb-3">Espace conservateur</h1>
      <app-admin-nav />
      @if (erreur()) { <div class="alert alert-danger">{{ erreur() }}</div> }
      @if (info()) { <div class="alert alert-success">{{ info() }}</div> }

      <div class="row g-3 mb-4">
        @for (s of stats(); track s.label) {
          <div class="col-6 col-md-4 col-lg-2">
            <a class="panel stat d-block text-decoration-none text-reset" [routerLink]="s.lien">
              <div class="n">{{ s.n }}</div>
              <div class="small text-muted">{{ s.label }}</div>
            </a>
          </div>
        }
      </div>

      <div class="panel">
        <h2 class="h5">Données de démonstration</h2>
        <p class="small text-muted">Crée 1 circuit reliant les sites existants et 3 évènements à venir, pour tester rapidement les réservations.</p>
        <button class="btn btn-outline-primary btn-sm" (click)="demo()" [disabled]="occupe()">Générer</button>
      </div>
    </div>
  `,
})
export class AdminDashboardComponent implements OnInit {
  private api = inject(ApiService);
  stats = signal<{ label: string; n: number; lien: string }[]>([]);
  erreur = signal('');
  info = signal('');
  occupe = signal(false);

  ngOnInit(): void {
    this.charger();
  }

  charger(): void {
    forkJoin({
      sites: this.api.patrimoines(),
      circuits: this.api.circuits(),
      evenements: this.api.evenements(),
      attente: this.api.guidesEnAttente(),
      signalements: this.api.signalements(),
      reservations: this.api.toutesLesReservations(),
    }).subscribe({
      next: (r) =>
        this.stats.set([
          { label: 'Sites', n: r.sites.length, lien: '/admin/sites' },
          { label: 'Circuits', n: r.circuits.length, lien: '/admin/circuits' },
          { label: 'Évènements', n: r.evenements.length, lien: '/admin/evenements' },
          { label: 'Guides à valider', n: r.attente.length, lien: '/admin/guides' },
          { label: 'Réservations', n: r.reservations.length, lien: '/admin/reservations' },
          { label: 'Signalements', n: r.signalements.filter((s) => s.statut === 'EN_ATTENTE').length, lien: '/admin/moderation' },
        ]),
      error: (e) => this.erreur.set(messageErreur(e)),
    });
  }

  demo(): void {
    this.occupe.set(true);
    this.erreur.set('');
    this.api.patrimoines().subscribe({
      next: (sites) => {
        const ids = sites.slice(0, 3).map((s) => s.id!);
        if (!ids.length) {
          this.occupe.set(false);
          this.erreur.set("Aucun site : créez d'abord un site.");
          return;
        }
        const suffixe = Date.now().toString().slice(-5);
        forkJoin([
          this.api.creerCircuit({
            codeCircuit: `DEMO-${suffixe}`,
            nomCircuit: 'Circuit découverte de Ziguinchor',
            descriptionCircuit: 'Parcours de démonstration à travers les sites emblématiques de la ville.',
            dureeTotale: 180,
            distanceTotale: 6,
            difficulte: 'FACILE',
            capaciteMax: 20,
            etapes: ids.map((id, i) => ({ position: i + 1, dureeEstime: 60, patrimoineId: id })),
          }),
          this.api.creerEvenement({ titre: 'Visite guidée du centre historique', description: 'Visite commentée de démonstration.', type: 'VISITE_GUIDEE', dateDebut: dansNJours(2, '09:00'), dateFin: dansNJours(2, '11:00'), lieu: 'Centre-ville', patrimoineId: ids[0], placesMax: 15, guideId: null, guideNom: null }),
          this.api.creerEvenement({ titre: 'Exposition d\'art casamançais', description: 'Exposition de démonstration.', type: 'EXPOSITION', dateDebut: dansNJours(5, '10:00'), dateFin: dansNJours(5, '17:00'), lieu: 'Musée', patrimoineId: ids[ids.length - 1], placesMax: 40, guideId: null, guideNom: null }),
          this.api.creerEvenement({ titre: 'Atelier de vannerie', description: 'Atelier de démonstration.', type: 'ATELIER', dateDebut: dansNJours(7, '15:00'), dateFin: dansNJours(7, '17:00'), lieu: 'Alliance franco-sénégalaise', patrimoineId: ids[0], placesMax: 12, guideId: null, guideNom: null }),
        ]).subscribe({
          next: () => {
            this.occupe.set(false);
            this.info.set('Données de démonstration créées.');
            this.charger();
          },
          error: (e) => {
            this.occupe.set(false);
            this.erreur.set(messageErreur(e));
          },
        });
      },
      error: (e) => {
        this.occupe.set(false);
        this.erreur.set(messageErreur(e));
      },
    });
  }
}
