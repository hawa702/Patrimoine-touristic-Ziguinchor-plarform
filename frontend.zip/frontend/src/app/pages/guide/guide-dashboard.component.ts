import { DatePipe } from '@angular/common';
import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { Evenement, GuideAdmin, Moyenne } from '../../core/models';
import { messageErreur } from '../../core/util';
import { GuideNavComponent } from '../../shared/space-nav.component';
import { StarsComponent } from '../../shared/stars.component';

@Component({
  selector: 'app-guide-dashboard',
  standalone: true,
  imports: [RouterLink, DatePipe, GuideNavComponent, StarsComponent],
  template: `
    <div class="container py-4">
      <h1 class="h3 mb-3">Espace guide — {{ auth.user()?.nom }}</h1>
      <app-guide-nav />

      @if (erreur()) { <div class="alert alert-danger">{{ erreur() }}</div> }

      @if (profil(); as p) {
        @if (!p.estVerifie) {
          <div class="alert alert-warning">Votre compte est <strong>en attente de validation</strong> par le conservateur. Vous n'apparaissez pas encore dans l'annuaire.</div>
        } @else {
          <div class="alert alert-success py-2">Compte validé ✔</div>
        }
      }

      <div class="row g-4">
        <div class="col-12 col-lg-4">
          <div class="panel text-center">
            <div class="small text-muted mb-1">Ma note moyenne</div>
            <app-stars [valeur]="moyenne()?.moyenne ?? 0" [nombre]="moyenne()?.nombre ?? 0" />
            <a class="d-block small mt-2" routerLink="/guide/avis">Lire et répondre aux avis</a>
          </div>
        </div>
        <div class="col-12 col-lg-8">
          <div class="panel mb-3">
            <h2 class="h5">Aujourd'hui</h2>
            @for (e of duJour(); track e.id) {
              <div class="py-1">{{ e.dateDebut | date: 'HH:mm' }} — <strong>{{ e.titre }}</strong> <span class="text-muted small">({{ e.lieu }})</span></div>
            } @empty { <p class="small text-muted mb-0">Aucune visite aujourd'hui.</p> }
          </div>
          <div class="panel">
            <h2 class="h5">Prochaines visites</h2>
            @for (e of avenir(); track e.id) {
              <a class="d-block py-2 border-bottom text-decoration-none" [routerLink]="['/evenements', e.id]">
                <strong>{{ e.titre }}</strong>
                <div class="small text-muted">{{ e.dateDebut | date: 'EEEE d MMMM y, HH:mm' }} · {{ e.placesMax }} places</div>
              </a>
            } @empty { <p class="small text-muted mb-0">Aucune visite programmée. Le conservateur vous les affecte.</p> }
          </div>
        </div>
      </div>
    </div>
  `,
})
export class GuideDashboardComponent implements OnInit {
  private api = inject(ApiService);
  auth = inject(AuthService);
  profil = signal<GuideAdmin | null>(null);
  evenements = signal<Evenement[]>([]);
  moyenne = signal<Moyenne | null>(null);
  erreur = signal('');

  duJour = computed(() => this.evenements().filter((e) => new Date(e.dateDebut).toDateString() === new Date().toDateString()));
  avenir = computed(() =>
    this.evenements()
      .filter((e) => new Date(e.dateDebut).getTime() > Date.now() && new Date(e.dateDebut).toDateString() !== new Date().toDateString())
      .sort((a, b) => a.dateDebut.localeCompare(b.dateDebut)),
  );

  ngOnInit(): void {
    this.api.monProfilGuide().subscribe({
      next: (p) => {
        this.profil.set(p);
        this.api.evenements({ guideId: p.id }).subscribe({ next: (l) => this.evenements.set(l) });
        this.api.moyennes('GUIDE').subscribe({ next: (m) => this.moyenne.set(m.find((x) => x.cibleId === p.id) ?? null) });
      },
      error: (e) => this.erreur.set(messageErreur(e)),
    });
  }
}
