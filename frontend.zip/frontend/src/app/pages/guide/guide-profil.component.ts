import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { messageErreur } from '../../core/util';
import { GuideNavComponent } from '../../shared/space-nav.component';

@Component({
  selector: 'app-guide-profil',
  standalone: true,
  imports: [FormsModule, GuideNavComponent],
  template: `
    <div class="container py-4" style="max-width: 680px">
      <h1 class="h3 mb-3">Mon profil</h1>
      <app-guide-nav />
      @if (erreur()) { <div class="alert alert-danger">{{ erreur() }}</div> }
      @if (info()) { <div class="alert alert-success">{{ info() }}</div> }
      <form class="panel" (ngSubmit)="enregistrer()" #f="ngForm">
        <div class="mb-3">
          <label class="form-label" for="nom">Nom</label>
          <input id="nom" class="form-control" name="nom" [(ngModel)]="d.nom" required>
        </div>
        <div class="mb-3">
          <label class="form-label" for="lic">Numéro de licence</label>
          <input id="lic" class="form-control" name="lic" [(ngModel)]="d.numeroLicence" required>
        </div>
        <div class="mb-3">
          <label class="form-label" for="lang">Langues</label>
          <input id="lang" class="form-control" name="lang" [(ngModel)]="d.langues">
        </div>
        <div class="mb-3">
          <label class="form-label" for="bio">Présentation</label>
          <textarea id="bio" class="form-control" rows="5" name="bio" [(ngModel)]="d.biographie" maxlength="2000"></textarea>
        </div>
        <button class="btn btn-primary" type="submit" [disabled]="f.invalid">Enregistrer</button>
      </form>
    </div>
  `,
})
export class GuideProfilComponent implements OnInit {
  private api = inject(ApiService);
  d = { nom: '', numeroLicence: '', biographie: '', langues: '' };
  erreur = signal('');
  info = signal('');

  ngOnInit(): void {
    this.api.monProfilGuide().subscribe({
      next: (p) => (this.d = { nom: p.nom, numeroLicence: p.numeroLicence ?? '', biographie: p.biographie ?? '', langues: p.langues ?? '' }),
      error: (e) => this.erreur.set(messageErreur(e)),
    });
  }

  enregistrer(): void {
    this.erreur.set('');
    this.info.set('');
    this.api.modifierMonProfilGuide(this.d).subscribe({
      next: () => this.info.set('Profil enregistré.'),
      error: (e) => this.erreur.set(messageErreur(e)),
    });
  }
}
