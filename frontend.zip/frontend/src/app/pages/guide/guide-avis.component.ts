import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { Avis } from '../../core/models';
import { messageErreur } from '../../core/util';
import { GuideNavComponent } from '../../shared/space-nav.component';
import { StarsComponent } from '../../shared/stars.component';

@Component({
  selector: 'app-guide-avis',
  standalone: true,
  imports: [FormsModule, DatePipe, GuideNavComponent, StarsComponent],
  template: `
    <div class="container py-4">
      <h1 class="h3 mb-3">Avis reçus</h1>
      <app-guide-nav />
      @if (erreur()) { <div class="alert alert-danger">{{ erreur() }}</div> }
      @if (info()) { <div class="alert alert-success">{{ info() }}</div> }

      @for (a of avis(); track a.id) {
        <div class="panel mb-3">
          <div class="d-flex justify-content-between flex-wrap">
            <strong>{{ a.auteurNom }}</strong>
            <span class="small text-muted">{{ a.datePublication | date: 'd MMM y' }}</span>
          </div>
          <app-stars [valeur]="a.note" [nombre]="0" />
          <p class="mb-2">{{ a.commentaire }}</p>

          @if (a.reponse) {
            <div class="border-start border-3 ps-3 small mb-2"><strong>Votre réponse :</strong> {{ a.reponse }}</div>
          } @else {
            <div class="input-group input-group-sm mb-2">
              <input class="form-control" placeholder="Votre réponse…" [ngModel]="reponses()[a.id] ?? ''" (ngModelChange)="saisir(a.id, $event)" [name]="'rep' + a.id">
              <button class="btn btn-primary" type="button" (click)="repondre(a)">Répondre</button>
            </div>
          }

          @if (signalant() === a.id) {
            <div class="input-group input-group-sm">
              <input class="form-control" placeholder="Motif du signalement" [(ngModel)]="motif" [name]="'mot' + a.id">
              <button class="btn btn-danger" type="button" (click)="signaler(a)">Envoyer</button>
              <button class="btn btn-outline-secondary" type="button" (click)="signalant.set(null)">Annuler</button>
            </div>
          } @else {
            <button class="btn btn-sm btn-link text-danger p-0" type="button" (click)="signalant.set(a.id); motif = ''">Signaler cet avis</button>
          }
        </div>
      } @empty {
        <p class="text-muted">Aucun avis pour le moment.</p>
      }
    </div>
  `,
})
export class GuideAvisComponent implements OnInit {
  private api = inject(ApiService);
  avis = signal<Avis[]>([]);
  reponses = signal<Record<number, string>>({});
  signalant = signal<number | null>(null);
  motif = '';
  erreur = signal('');
  info = signal('');

  saisir(id: number, v: string): void {
    this.reponses.set({ ...this.reponses(), [id]: v });
  }

  ngOnInit(): void {
    this.api.monProfilGuide().subscribe({
      next: (p) => this.api.avis('GUIDE', p.id).subscribe({ next: (l) => this.avis.set(l) }),
      error: (e) => this.erreur.set(messageErreur(e)),
    });
  }

  repondre(a: Avis): void {
    const texte = (this.reponses()[a.id] ?? '').trim();
    if (!texte) return;
    this.erreur.set('');
    this.api.repondreAvis(a.id, texte).subscribe({
      next: (maj) => {
        this.avis.set(this.avis().map((x) => (x.id === a.id ? maj : x)));
        this.info.set('Réponse publiée.');
      },
      error: (e) => this.erreur.set(messageErreur(e)),
    });
  }

  signaler(a: Avis): void {
    if (!this.motif.trim()) return;
    this.erreur.set('');
    this.api.signalerAvis(a.id, this.motif.trim()).subscribe({
      next: () => {
        this.signalant.set(null);
        this.info.set('Signalement transmis au conservateur.');
      },
      error: (e) => this.erreur.set(messageErreur(e)),
    });
  }
}
