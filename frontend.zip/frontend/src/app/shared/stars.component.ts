import { Component, computed, input, model } from '@angular/core';

/** Affiche une note sur 5 (étoiles) avec, en option, la moyenne et le nombre d'avis. */
@Component({
  selector: 'app-stars',
  standalone: true,
  template: `
    <span class="stars" [attr.aria-label]="valeur() + ' sur 5'">
      @for (i of etoiles; track i) {
        <span [class.on]="i <= arrondi()">★</span>
      }
      @if (nombre() !== null) {
        <small class="text-muted ms-1">
          @if (nombre() === 0) { Pas encore d'avis } @else { {{ valeur() }} ({{ nombre() }}) }
        </small>
      }
    </span>
  `,
})
export class StarsComponent {
  valeur = input<number>(0);
  nombre = input<number | null>(null);
  etoiles = [1, 2, 3, 4, 5];
  arrondi = computed(() => Math.round(this.valeur()));
}

/** Saisie d'une note de 1 à 5 : <app-star-input [(valeur)]="note" /> */
@Component({
  selector: 'app-star-input',
  standalone: true,
  template: `
    <span class="star-input" role="radiogroup" aria-label="Note">
      @for (i of etoiles; track i) {
        <button type="button" [class.on]="i <= valeur()" (click)="valeur.set(i)" [attr.aria-label]="i + ' étoile(s)'">★</button>
      }
    </span>
  `,
})
export class StarInputComponent {
  valeur = model<number>(0);
  etoiles = [1, 2, 3, 4, 5];
}
