import { Component, computed, input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Moyenne, Patrimoine } from '../core/models';
import { IMAGE_PAR_DEFAUT, libelleType, resume } from '../core/util';
import { StarsComponent } from './stars.component';

@Component({
  selector: 'app-site-card',
  standalone: true,
  imports: [RouterLink, StarsComponent],
  template: `
    <a class="card site-card h-100" [routerLink]="['/sites', site().id]">
      <img [src]="image()" [alt]="site().nomPatrimoine" loading="lazy">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-start mb-1">
          <span class="badge text-bg-light border">{{ type() }}</span>
          @if (distance() !== null) {
            <small class="text-accent fw-semibold">{{ distance() }} km</small>
          }
        </div>
        <h5 class="card-title mb-1 display-font">{{ site().nomPatrimoine }}</h5>
        <div class="small text-muted mb-2">{{ site().villePatrimoine }}</div>
        <p class="card-text small">{{ extrait() }}</p>
        <app-stars [valeur]="moyenne()?.moyenne ?? 0" [nombre]="moyenne()?.nombre ?? 0" />
      </div>
    </a>
  `,
})
export class SiteCardComponent {
  site = input.required<Patrimoine>();
  moyenne = input<Moyenne | undefined>(undefined);
  distance = input<number | null>(null);

  image = computed(() => this.site().imageUrl || IMAGE_PAR_DEFAUT);
  type = computed(() => libelleType(this.site().typePatrimoine));
  extrait = computed(() => resume(this.site().descriptionPatrimoine, 110));
}
