import { Component, computed, input, output } from '@angular/core';

/** Pagination style "pills" (comme dans le tutoriel Thymeleaf). Les pages sont numérotées à partir de 0. */
@Component({
  selector: 'app-pagination',
  standalone: true,
  template: `
    @if (nombrePages() > 1) {
      <nav aria-label="Pagination">
        <ul class="nav nav-pills justify-content-center gap-1">
          @for (p of pages(); track p) {
            <li class="nav-item">
              <button type="button" class="nav-link" [class.active]="p === page()" (click)="changer.emit(p)">{{ p + 1 }}</button>
            </li>
          }
        </ul>
      </nav>
    }
  `,
})
export class PaginationComponent {
  page = input.required<number>();
  nombrePages = input.required<number>();
  changer = output<number>();
  pages = computed(() => Array.from({ length: this.nombrePages() }, (_, i) => i));
}
