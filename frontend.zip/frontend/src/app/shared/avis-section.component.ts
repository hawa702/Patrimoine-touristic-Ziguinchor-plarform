import { DatePipe } from '@angular/common';
import { Component, OnInit, computed, inject, input, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { ApiService } from '../core/api.service';
import { AuthService } from '../core/auth.service';
import { Avis, CibleType } from '../core/models';
import { messageErreur } from '../core/util';
import { StarInputComponent, StarsComponent } from './stars.component';

/** Liste des avis d'un site ou d'un guide + formulaire de dépôt (touriste) + suppression (conservateur). */
@Component({
  selector: 'app-avis-section',
  standalone: true,
  imports: [FormsModule, DatePipe, RouterLink, StarsComponent, StarInputComponent],
  template: `
    <section class="panel">
      <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
        <h2 class="h4 mb-0">Avis des visiteurs</h2>
        <app-stars [valeur]="moyenne()" [nombre]="avis().length" />
      </div>

      @if (erreur()) {
        <div class="alert alert-danger py-2">{{ erreur() }}</div>
      }
      @if (info()) {
        <div class="alert alert-success py-2">{{ info() }}</div>
      }

      @if (auth.role() === 'TOURIST') {
        @if (dejaNote()) {
          <p class="small text-muted">Merci, vous avez déjà donné votre avis.</p>
        } @else {
          <form class="border rounded p-3 mb-3 bg-sand" (ngSubmit)="envoyer()">
            <div class="fw-semibold mb-1">Donnez votre avis</div>
            <app-star-input [(valeur)]="note" />
            <textarea class="form-control mt-2" rows="2" name="commentaire" [(ngModel)]="commentaire"
                      placeholder="Racontez votre visite (facultatif)" maxlength="2000"></textarea>
            <button class="btn btn-primary btn-sm mt-2" type="submit" [disabled]="note() < 1 || envoi()">Publier mon avis</button>
          </form>
        }
      } @else if (!auth.isLoggedIn()) {
        <p class="small text-muted">
          <a routerLink="/login" [queryParams]="{ redirect: router.url }">Connectez-vous</a> avec un compte touriste pour donner votre avis.
        </p>
      }

      @for (a of avis(); track a.id) {
        <div class="border-top pt-3 mt-3">
          <div class="d-flex justify-content-between align-items-start flex-wrap gap-1">
            <div>
              <strong>{{ a.auteurNom }}</strong>
              <span class="text-muted small ms-2">{{ a.datePublication | date: 'd MMMM y' }}</span>
            </div>
            <app-stars [valeur]="a.note" />
          </div>
          @if (a.commentaire) {
            <p class="mb-1 mt-1">{{ a.commentaire }}</p>
          }
          @if (a.reponse) {
            <div class="ms-3 mt-2 p-2 bg-sand rounded small">
              <strong>Réponse du guide :</strong> {{ a.reponse }}
            </div>
          }
          @if (auth.role() === 'ADMIN') {
            <button type="button" class="btn btn-sm btn-outline-danger mt-2" (click)="supprimer(a)">Supprimer cet avis</button>
          }
        </div>
      } @empty {
        <p class="text-muted mb-0">Aucun avis pour le moment.</p>
      }
    </section>
  `,
})
export class AvisSectionComponent implements OnInit {
  cibleType = input.required<CibleType>();
  cibleId = input.required<number>();

  private api = inject(ApiService);
  auth = inject(AuthService);
  router = inject(Router);

  avis = signal<Avis[]>([]);
  dejaNote = signal(false);
  erreur = signal('');
  info = signal('');
  envoi = signal(false);
  note = signal(0);
  commentaire = '';

  moyenne = computed(() => {
    const liste = this.avis();
    if (liste.length === 0) return 0;
    return Math.round((liste.reduce((s, a) => s + a.note, 0) / liste.length) * 10) / 10;
  });

  ngOnInit(): void {
    this.charger();
  }

  private charger(): void {
    this.api.avis(this.cibleType(), this.cibleId()).subscribe({
      next: (l) => this.avis.set(l),
      error: (e) => this.erreur.set(messageErreur(e)),
    });
    if (this.auth.role() === 'TOURIST') {
      this.api.mesAvis().subscribe({
        next: (l) =>
          this.dejaNote.set(l.some((a) => a.cibleType === this.cibleType() && a.cibleId === this.cibleId())),
      });
    }
  }

  envoyer(): void {
    this.erreur.set('');
    this.info.set('');
    this.envoi.set(true);
    this.api
      .deposerAvis({
        cibleType: this.cibleType(),
        cibleId: this.cibleId(),
        note: this.note(),
        commentaire: this.commentaire,
      })
      .subscribe({
        next: () => {
          this.envoi.set(false);
          this.info.set('Merci, votre avis a été publié.');
          this.commentaire = '';
          this.note.set(0);
          this.charger();
        },
        error: (e) => {
          this.envoi.set(false);
          this.erreur.set(messageErreur(e));
        },
      });
  }

  supprimer(a: Avis): void {
    if (!confirm('Supprimer définitivement cet avis ?')) return;
    this.api.supprimerAvis(a.id).subscribe({
      next: () => this.charger(),
      error: (e) => this.erreur.set(messageErreur(e)),
    });
  }
}
