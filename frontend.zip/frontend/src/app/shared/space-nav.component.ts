import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';

/** Barre d'onglets de l'espace conservateur. */
@Component({
  selector: 'app-admin-nav',
  standalone: true,
  imports: [RouterLink, RouterLinkActive],
  template: `
    <ul class="nav nav-pills flex-wrap gap-1 mb-4">
      @for (l of liens; track l.chemin) {
        <li class="nav-item">
          <a class="nav-link" [routerLink]="l.chemin" routerLinkActive="active" [routerLinkActiveOptions]="{ exact: l.chemin === '/admin' }">{{ l.label }}</a>
        </li>
      }
    </ul>
  `,
})
export class AdminNavComponent {
  liens = [
    { chemin: '/admin', label: 'Tableau de bord' },
    { chemin: '/admin/sites', label: 'Sites' },
    { chemin: '/admin/circuits', label: 'Circuits' },
    { chemin: '/admin/evenements', label: 'Visites & évènements' },
    { chemin: '/admin/guides', label: 'Guides' },
    { chemin: '/admin/reservations', label: 'Réservations' },
    { chemin: '/admin/moderation', label: 'Modération' },
  ];
}

/** Barre d'onglets de l'espace guide. */
@Component({
  selector: 'app-guide-nav',
  standalone: true,
  imports: [RouterLink, RouterLinkActive],
  template: `
    <ul class="nav nav-pills flex-wrap gap-1 mb-4">
      @for (l of liens; track l.chemin) {
        <li class="nav-item">
          <a class="nav-link" [routerLink]="l.chemin" routerLinkActive="active" [routerLinkActiveOptions]="{ exact: l.chemin === '/guide' }">{{ l.label }}</a>
        </li>
      }
    </ul>
  `,
})
export class GuideNavComponent {
  liens = [
    { chemin: '/guide', label: 'Mon agenda' },
    { chemin: '/guide/avis', label: 'Mes avis' },
    { chemin: '/guide/profil', label: 'Mon profil' },
  ];
}
