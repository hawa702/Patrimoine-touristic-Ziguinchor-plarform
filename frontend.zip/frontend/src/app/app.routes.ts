import { Routes } from '@angular/router';
import { roleGuard } from './core/guards';

export const routes: Routes = [
  // ---------- visiteur (public)
  { path: '', pathMatch: 'full', title: 'Accueil', loadComponent: () => import('./pages/public/home.component').then((m) => m.HomeComponent) },
  { path: 'sites', title: 'Sites', loadComponent: () => import('./pages/public/sites-list.component').then((m) => m.SitesListComponent) },
  { path: 'sites/:id', title: 'Détail du site', loadComponent: () => import('./pages/public/site-detail.component').then((m) => m.SiteDetailComponent) },
  { path: 'circuits', title: 'Circuits', loadComponent: () => import('./pages/public/circuits-list.component').then((m) => m.CircuitsListComponent) },
  { path: 'circuits/:id', title: 'Détail du circuit', loadComponent: () => import('./pages/public/circuit-detail.component').then((m) => m.CircuitDetailComponent) },
  { path: 'evenements', title: 'Visites & évènements', loadComponent: () => import('./pages/public/evenements-list.component').then((m) => m.EvenementsListComponent) },
  { path: 'evenements/:id', title: "Détail de l'évènement", loadComponent: () => import('./pages/public/evenement-detail.component').then((m) => m.EvenementDetailComponent) },
  { path: 'guides', title: 'Guides', loadComponent: () => import('./pages/public/guides-list.component').then((m) => m.GuidesListComponent) },
  { path: 'guides/:id', title: 'Fiche du guide', loadComponent: () => import('./pages/public/guide-detail.component').then((m) => m.GuideDetailComponent) },

  // ---------- connexion / inscription
  { path: 'login', title: 'Connexion', loadComponent: () => import('./pages/public/login.component').then((m) => m.LoginComponent) },
  { path: 'inscription', title: 'Inscription touriste', loadComponent: () => import('./pages/public/register.component').then((m) => m.RegisterComponent) },
  { path: 'inscription-guide', title: 'Inscription guide', loadComponent: () => import('./pages/public/register-guide.component').then((m) => m.RegisterGuideComponent) },
  { path: 'acces-refuse', title: 'Accès refusé', loadComponent: () => import('./pages/public/acces-refuse.component').then((m) => m.AccesRefuseComponent) },

  // ---------- touriste
  { path: 'reserver/:type/:id', title: 'Réserver', canActivate: [roleGuard('TOURIST')], loadComponent: () => import('./pages/tourist/reserver.component').then((m) => m.ReserverComponent) },
  { path: 'touriste', title: 'Mon espace touriste', canActivate: [roleGuard('TOURIST')], loadComponent: () => import('./pages/tourist/tourist-dashboard.component').then((m) => m.TouristDashboardComponent) },

  // ---------- guide
  {
    path: 'guide',
    canActivate: [roleGuard('GUIDE')],
    children: [
      { path: '', pathMatch: 'full', title: 'Mon agenda', loadComponent: () => import('./pages/guide/guide-dashboard.component').then((m) => m.GuideDashboardComponent) },
      { path: 'avis', title: 'Mes avis', loadComponent: () => import('./pages/guide/guide-avis.component').then((m) => m.GuideAvisComponent) },
      { path: 'profil', title: 'Mon profil', loadComponent: () => import('./pages/guide/guide-profil.component').then((m) => m.GuideProfilComponent) },
    ],
  },

  // ---------- conservateur (ADMIN)
  {
    path: 'admin',
    canActivate: [roleGuard('ADMIN')],
    children: [
      { path: '', pathMatch: 'full', title: 'Tableau de bord', loadComponent: () => import('./pages/admin/admin-dashboard.component').then((m) => m.AdminDashboardComponent) },
      { path: 'sites', title: 'Gestion des sites', loadComponent: () => import('./pages/admin/admin-sites.component').then((m) => m.AdminSitesComponent) },
      { path: 'circuits', title: 'Gestion des circuits', loadComponent: () => import('./pages/admin/admin-circuits.component').then((m) => m.AdminCircuitsComponent) },
      { path: 'evenements', title: 'Visites & évènements', loadComponent: () => import('./pages/admin/admin-evenements.component').then((m) => m.AdminEvenementsComponent) },
      { path: 'guides', title: 'Validation des guides', loadComponent: () => import('./pages/admin/admin-guides.component').then((m) => m.AdminGuidesComponent) },
      { path: 'reservations', title: 'Réservations', loadComponent: () => import('./pages/admin/admin-reservations.component').then((m) => m.AdminReservationsComponent) },
      { path: 'moderation', title: 'Modération des avis', loadComponent: () => import('./pages/admin/admin-moderation.component').then((m) => m.AdminModerationComponent) },
    ],
  },

  { path: '**', title: 'Page introuvable', loadComponent: () => import('./pages/public/not-found.component').then((m) => m.NotFoundComponent) },
];
