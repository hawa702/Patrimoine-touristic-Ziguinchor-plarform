import { HttpErrorResponse } from '@angular/common/http';
import { Moyenne, Patrimoine } from './models';

export const IMAGE_PAR_DEFAUT = '/images/fleuve-casamance.jpg';

export const TYPES_SITE: { value: string; label: string }[] = [
  { value: 'MONUMENT', label: 'Monument' },
  { value: 'MUSEE', label: 'Musée' },
  { value: 'PARC', label: 'Parc' },
  { value: 'SITE_NATUREL', label: 'Site naturel' },
  { value: 'CENTRE_CULTUREL', label: 'Centre culturel' },
  { value: 'AUTRE', label: 'Autre' },
];

export function libelleType(valeur?: string): string {
  return TYPES_SITE.find((t) => t.value === valeur)?.label ?? valeur ?? '';
}

/** Message lisible à partir d'une erreur HTTP (le message vient des microservices ou de la gateway). */
export function messageErreur(e: unknown, defaut = 'Une erreur est survenue.'): string {
  if (e instanceof HttpErrorResponse) {
    if (e.status === 0) {
      return 'Serveur injoignable. Vérifiez que les services sont démarrés.';
    }
    const corps: unknown = e.error;
    if (corps && typeof corps === 'object' && 'message' in corps) {
      const m = (corps as { message?: unknown }).message;
      if (typeof m === 'string' && m) {
        return m;
      }
    }
    if (e.status === 401) return 'Connexion requise.';
    if (e.status === 403) return 'Accès refusé.';
    if (e.status === 404) return 'Ressource introuvable.';
    if (e.status === 503) return "Un service est momentanément indisponible, réessayez plus tard.";
  }
  return defaut;
}

/** Distance à vol d'oiseau en km (formule de haversine). */
export function distanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const rad = Math.PI / 180;
  const dLat = (lat2 - lat1) * rad;
  const dLon = (lon2 - lon1) * rad;
  const a =
    Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.asin(Math.sqrt(a));
}

/** Date du jour au format yyyy-MM-dd (fuseau du navigateur). */
export function aujourdhui(): string {
  return formatDate(new Date());
}

export function formatDate(d: Date): string {
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

/** yyyy-MM-ddTHH:mm à partir d'une date décalée de n jours (pour les données de démonstration). */
export function dansNJours(jours: number, heure: string): string {
  const d = new Date();
  d.setDate(d.getDate() + jours);
  return `${formatDate(d)}T${heure}`;
}

export function resume(texte: string | undefined, max = 120): string {
  if (!texte) return '';
  return texte.length > max ? texte.slice(0, max).trimEnd() + '…' : texte;
}

export function dureeLisible(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h === 0) return `${m} min`;
  return m === 0 ? `${h} h` : `${h} h ${String(m).padStart(2, '0')}`;
}

/** Transforme la liste des moyennes renvoyée par ms-avis en dictionnaire id -> moyenne. */
export function versDictionnaire(liste: Moyenne[]): Record<number, Moyenne> {
  const d: Record<number, Moyenne> = {};
  for (const m of liste) {
    d[m.cibleId] = m;
  }
  return d;
}

/**
 * Accepte les anciens noms de champs (nom, code, ...) au cas où ms-patrimoine renverrait
 * encore l'entité brute : le frontend reste ainsi tolérant sur le contrat JSON.
 */
export function normaliserPatrimoine(p: any): Patrimoine {
  return {
    ...p,
    nomPatrimoine: p.nomPatrimoine ?? p.nom ?? '',
    codePatrimoine: p.codePatrimoine ?? p.code,
    descriptionPatrimoine: p.descriptionPatrimoine ?? p.description,
    historiquePatrimoine: p.historiquePatrimoine ?? p.historique,
    adressePatrimoine: p.adressePatrimoine ?? p.adresse,
    capacitePatrimoine: p.capacitePatrimoine ?? p.capacite ?? 0,
    latitudePatrimoine: p.latitudePatrimoine ?? 0,
    longitudePatrimoine: p.longitudePatrimoine ?? 0,
  };
}
