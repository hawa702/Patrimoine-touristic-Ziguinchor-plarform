import { Injectable, computed, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, tap } from 'rxjs';
import { ApiService } from './api.service';
import { AuthResponse, User } from './models';

const CLE = 'patrimoine.session';

/** Session de l'utilisateur : jeton JWT + profil, conservés dans le navigateur (localStorage). */
@Injectable({ providedIn: 'root' })
export class AuthService {
  private api = inject(ApiService);
  private router = inject(Router);

  private _user = signal<User | null>(null);
  private _token = signal<string | null>(null);

  readonly user = this._user.asReadonly();
  readonly token = this._token.asReadonly();
  readonly isLoggedIn = computed(() => this._user() !== null && this._token() !== null);
  readonly role = computed(() => this._user()?.role ?? null);
  readonly dashboardPath = computed(() => {
    switch (this._user()?.role) {
      case 'ADMIN': return '/admin';
      case 'GUIDE': return '/guide';
      case 'TOURIST': return '/touriste';
      default: return '/login';
    }
  });

  constructor() {
    this.restaurer();
  }

  login(email: string, password: string): Observable<AuthResponse> {
    return this.api.login(email, password).pipe(tap((r) => this.ouvrirSession(r)));
  }

  inscrireTouriste(nom: string, email: string, password: string): Observable<AuthResponse> {
    return this.api.inscrireTouriste(nom, email, password).pipe(tap((r) => this.ouvrirSession(r)));
  }

  inscrireGuide(d: {
    nom: string; email: string; password: string; numeroLicence: string; biographie: string; langues: string;
  }): Observable<AuthResponse> {
    return this.api.inscrireGuide(d).pipe(tap((r) => this.ouvrirSession(r)));
  }

  logout(): void {
    this._user.set(null);
    this._token.set(null);
    try {
      localStorage.removeItem(CLE);
    } catch {
      /* stockage indisponible : on ignore */
    }
  }

  deconnecter(): void {
    this.logout();
    void this.router.navigate(['/']);
  }

  /** Met à jour le profil en mémoire (ex : un guide vient d'être validé). */
  majUtilisateur(u: User): void {
    this._user.set(u);
    this.sauvegarder();
  }

  private ouvrirSession(r: AuthResponse): void {
    this._token.set(r.token);
    this._user.set(r.user);
    this.sauvegarder();
  }

  private sauvegarder(): void {
    try {
      localStorage.setItem(CLE, JSON.stringify({ token: this._token(), user: this._user() }));
    } catch {
      /* navigation privée : la session reste valable tant que l'onglet est ouvert */
    }
  }

  private restaurer(): void {
    try {
      const brut = localStorage.getItem(CLE);
      if (!brut) return;
      const s = JSON.parse(brut) as { token: string | null; user: User | null };
      if (s.token && s.user && !this.expire(s.token)) {
        this._token.set(s.token);
        this._user.set(s.user);
      } else {
        localStorage.removeItem(CLE);
      }
    } catch {
      /* session illisible : on repart de zéro */
    }
  }

  private expire(token: string): boolean {
    try {
      const charge = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
      const json = JSON.parse(atob(charge)) as { exp?: number };
      return !json.exp || json.exp * 1000 < Date.now();
    } catch {
      return true;
    }
  }
}
