import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from './auth.service';
import { Role } from './models';

/** Protège une route : connexion obligatoire + rôle autorisé (sinon /login ou /acces-refuse). */
export const roleGuard = (...roles: Role[]): CanActivateFn => (_route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (!auth.isLoggedIn()) {
    return router.createUrlTree(['/login'], { queryParams: { redirect: state.url } });
  }
  const role = auth.role();
  return role !== null && roles.includes(role) ? true : router.createUrlTree(['/acces-refuse']);
};
