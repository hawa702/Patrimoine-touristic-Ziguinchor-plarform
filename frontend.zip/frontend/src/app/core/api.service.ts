import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';
import {
  AuthResponse, Avis, CibleType, Circuit, Disponibilite, Evenement, GuideAdmin, GuidePublic,
  Moyenne, Patrimoine, Reservation, Signalement, TypeReservation, User,
} from './models';
import { normaliserPatrimoine } from './util';

/** Tous les appels HTTP du site passent par ici, toujours via l'API Gateway (/api/...). */
@Injectable({ providedIn: 'root' })
export class ApiService {
  private http = inject(HttpClient);

  // ------------------------------------------------------------ authentification
  login(email: string, password: string): Observable<AuthResponse> {
    return this.http.post<AuthResponse>('/api/auth/login', { email, password });
  }
  inscrireTouriste(nom: string, email: string, password: string): Observable<AuthResponse> {
    return this.http.post<AuthResponse>('/api/auth/register', { nom, email, password });
  }
  inscrireGuide(d: {
    nom: string; email: string; password: string; numeroLicence: string; biographie: string; langues: string;
  }): Observable<AuthResponse> {
    return this.http.post<AuthResponse>('/api/auth/register-guide', d);
  }
  moi(): Observable<User> {
    return this.http.get<User>('/api/auth/me');
  }

  // ------------------------------------------------------------ patrimoines (sites)
  patrimoines(): Observable<Patrimoine[]> {
    return this.http.get<any[]>('/api/patrimoines').pipe(map((l) => l.map(normaliserPatrimoine)));
  }
  patrimoine(id: number): Observable<Patrimoine> {
    return this.http.get<any>(`/api/patrimoines/${id}`).pipe(map(normaliserPatrimoine));
  }
  creerPatrimoine(p: Patrimoine): Observable<Patrimoine> {
    return this.http.post<Patrimoine>('/api/patrimoines', p);
  }
  modifierPatrimoine(id: number, p: Patrimoine): Observable<Patrimoine> {
    return this.http.put<Patrimoine>(`/api/patrimoines/${id}`, p);
  }
  supprimerPatrimoine(id: number): Observable<void> {
    return this.http.delete<void>(`/api/patrimoines/${id}`);
  }

  // ------------------------------------------------------------ circuits
  circuits(): Observable<Circuit[]> {
    return this.http.get<Circuit[]>('/api/circuits').pipe(map((l) => l.map((c) => this.circuitNormalise(c))));
  }
  circuit(id: number): Observable<Circuit> {
    return this.http.get<Circuit>(`/api/circuits/${id}`).pipe(map((c) => this.circuitNormalise(c)));
  }
  creerCircuit(c: Circuit): Observable<Circuit> {
    return this.http.post<Circuit>('/api/circuits', c);
  }
  modifierCircuit(id: number, c: Circuit): Observable<Circuit> {
    return this.http.put<Circuit>(`/api/circuits/${id}`, c);
  }
  supprimerCircuit(id: number): Observable<void> {
    return this.http.delete<void>(`/api/circuits/${id}`);
  }
  private circuitNormalise(c: Circuit): Circuit {
    return {
      ...c,
      etapes: (c.etapes ?? []).map((e) => ({
        ...e,
        patrimoine: e.patrimoine ? normaliserPatrimoine(e.patrimoine) : null,
      })),
    };
  }

  // ------------------------------------------------------------ évènements / visites
  evenements(filtre?: { patrimoineId?: number; guideId?: number }): Observable<Evenement[]> {
    let params = new HttpParams();
    if (filtre?.patrimoineId !== undefined) params = params.set('patrimoineId', filtre.patrimoineId);
    if (filtre?.guideId !== undefined) params = params.set('guideId', filtre.guideId);
    return this.http.get<Evenement[]>('/api/evenements', { params });
  }
  evenement(id: number): Observable<Evenement> {
    return this.http.get<Evenement>(`/api/evenements/${id}`);
  }
  creerEvenement(e: Evenement): Observable<Evenement> {
    return this.http.post<Evenement>('/api/evenements', e);
  }
  modifierEvenement(id: number, e: Evenement): Observable<Evenement> {
    return this.http.put<Evenement>(`/api/evenements/${id}`, e);
  }
  supprimerEvenement(id: number): Observable<void> {
    return this.http.delete<void>(`/api/evenements/${id}`);
  }

  // ------------------------------------------------------------ réservations
  disponibilite(type: TypeReservation, referenceId: number, date?: string): Observable<Disponibilite> {
    let params = new HttpParams().set('type', type).set('referenceId', referenceId);
    if (date) params = params.set('date', date);
    return this.http.get<Disponibilite>('/api/reservations/disponibilite', { params });
  }
  creerReservation(r: Reservation): Observable<Reservation> {
    return this.http.post<Reservation>('/api/reservations', r);
  }
  mesReservations(): Observable<Reservation[]> {
    return this.http.get<Reservation[]>('/api/reservations/mes');
  }
  toutesLesReservations(): Observable<Reservation[]> {
    return this.http.get<Reservation[]>('/api/reservations');
  }
  confirmerReservation(id: number): Observable<Reservation> {
    return this.http.put<Reservation>(`/api/reservations/${id}/confirmer`, {});
  }
  annulerReservation(id: number): Observable<Reservation> {
    return this.http.put<Reservation>(`/api/reservations/${id}/annuler`, {});
  }
  qrCode(id: number): Observable<{ qrCode: string; contenu: string }> {
    return this.http.get<{ qrCode: string; contenu: string }>(`/api/reservations/${id}/qrcode`);
  }

  // ------------------------------------------------------------ guides
  guides(): Observable<GuidePublic[]> {
    return this.http.get<GuidePublic[]>('/api/guides');
  }
  guide(id: number): Observable<GuidePublic> {
    return this.http.get<GuidePublic>(`/api/guides/${id}`);
  }
  guidesEnAttente(): Observable<GuideAdmin[]> {
    return this.http.get<GuideAdmin[]>('/api/guides/en-attente');
  }
  validerGuide(id: number): Observable<GuideAdmin> {
    return this.http.put<GuideAdmin>(`/api/guides/${id}/valider`, {});
  }
  refuserGuide(id: number): Observable<void> {
    return this.http.put<void>(`/api/guides/${id}/refuser`, {});
  }
  monProfilGuide(): Observable<GuideAdmin> {
    return this.http.get<GuideAdmin>('/api/guides/me');
  }
  modifierMonProfilGuide(d: { nom: string; numeroLicence: string; biographie: string; langues: string }): Observable<GuideAdmin> {
    return this.http.put<GuideAdmin>('/api/guides/me', d);
  }

  // ------------------------------------------------------------ avis et signalements
  avis(cibleType: CibleType, cibleId: number): Observable<Avis[]> {
    const params = new HttpParams().set('cibleType', cibleType).set('cibleId', cibleId);
    return this.http.get<Avis[]>('/api/avis', { params });
  }
  moyennes(cibleType: CibleType): Observable<Moyenne[]> {
    return this.http.get<Moyenne[]>('/api/avis/moyennes', { params: new HttpParams().set('cibleType', cibleType) });
  }
  mesAvis(): Observable<Avis[]> {
    return this.http.get<Avis[]>('/api/avis/mes');
  }
  deposerAvis(d: { cibleType: CibleType; cibleId: number; note: number; commentaire: string }): Observable<Avis> {
    return this.http.post<Avis>('/api/avis', d);
  }
  repondreAvis(id: number, reponse: string): Observable<Avis> {
    return this.http.put<Avis>(`/api/avis/${id}/reponse`, { reponse });
  }
  signalerAvis(id: number, motif: string): Observable<Signalement> {
    return this.http.post<Signalement>(`/api/avis/${id}/signaler`, { motif });
  }
  supprimerAvis(id: number): Observable<void> {
    return this.http.delete<void>(`/api/avis/${id}`);
  }
  signalements(): Observable<Signalement[]> {
    return this.http.get<Signalement[]>('/api/signalements');
  }
  resoudreSignalement(id: number, supprimerAvis: boolean): Observable<Signalement> {
    return this.http.put<Signalement>(`/api/signalements/${id}/resoudre`, { supprimerAvis });
  }
}
