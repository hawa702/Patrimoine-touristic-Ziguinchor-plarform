export type Role = 'TOURIST' | 'GUIDE' | 'ADMIN';
export type CibleType = 'SITE' | 'GUIDE';
export type TypeEvenement = 'EXPOSITION' | 'ATELIER' | 'VISITE_GUIDEE';
export type Difficulte = 'FACILE' | 'MOYEN' | 'DIFFICILE';
export type TypeReservation = 'CIRCUIT' | 'EVENEMENT';
export type StatutReservation = 'EN_ATTENTE' | 'CONFIRMEE' | 'ANNULEE';

export interface User {
  id: number;
  nom: string;
  email: string;
  role: Role;
  estVerifie: boolean;
}

export interface AuthResponse {
  token: string;
  user: User;
}

export interface Patrimoine {
  id?: number;
  nomPatrimoine: string;
  codePatrimoine?: string;
  descriptionPatrimoine?: string;
  historiquePatrimoine?: string;
  adressePatrimoine?: string;
  capacitePatrimoine: number;
  latitudePatrimoine: number;
  longitudePatrimoine: number;
  villePatrimoine?: string;
  typePatrimoine?: string;
  horairesPatrimoine?: string;
  imageUrl?: string;
}

export interface Etape {
  id?: number;
  position: number;
  dureeEstime: number;
  patrimoineId: number;
  patrimoine?: Patrimoine | null;
}

export interface Circuit {
  id?: number;
  codeCircuit: string;
  nomCircuit: string;
  descriptionCircuit: string;
  dureeTotale: number;
  distanceTotale: number;
  difficulte: Difficulte;
  capaciteMax: number;
  etapes: Etape[];
}

export interface Evenement {
  id?: number;
  titre: string;
  description: string;
  type: TypeEvenement;
  dateDebut: string;
  dateFin: string;
  lieu: string;
  patrimoineId: number | null;
  placesMax: number;
  guideId: number | null;
  guideNom: string | null;
}

export interface Reservation {
  id?: number;
  typeReservation: TypeReservation;
  referenceId: number;
  nomClient: string;
  email?: string;
  dateVisite?: string | null;
  nombrePlaces: number;
  statut?: StatutReservation;
  dateCreation?: string;
}

export interface Disponibilite {
  typeReservation: TypeReservation;
  referenceId: number;
  date: string | null;
  capacite: number;
  placesReservees: number;
  placesRestantes: number;
  disponible: boolean;
}

export interface GuidePublic {
  id: number;
  nom: string;
  biographie?: string;
  langues?: string;
}

export interface GuideAdmin extends GuidePublic {
  email: string;
  numeroLicence?: string;
  estVerifie: boolean;
  dateCreation?: string;
}

export interface Avis {
  id: number;
  cibleType: CibleType;
  cibleId: number;
  auteurId: number;
  auteurNom: string;
  note: number;
  commentaire?: string;
  reponse?: string;
  datePublication: string;
  dateReponse?: string;
}

export interface Moyenne {
  cibleId: number;
  moyenne: number;
  nombre: number;
}

export interface Signalement {
  id: number;
  avisId: number;
  motif: string;
  auteurId: number;
  statut: 'EN_ATTENTE' | 'RESOLU';
  dateSignalement: string;
  avis: Avis | null;
}
