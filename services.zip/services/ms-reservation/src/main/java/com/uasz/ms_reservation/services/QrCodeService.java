package com.uasz.ms_reservation.services;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;

/** Génère le QR Code du ticket de visite (image PNG renvoyée en data-URI base64). */
@Service
public class QrCodeService {

    public String genererDataUri(String contenu) {
        try {
            BitMatrix matrice = new QRCodeWriter().encode(contenu, BarcodeFormat.QR_CODE, 300, 300);
            ByteArrayOutputStream sortie = new ByteArrayOutputStream();
            MatrixToImageWriter.writeToStream(matrice, "PNG", sortie);
            return "data:image/png;base64," + Base64.getEncoder().encodeToString(sortie.toByteArray());
        } catch (WriterException | IOException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Impossible de générer le QR Code");
        }
    }
}
