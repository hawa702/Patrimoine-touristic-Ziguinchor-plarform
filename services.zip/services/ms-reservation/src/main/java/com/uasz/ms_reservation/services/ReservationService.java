package com.uasz.ms_reservation.services;

import com.uasz.ms_reservation.clients.CircuitClient;
import com.uasz.ms_reservation.clients.EvenementClient;
import com.uasz.ms_reservation.dto.CircuitDto;
import com.uasz.ms_reservation.dto.DisponibiliteDto;
import com.uasz.ms_reservation.dto.EvenementDto;
import com.uasz.ms_reservation.dto.ReservationDto;
import com.uasz.ms_reservation.entities.Reservation;
import com.uasz.ms_reservation.entities.StatutReservation;
import com.uasz.ms_reservation.entities.TypeReservation;
import com.uasz.ms_reservation.mappers.ReservationMapper;
import com.uasz.ms_reservation.repositories.ReservationRepository;
import feign.FeignException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

@Service
public class ReservationService implements IReservationService {

    // Les réservations annulées libèrent leurs places
    private static final Set<StatutReservation> STATUTS_ACTIFS =
            Set.of(StatutReservation.EN_ATTENTE, StatutReservation.CONFIRMEE);

    @Autowired
    ReservationRepository reservationRepository;

    @Autowired
    ReservationMapper reservationMapper;

    @Autowired
    CircuitClient circuitClient;         // communication avec ms-circuit (OpenFeign)

    @Autowired
    EvenementClient evenementClient;     // communication avec ms-evenement (OpenFeign)

    // CREATE
    @Override
    @Transactional
    public ReservationDto creerReservation(ReservationDto dto) {
        if (dto.getTypeReservation() == null || dto.getReferenceId() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "typeReservation et referenceId sont obligatoires");
        }
        if (dto.getNombrePlaces() <= 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "nombrePlaces doit être supérieur à 0");
        }
        if (dto.getNomClient() == null || dto.getNomClient().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "nomClient est obligatoire");
        }

        // 1. Interroger ms-circuit / ms-evenement pour connaître la capacité et la date
        LocalDate date = dto.getDateVisite();
        int capacite;
        if (dto.getTypeReservation() == TypeReservation.CIRCUIT) {
            if (date == null) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                        "dateVisite est obligatoire pour un circuit");
            }
            if (date.isBefore(LocalDate.now())) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "dateVisite est dans le passé");
            }
            capacite = chargerCircuit(dto.getReferenceId()).getCapaciteMax();
        } else {
            EvenementDto evenement = chargerEvenement(dto.getReferenceId());
            if (evenement.getDateDebut() != null && evenement.getDateDebut().isBefore(LocalDateTime.now())) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                        "Cet événement a déjà commencé ou est terminé");
            }
            // la date d'un événement est imposée par l'événement lui-même
            if (evenement.getDateDebut() != null) {
                date = evenement.getDateDebut().toLocalDate();
            }
            capacite = evenement.getPlacesMax();
        }

        // 2. Vérifier qu'il reste assez de places
        int dejaReservees = reservationRepository.countPlacesReservees(
                dto.getTypeReservation(), dto.getReferenceId(), date, STATUTS_ACTIFS);
        int restantes = capacite - dejaReservees;
        if (dto.getNombrePlaces() > restantes) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Places insuffisantes : " + Math.max(restantes, 0) + " restante(s), "
                            + dto.getNombrePlaces() + " demandée(s)");
        }

        // 3. Valider la réservation (en attente de confirmation)
        Reservation reservation = reservationMapper.toEntity(dto);
        reservation.setId(null);
        reservation.setDateVisite(date);
        reservation.setStatut(StatutReservation.EN_ATTENTE);
        reservation.setDateCreation(LocalDateTime.now());
        return reservationMapper.toDto(reservationRepository.save(reservation));
    }

    // READ ALL
    @Override
    public List<ReservationDto> getAllReservations() {
        return reservationRepository.findAll().stream()
                .map(reservationMapper::toDto)
                .toList();
    }

    // READ par client (email)
    @Override
    public List<ReservationDto> getReservationsByEmail(String email) {
        return reservationRepository.findByEmail(email).stream()
                .map(reservationMapper::toDto)
                .toList();
    }

    // READ ONE
    @Override
    public ReservationDto getByIdReservation(Long id) {
        return reservationMapper.toDto(findOrThrow(id));
    }

    // CONFIRMER
    @Override
    @Transactional
    public ReservationDto confirmerReservation(Long id) {
        Reservation reservation = findOrThrow(id);
        if (reservation.getStatut() != StatutReservation.EN_ATTENTE) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Seule une réservation EN_ATTENTE peut être confirmée (statut actuel : "
                            + reservation.getStatut() + ")");
        }
        reservation.setStatut(StatutReservation.CONFIRMEE);
        return reservationMapper.toDto(reservationRepository.save(reservation));
    }

    // ANNULER
    @Override
    @Transactional
    public ReservationDto annulerReservation(Long id) {
        Reservation reservation = findOrThrow(id);
        if (reservation.getStatut() == StatutReservation.ANNULEE) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Réservation déjà annulée");
        }
        reservation.setStatut(StatutReservation.ANNULEE);
        return reservationMapper.toDto(reservationRepository.save(reservation));
    }

    // DISPONIBILITE
    @Override
    public DisponibiliteDto verifierDisponibilite(TypeReservation type, Long referenceId, LocalDate date) {
        int capacite;
        LocalDate dateRef = date;
        if (type == TypeReservation.CIRCUIT) {
            if (date == null) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "date est obligatoire pour un circuit");
            }
            capacite = chargerCircuit(referenceId).getCapaciteMax();
        } else {
            EvenementDto evenement = chargerEvenement(referenceId);
            capacite = evenement.getPlacesMax();
            if (evenement.getDateDebut() != null) {
                dateRef = evenement.getDateDebut().toLocalDate();
            }
        }
        int reservees = reservationRepository.countPlacesReservees(type, referenceId, dateRef, STATUTS_ACTIFS);
        int restantes = Math.max(capacite - reservees, 0);
        return new DisponibiliteDto(type, referenceId, dateRef, capacite, reservees, restantes, restantes > 0);
    }

    // ---------------------------------------------------------------------
    // Méthodes privées
    // ---------------------------------------------------------------------

    private Reservation findOrThrow(Long id) {
        return reservationRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "Réservation non trouvée avec l'id : " + id));
    }

    /** Appel Feign vers ms-circuit : 404 si inconnu, 503 si le service est arrêté. */
    private CircuitDto chargerCircuit(Long id) {
        try {
            return circuitClient.getCircuitById(id);
        } catch (FeignException.NotFound e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Circuit introuvable : " + id);
        } catch (FeignException e) {
            throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,
                    "ms-circuit est indisponible, réessayez plus tard");
        }
    }

    /** Appel Feign vers ms-evenement : 404 si inconnu, 503 si le service est arrêté. */
    private EvenementDto chargerEvenement(Long id) {
        try {
            return evenementClient.getEvenementById(id);
        } catch (FeignException.NotFound e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Evenement introuvable : " + id);
        } catch (FeignException e) {
            throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,
                    "ms-evenement est indisponible, réessayez plus tard");
        }
    }
}
