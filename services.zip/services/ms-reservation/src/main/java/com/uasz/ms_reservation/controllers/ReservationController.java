package com.uasz.ms_reservation.controllers;

import com.uasz.ms_reservation.dto.DisponibiliteDto;
import com.uasz.ms_reservation.dto.ReservationDto;
import com.uasz.ms_reservation.entities.StatutReservation;
import com.uasz.ms_reservation.entities.TypeReservation;
import com.uasz.ms_reservation.services.QrCodeService;
import com.uasz.ms_reservation.services.ReservationService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * Les en-têtes X-User-Email et X-User-Role sont posés par l'API Gateway après validation du JWT.
 * Les microservices ne sont pas accessibles directement depuis l'extérieur (réseau Docker interne).
 */
@RestController
@RequestMapping("/api/reservations")
public class ReservationController {

    private final ReservationService reservationService;
    private final QrCodeService qrCodeService;

    public ReservationController(ReservationService reservationService, QrCodeService qrCodeService) {
        this.reservationService = reservationService;
        this.qrCodeService = qrCodeService;
    }

    // 1. Créer une réservation (POST) : vérifie la disponibilité auprès de ms-circuit / ms-evenement
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ReservationDto createReservation(@RequestBody ReservationDto reservationDto,
                                            @RequestHeader(value = "X-User-Email", required = false) String email) {
        // la réservation est toujours rattachée au compte connecté
        if (email != null && !email.isBlank()) {
            reservationDto.setEmail(email);
        }
        return this.reservationService.creerReservation(reservationDto);
    }

    // 2. Lister toutes les réservations (GET) : réservé au conservateur (règle posée dans la gateway)
    @GetMapping
    public List<ReservationDto> getAllReservations() {
        return this.reservationService.getAllReservations();
    }

    // 2 bis. Mes réservations (GET) : celles du compte connecté
    @GetMapping("/mes")
    public List<ReservationDto> getMesReservations(
            @RequestHeader(value = "X-User-Email", required = false) String email) {
        if (email == null || email.isBlank()) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Connexion requise");
        }
        return this.reservationService.getReservationsByEmail(email);
    }

    // 3. Récupérer une réservation par son ID (GET)
    @GetMapping("/{id}")
    public ResponseEntity<ReservationDto> getReservationById(
            @PathVariable Long id,
            @RequestHeader(value = "X-User-Email", required = false) String email,
            @RequestHeader(value = "X-User-Role", required = false) String role) {
        ReservationDto reservation = this.reservationService.getByIdReservation(id);
        verifierProprietaire(reservation, email, role);
        return ResponseEntity.ok(reservation);
    }

    // 4. Consulter la disponibilité (GET)
    // ex : /api/reservations/disponibilite?type=CIRCUIT&referenceId=1&date=2026-12-01
    @GetMapping("/disponibilite")
    public DisponibiliteDto getDisponibilite(@RequestParam TypeReservation type,
                                             @RequestParam Long referenceId,
                                             @RequestParam(required = false)
                                             @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return this.reservationService.verifierDisponibilite(type, referenceId, date);
    }

    // 5. Confirmer une réservation (PUT)
    @PutMapping("/{id}/confirmer")
    public ReservationDto confirmerReservation(
            @PathVariable Long id,
            @RequestHeader(value = "X-User-Email", required = false) String email,
            @RequestHeader(value = "X-User-Role", required = false) String role) {
        verifierProprietaire(this.reservationService.getByIdReservation(id), email, role);
        return this.reservationService.confirmerReservation(id);
    }

    // 6. Annuler une réservation (PUT)
    @PutMapping("/{id}/annuler")
    public ReservationDto annulerReservation(
            @PathVariable Long id,
            @RequestHeader(value = "X-User-Email", required = false) String email,
            @RequestHeader(value = "X-User-Role", required = false) String role) {
        verifierProprietaire(this.reservationService.getByIdReservation(id), email, role);
        return this.reservationService.annulerReservation(id);
    }

    // 7. QR Code du ticket (GET) : disponible uniquement pour une réservation confirmée
    @GetMapping("/{id}/qrcode")
    public Map<String, String> getQrCode(
            @PathVariable Long id,
            @RequestHeader(value = "X-User-Email", required = false) String email,
            @RequestHeader(value = "X-User-Role", required = false) String role) {
        ReservationDto r = this.reservationService.getByIdReservation(id);
        verifierProprietaire(r, email, role);
        if (r.getStatut() != StatutReservation.CONFIRMEE) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Le QR Code n'est disponible que pour une réservation confirmée");
        }
        String contenu = "PATRIMOINE-ZIG|RES-" + r.getId()
                + "|" + r.getTypeReservation() + "-" + r.getReferenceId()
                + "|" + r.getDateVisite()
                + "|" + r.getNombrePlaces() + " place(s)"
                + "|" + r.getNomClient();
        return Map.of("qrCode", this.qrCodeService.genererDataUri(contenu), "contenu", contenu);
    }

    /** Un touriste ne peut agir que sur ses propres réservations ; le conservateur (ADMIN) sur toutes. */
    private void verifierProprietaire(ReservationDto reservation, String email, String role) {
        if ("ADMIN".equals(role)) {
            return;
        }
        if (email == null || reservation.getEmail() == null
                || !email.equalsIgnoreCase(reservation.getEmail())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Cette réservation ne vous appartient pas");
        }
    }
}
