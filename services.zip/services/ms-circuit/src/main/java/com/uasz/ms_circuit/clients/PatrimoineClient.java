package com.uasz.ms_circuit.clients;

import com.uasz.ms_circuit.dto.PatrimoineDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

// L'URL vient de application.yaml (services.patrimoine.url) ou de la variable d'environnement
// SERVICES_PATRIMOINE_URL (dans Docker : http://ms-patrimoine:3001).
@FeignClient(name = "ms-patrimoine", url = "${services.patrimoine.url}")
public interface PatrimoineClient {

    @GetMapping("/api/patrimoines/{id}")
    PatrimoineDto getPatrimoineById(@PathVariable("id") Long id);
}
