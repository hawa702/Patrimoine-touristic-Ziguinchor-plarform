package com.uasz.ms_patrimoine.services;

import com.uasz.ms_patrimoine.entities.Patrimoine;
import com.uasz.ms_patrimoine.repositories.PatrimoineRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

@Service
public class PatrimoineService implements IPatrimoineService {

    @Autowired
    PatrimoineRepository patrimoineRepository;

    // CREATE
    @Override
    public Patrimoine savePatrimoine(Patrimoine patrimoine) {
        return patrimoineRepository.save(patrimoine);
    }

    // READ ALL
    @Override
    public List<Patrimoine> getAllPatrimoines() {
        return patrimoineRepository.findAll();
    }

    // READ ONE
    @Override
    public Optional<Patrimoine> getByIdPatrimoine(Long id) {
        return patrimoineRepository.findById(id);
    }

    // UPDATE
    @Override
    public Patrimoine updatePatrimoine(Long id, Patrimoine n) {
        return patrimoineRepository.findById(id).map(p -> {
            p.setNomPatrimoine(n.getNomPatrimoine());
            p.setCodePatrimoine(n.getCodePatrimoine());
            p.setDescriptionPatrimoine(n.getDescriptionPatrimoine());
            p.setHistoriquePatrimoine(n.getHistoriquePatrimoine());
            p.setAdressePatrimoine(n.getAdressePatrimoine());
            p.setCapacitePatrimoine(n.getCapacitePatrimoine());
            p.setLatitudePatrimoine(n.getLatitudePatrimoine());
            p.setLongitudePatrimoine(n.getLongitudePatrimoine());
            p.setVillePatrimoine(n.getVillePatrimoine());
            p.setTypePatrimoine(n.getTypePatrimoine());
            p.setHorairesPatrimoine(n.getHorairesPatrimoine());
            p.setImageUrl(n.getImageUrl());
            return patrimoineRepository.save(p);
        }).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                "Patrimoine non trouvé avec l'id : " + id));
    }

    // DELETE
    @Override
    public void deletePatrimoine(Long id) {
        patrimoineRepository.deleteById(id);
    }
}
