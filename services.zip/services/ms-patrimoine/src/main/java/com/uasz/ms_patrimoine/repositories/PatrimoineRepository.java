package com.uasz.ms_patrimoine.repositories;

import com.uasz.ms_patrimoine.entities.Patrimoine;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PatrimoineRepository extends JpaRepository<Patrimoine,Long> {
}
