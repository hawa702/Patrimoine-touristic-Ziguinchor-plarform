package com.uasz.ms_patrimoine.controllers;

import com.uasz.ms_patrimoine.dto.PatrimoineDto;
import com.uasz.ms_patrimoine.entities.Patrimoine;
import com.uasz.ms_patrimoine.mappers.PatrimoineMapper;
import com.uasz.ms_patrimoine.services.PatrimoineService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/patrimoines")
public class PatrimoineController {

    private final PatrimoineService patrimoineService;
    private final PatrimoineMapper patrimoineMapper;

    public PatrimoineController(PatrimoineService patrimoineService, PatrimoineMapper patrimoineMapper) {
        this.patrimoineService = patrimoineService;
        this.patrimoineMapper = patrimoineMapper;
    }

    // 1. Ajouter un patrimoine (POST)
    @PostMapping
    public PatrimoineDto createPatrimoine(@RequestBody PatrimoineDto dto) {
        Patrimoine entity = patrimoineMapper.toEntity(dto);
        entity.setId(null);
        return patrimoineMapper.toDto(patrimoineService.savePatrimoine(entity));
    }

    // 2. Récupérer tous les patrimoines (GET)
    @GetMapping
    public List<PatrimoineDto> getAllPatrimoines() {
        return patrimoineService.getAllPatrimoines().stream().map(patrimoineMapper::toDto).toList();
    }

    // 3. Récupérer un patrimoine par son ID (GET)
    @GetMapping("/{id}")
    public ResponseEntity<PatrimoineDto> getPatrimoineById(@PathVariable Long id) {
        return patrimoineService.getByIdPatrimoine(id)
                .map(patrimoineMapper::toDto)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // 4. Mettre à jour un patrimoine (PUT)
    @PutMapping("/{id}")
    public PatrimoineDto updatePatrimoine(@PathVariable Long id, @RequestBody PatrimoineDto dto) {
        return patrimoineMapper.toDto(patrimoineService.updatePatrimoine(id, patrimoineMapper.toEntity(dto)));
    }

    // 5. Supprimer un patrimoine (DELETE)
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePatrimoine(@PathVariable Long id) {
        patrimoineService.deletePatrimoine(id);
        return ResponseEntity.noContent().build();
    }
}
