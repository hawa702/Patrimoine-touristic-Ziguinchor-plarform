package com.uasz.ms_patrimoine.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Les noms des champs sont volontairement identiques à ceux de PatrimoineDto :
 * c'est le "contrat" JSON partagé avec ms-circuit, ms-evenement et le frontend.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Patrimoine {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nomPatrimoine;
    private String codePatrimoine;
    @Column(length = 2000)
    private String descriptionPatrimoine;
    @Column(length = 4000)
    private String historiquePatrimoine;
    private String adressePatrimoine;
    private int capacitePatrimoine;
    private float latitudePatrimoine;
    private float longitudePatrimoine;
    private String villePatrimoine;
    private String typePatrimoine;       // MONUMENT, MUSEE, PARC, SITE_NATUREL, CENTRE_CULTUREL, AUTRE
    private String horairesPatrimoine;   // ex : "Lun-Sam 09:00-17:00"
    private String imageUrl;             // URL de la photo principale
}
