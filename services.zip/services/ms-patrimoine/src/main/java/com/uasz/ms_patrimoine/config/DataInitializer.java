package com.uasz.ms_patrimoine.config;

import com.uasz.ms_patrimoine.entities.Patrimoine;
import com.uasz.ms_patrimoine.repositories.PatrimoineRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * Données de démonstration chargées uniquement si la table est vide.
 * Les coordonnées GPS sont approximatives et les textes sont à compléter par le conservateur.
 */
@Component
public class DataInitializer implements CommandLineRunner {

    private final PatrimoineRepository repository;

    public DataInitializer(PatrimoineRepository repository) {
        this.repository = repository;
    }

    @Override
    public void run(String... args) {
        if (repository.count() > 0) {
            return;
        }
        String note = "Fiche de démonstration : le conservateur peut compléter l'historique de ce site.";

        repository.save(site("PAT-001", "Maison coloniale", "MONUMENT", "Ziguinchor",
                "Quartier administratif, Ziguinchor", 12.5855f, -16.2725f, 40, "Lun-Sam 09:00-17:00",
                "Bâtiment de style colonial à la façade rouge et blanche, témoin de l'architecture de l'époque coloniale en Casamance.",
                note, "/images/maison-coloniale.jpg"));

        repository.save(site("PAT-002", "Alliance franco-sénégalaise", "CENTRE_CULTUREL", "Ziguinchor",
                "Centre-ville, Ziguinchor", 12.5832f, -16.2719f, 80, "Lun-Ven 09:00-18:00",
                "Centre culturel de la ville : expositions, spectacles et rencontres autour des cultures de la Casamance.",
                note, "/images/alliance-francaise.jpg"));

        repository.save(site("PAT-003", "Port et quai de Ziguinchor", "AUTRE", "Ziguinchor",
                "Port fluvial, Ziguinchor", 12.5630f, -16.2740f, 150, "Tous les jours 06:00-19:00",
                "Le port fluvial sur le fleuve Casamance, point de départ de nombreuses traversées et lieu de vie de la ville.",
                note, "/images/allee-port.jpg"));

        repository.save(site("PAT-004", "Musée des arts", "MUSEE", "Ziguinchor",
                "Ziguinchor", 12.5810f, -16.2690f, 60, "Mar-Dim 10:00-17:00",
                "Musée consacré aux arts et aux traditions de la région.",
                note, "/images/musee-des-arts.jpg"));

        repository.save(site("PAT-005", "Plage de Cap Skirring", "SITE_NATUREL", "Cap Skirring",
                "Cap Skirring", 12.3920f, -16.7470f, 300, "Accès libre",
                "Grande plage de sable fin bordée de palmiers, sur la côte atlantique de la Casamance.",
                note, "/images/cap-skirring.avif"));

        repository.save(site("PAT-006", "Rives du fleuve Casamance", "SITE_NATUREL", "Ziguinchor",
                "Bords du fleuve, Ziguinchor", 12.5640f, -16.2680f, 200, "Accès libre",
                "Les berges du fleuve avec leurs pirogues colorées, leurs cocotiers et la vie des pêcheurs.",
                note, "/images/fleuve-casamance.jpg"));
    }

    private Patrimoine site(String code, String nom, String type, String ville, String adresse,
                            float lat, float lng, int capacite, String horaires,
                            String description, String historique, String image) {
        Patrimoine p = new Patrimoine();
        p.setCodePatrimoine(code);
        p.setNomPatrimoine(nom);
        p.setTypePatrimoine(type);
        p.setVillePatrimoine(ville);
        p.setAdressePatrimoine(adresse);
        p.setLatitudePatrimoine(lat);
        p.setLongitudePatrimoine(lng);
        p.setCapacitePatrimoine(capacite);
        p.setHorairesPatrimoine(horaires);
        p.setDescriptionPatrimoine(description);
        p.setHistoriquePatrimoine(historique);
        p.setImageUrl(image);
        return p;
    }
}
