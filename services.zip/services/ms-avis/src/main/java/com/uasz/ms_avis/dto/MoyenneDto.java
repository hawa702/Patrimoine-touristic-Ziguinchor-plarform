package com.uasz.ms_avis.dto;

public record MoyenneDto(Long cibleId, double moyenne, long nombre) {
}
