package com.uasz.ms_avis.dto;

import com.uasz.ms_avis.entities.StatutSignalement;

import java.time.LocalDateTime;

/** avis vaut null si l'avis signalé a déjà été supprimé. */
public record SignalementDto(Long id, Long avisId, String motif, Long auteurId,
                             StatutSignalement statut, LocalDateTime dateSignalement, AvisDto avis) {
}
