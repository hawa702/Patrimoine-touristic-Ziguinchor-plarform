package com.uasz.ms_avis.repositories;

import com.uasz.ms_avis.entities.Signalement;
import com.uasz.ms_avis.entities.StatutSignalement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SignalementRepository extends JpaRepository<Signalement, Long> {

    List<Signalement> findAllByOrderByDateSignalementDesc();

    List<Signalement> findByAvisId(Long avisId);

    boolean existsByAvisIdAndAuteurIdAndStatut(Long avisId, Long auteurId, StatutSignalement statut);
}
