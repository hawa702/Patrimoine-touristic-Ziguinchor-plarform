package com.uasz.ms_avis.entities;

public enum StatutSignalement {
    EN_ATTENTE,
    RESOLU
}
