package com.uasz.ms_avis.dto;

import com.uasz.ms_avis.entities.CibleType;

import java.time.LocalDateTime;

public record AvisDto(Long id, CibleType cibleType, Long cibleId, Long auteurId, String auteurNom,
                      int note, String commentaire, String reponse,
                      LocalDateTime datePublication, LocalDateTime dateReponse) {
}
