package com.uasz.ms_avis.controllers;

import com.uasz.ms_avis.dto.ResolutionRequest;
import com.uasz.ms_avis.dto.SignalementDto;
import com.uasz.ms_avis.services.AvisService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** Modération : réservé au conservateur (règle posée dans l'API Gateway). */
@RestController
@RequestMapping("/api/signalements")
public class SignalementController {

    private final AvisService avisService;

    public SignalementController(AvisService avisService) {
        this.avisService = avisService;
    }

    @GetMapping
    public List<SignalementDto> lister() {
        return avisService.listerSignalements();
    }

    // Clôture un signalement ; supprimerAvis=true supprime aussi l'avis signalé
    @PutMapping("/{id}/resoudre")
    public SignalementDto resoudre(@PathVariable Long id, @RequestBody ResolutionRequest request) {
        return avisService.resoudre(id, request.supprimerAvis());
    }
}
