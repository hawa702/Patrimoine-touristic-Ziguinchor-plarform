package com.uasz.ms_avis.entities;

/** Un avis porte soit sur un site (patrimoine), soit sur un guide. */
public enum CibleType {
    SITE,
    GUIDE
}
