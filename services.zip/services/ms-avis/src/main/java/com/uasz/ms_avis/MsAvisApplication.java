package com.uasz.ms_avis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsAvisApplication {

    public static void main(String[] args) {
        SpringApplication.run(MsAvisApplication.class, args);
    }
}
