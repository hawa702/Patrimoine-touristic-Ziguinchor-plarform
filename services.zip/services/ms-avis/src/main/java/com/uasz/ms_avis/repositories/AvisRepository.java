package com.uasz.ms_avis.repositories;

import com.uasz.ms_avis.entities.Avis;
import com.uasz.ms_avis.entities.CibleType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AvisRepository extends JpaRepository<Avis, Long> {

    List<Avis> findByCibleTypeAndCibleIdOrderByDatePublicationDesc(CibleType cibleType, Long cibleId);

    List<Avis> findByCibleType(CibleType cibleType);

    List<Avis> findByAuteurIdOrderByDatePublicationDesc(Long auteurId);

    boolean existsByAuteurIdAndCibleTypeAndCibleId(Long auteurId, CibleType cibleType, Long cibleId);
}
