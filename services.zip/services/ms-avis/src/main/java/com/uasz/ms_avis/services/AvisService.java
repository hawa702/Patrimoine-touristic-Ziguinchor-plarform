package com.uasz.ms_avis.services;

import com.uasz.ms_avis.dto.*;
import com.uasz.ms_avis.entities.*;
import com.uasz.ms_avis.repositories.AvisRepository;
import com.uasz.ms_avis.repositories.SignalementRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class AvisService {

    private final AvisRepository avisRepository;
    private final SignalementRepository signalementRepository;

    public AvisService(AvisRepository avisRepository, SignalementRepository signalementRepository) {
        this.avisRepository = avisRepository;
        this.signalementRepository = signalementRepository;
    }

    // ------------------------------------------------------------------ avis

    public List<AvisDto> lister(CibleType type, Long cibleId) {
        return avisRepository.findByCibleTypeAndCibleIdOrderByDatePublicationDesc(type, cibleId).stream()
                .map(this::versDto).toList();
    }

    public List<AvisDto> mesAvis(Long auteurId) {
        return avisRepository.findByAuteurIdOrderByDatePublicationDesc(auteurId).stream()
                .map(this::versDto).toList();
    }

    /** Note moyenne (arrondie à 0,1) et nombre d'avis pour chaque site ou chaque guide. */
    public List<MoyenneDto> moyennes(CibleType type) {
        Map<Long, DoubleSummaryStatistics> stats = avisRepository.findByCibleType(type).stream()
                .collect(Collectors.groupingBy(Avis::getCibleId, Collectors.summarizingDouble(Avis::getNote)));
        return stats.entrySet().stream()
                .map(e -> new MoyenneDto(e.getKey(),
                        Math.round(e.getValue().getAverage() * 10.0) / 10.0,
                        e.getValue().getCount()))
                .toList();
    }

    @Transactional
    public AvisDto creer(Long auteurId, String auteurNom, AvisRequest r) {
        if (r.cibleType() == null || r.cibleId() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "cibleType et cibleId sont obligatoires");
        }
        if (r.note() < 1 || r.note() > 5) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "La note doit être comprise entre 1 et 5");
        }
        if (r.commentaire() != null && r.commentaire().length() > 2000) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Commentaire trop long (2000 caractères max)");
        }
        if (avisRepository.existsByAuteurIdAndCibleTypeAndCibleId(auteurId, r.cibleType(), r.cibleId())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Vous avez déjà donné votre avis");
        }
        Avis avis = new Avis();
        avis.setCibleType(r.cibleType());
        avis.setCibleId(r.cibleId());
        avis.setAuteurId(auteurId);
        avis.setAuteurNom(auteurNom);
        avis.setNote(r.note());
        avis.setCommentaire(r.commentaire());
        return versDto(avisRepository.save(avis));
    }

    /** Seul le guide concerné par l'avis peut y répondre. */
    @Transactional
    public AvisDto repondre(Long guideId, Long avisId, String reponse) {
        Avis avis = trouver(avisId);
        if (avis.getCibleType() != CibleType.GUIDE || !avis.getCibleId().equals(guideId)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Cet avis ne vous concerne pas");
        }
        if (reponse == null || reponse.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "La réponse est vide");
        }
        avis.setReponse(reponse.trim());
        avis.setDateReponse(LocalDateTime.now());
        return versDto(avisRepository.save(avis));
    }

    /** Suppression par le conservateur : les signalements liés sont clôturés. */
    @Transactional
    public void supprimer(Long avisId) {
        Avis avis = trouver(avisId);
        signalementRepository.findByAvisId(avisId).forEach(s -> {
            s.setStatut(StatutSignalement.RESOLU);
            signalementRepository.save(s);
        });
        avisRepository.delete(avis);
    }

    // ---------------------------------------------------------- signalements

    /** Un guide signale un avis qui le concerne ; le conservateur peut signaler n'importe quel avis. */
    @Transactional
    public SignalementDto signaler(Long userId, String role, Long avisId, String motif) {
        Avis avis = trouver(avisId);
        boolean admin = "ADMIN".equals(role);
        if (!admin && (avis.getCibleType() != CibleType.GUIDE || !avis.getCibleId().equals(userId))) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Cet avis ne vous concerne pas");
        }
        if (motif == null || motif.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Le motif est obligatoire");
        }
        if (signalementRepository.existsByAvisIdAndAuteurIdAndStatut(avisId, userId, StatutSignalement.EN_ATTENTE)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Cet avis est déjà signalé");
        }
        Signalement s = new Signalement();
        s.setAvisId(avisId);
        s.setAuteurId(userId);
        s.setMotif(motif.trim());
        return signalementDto(signalementRepository.save(s));
    }

    public List<SignalementDto> listerSignalements() {
        return signalementRepository.findAllByOrderByDateSignalementDesc().stream()
                .map(this::signalementDto).toList();
    }

    @Transactional
    public SignalementDto resoudre(Long signalementId, boolean supprimerAvis) {
        Signalement s = signalementRepository.findById(signalementId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Signalement introuvable"));
        if (supprimerAvis && avisRepository.existsById(s.getAvisId())) {
            supprimer(s.getAvisId());
            s = signalementRepository.findById(signalementId).orElse(s);
        }
        s.setStatut(StatutSignalement.RESOLU);
        return signalementDto(signalementRepository.save(s));
    }

    // ---------------------------------------------------------------------

    private Avis trouver(Long id) {
        return avisRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Avis introuvable"));
    }

    private AvisDto versDto(Avis a) {
        return new AvisDto(a.getId(), a.getCibleType(), a.getCibleId(), a.getAuteurId(), a.getAuteurNom(),
                a.getNote(), a.getCommentaire(), a.getReponse(), a.getDatePublication(), a.getDateReponse());
    }

    private SignalementDto signalementDto(Signalement s) {
        AvisDto avis = avisRepository.findById(s.getAvisId()).map(this::versDto).orElse(null);
        return new SignalementDto(s.getId(), s.getAvisId(), s.getMotif(), s.getAuteurId(),
                s.getStatut(), s.getDateSignalement(), avis);
    }
}
