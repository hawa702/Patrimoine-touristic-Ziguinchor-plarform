package com.uasz.ms_avis.entities;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
public class Signalement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long avisId;

    @Column(nullable = false, length = 1000)
    private String motif;

    @Column(nullable = false)
    private Long auteurId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private StatutSignalement statut = StatutSignalement.EN_ATTENTE;

    private LocalDateTime dateSignalement = LocalDateTime.now();

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getAvisId() { return avisId; }
    public void setAvisId(Long avisId) { this.avisId = avisId; }
    public String getMotif() { return motif; }
    public void setMotif(String motif) { this.motif = motif; }
    public Long getAuteurId() { return auteurId; }
    public void setAuteurId(Long auteurId) { this.auteurId = auteurId; }
    public StatutSignalement getStatut() { return statut; }
    public void setStatut(StatutSignalement statut) { this.statut = statut; }
    public LocalDateTime getDateSignalement() { return dateSignalement; }
    public void setDateSignalement(LocalDateTime dateSignalement) { this.dateSignalement = dateSignalement; }
}
