package com.uasz.ms_avis.dto;

public record ResolutionRequest(boolean supprimerAvis) {
}
