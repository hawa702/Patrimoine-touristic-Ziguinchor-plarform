package com.uasz.ms_avis.entities;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
public class Avis {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private CibleType cibleType;

    @Column(nullable = false)
    private Long cibleId;          // id du patrimoine (SITE) ou de l'utilisateur guide (GUIDE)

    @Column(nullable = false)
    private Long auteurId;         // id de l'utilisateur (ms-auth)

    private String auteurNom;

    @Column(nullable = false)
    private int note;              // 1 à 5

    @Column(length = 2000)
    private String commentaire;

    @Column(length = 2000)
    private String reponse;        // réponse du guide

    private LocalDateTime datePublication = LocalDateTime.now();

    private LocalDateTime dateReponse;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public CibleType getCibleType() { return cibleType; }
    public void setCibleType(CibleType cibleType) { this.cibleType = cibleType; }
    public Long getCibleId() { return cibleId; }
    public void setCibleId(Long cibleId) { this.cibleId = cibleId; }
    public Long getAuteurId() { return auteurId; }
    public void setAuteurId(Long auteurId) { this.auteurId = auteurId; }
    public String getAuteurNom() { return auteurNom; }
    public void setAuteurNom(String auteurNom) { this.auteurNom = auteurNom; }
    public int getNote() { return note; }
    public void setNote(int note) { this.note = note; }
    public String getCommentaire() { return commentaire; }
    public void setCommentaire(String commentaire) { this.commentaire = commentaire; }
    public String getReponse() { return reponse; }
    public void setReponse(String reponse) { this.reponse = reponse; }
    public LocalDateTime getDatePublication() { return datePublication; }
    public void setDatePublication(LocalDateTime datePublication) { this.datePublication = datePublication; }
    public LocalDateTime getDateReponse() { return dateReponse; }
    public void setDateReponse(LocalDateTime dateReponse) { this.dateReponse = dateReponse; }
}
