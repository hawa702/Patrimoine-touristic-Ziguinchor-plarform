package com.uasz.ms_avis.controllers;

import com.uasz.ms_avis.dto.*;
import com.uasz.ms_avis.entities.CibleType;
import com.uasz.ms_avis.services.AvisService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * Les en-têtes X-User-Id, X-User-Role et X-User-Name sont posés par l'API Gateway
 * après validation du JWT (le nom est encodé en URL pour supporter les accents).
 */
@RestController
@RequestMapping("/api/avis")
public class AvisController {

    private final AvisService avisService;

    public AvisController(AvisService avisService) {
        this.avisService = avisService;
    }

    // Public : avis d'un site ou d'un guide  ex : /api/avis?cibleType=SITE&cibleId=1
    @GetMapping
    public List<AvisDto> lister(@RequestParam CibleType cibleType, @RequestParam Long cibleId) {
        return avisService.lister(cibleType, cibleId);
    }

    // Public : notes moyennes  ex : /api/avis/moyennes?cibleType=SITE
    @GetMapping("/moyennes")
    public List<MoyenneDto> moyennes(@RequestParam CibleType cibleType) {
        return avisService.moyennes(cibleType);
    }

    // Touriste : les avis que j'ai déjà déposés
    @GetMapping("/mes")
    public List<AvisDto> mesAvis(@RequestHeader(value = "X-User-Id", required = false) Long userId) {
        return avisService.mesAvis(exiger(userId));
    }

    // Touriste : déposer un avis (note de 1 à 5 + commentaire)
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public AvisDto creer(@RequestHeader(value = "X-User-Id", required = false) Long userId,
                         @RequestHeader(value = "X-User-Name", required = false) String nom,
                         @RequestBody AvisRequest request) {
        String auteur = nom == null ? "Anonyme" : URLDecoder.decode(nom, StandardCharsets.UTF_8);
        return avisService.creer(exiger(userId), auteur, request);
    }

    // Guide : répondre à un avis qui le concerne
    @PutMapping("/{id}/reponse")
    public AvisDto repondre(@PathVariable Long id,
                            @RequestHeader(value = "X-User-Id", required = false) Long userId,
                            @RequestBody ReponseRequest request) {
        return avisService.repondre(exiger(userId), id, request.reponse());
    }

    // Guide (ou conservateur) : signaler un avis abusif
    @PostMapping("/{id}/signaler")
    @ResponseStatus(HttpStatus.CREATED)
    public SignalementDto signaler(@PathVariable Long id,
                                   @RequestHeader(value = "X-User-Id", required = false) Long userId,
                                   @RequestHeader(value = "X-User-Role", required = false) String role,
                                   @RequestBody SignalementRequest request) {
        return avisService.signaler(exiger(userId), role, id, request.motif());
    }

    // Conservateur : suppression d'un avis (modération)
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> supprimer(@PathVariable Long id) {
        avisService.supprimer(id);
        return ResponseEntity.noContent().build();
    }

    private Long exiger(Long userId) {
        if (userId == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Connexion requise");
        }
        return userId;
    }
}
