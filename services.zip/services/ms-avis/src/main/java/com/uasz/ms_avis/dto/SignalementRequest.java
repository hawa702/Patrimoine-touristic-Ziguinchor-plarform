package com.uasz.ms_avis.dto;

public record SignalementRequest(String motif) {
}
