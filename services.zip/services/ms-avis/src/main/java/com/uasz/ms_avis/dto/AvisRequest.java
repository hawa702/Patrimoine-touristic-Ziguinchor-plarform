package com.uasz.ms_avis.dto;

import com.uasz.ms_avis.entities.CibleType;

public record AvisRequest(CibleType cibleType, Long cibleId, int note, String commentaire) {
}
