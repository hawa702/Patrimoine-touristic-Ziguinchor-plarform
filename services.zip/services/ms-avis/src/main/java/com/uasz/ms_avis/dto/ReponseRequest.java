package com.uasz.ms_avis.dto;

public record ReponseRequest(String reponse) {
}
