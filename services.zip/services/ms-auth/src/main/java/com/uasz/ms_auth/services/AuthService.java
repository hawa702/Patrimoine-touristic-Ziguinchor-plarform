package com.uasz.ms_auth.services;

import com.uasz.ms_auth.dto.*;
import com.uasz.ms_auth.entities.GuideDetails;
import com.uasz.ms_auth.entities.Role;
import com.uasz.ms_auth.entities.User;
import com.uasz.ms_auth.repositories.GuideDetailsRepository;
import com.uasz.ms_auth.repositories.UserRepository;
import com.uasz.ms_auth.security.JwtService;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
public class AuthService {

    private final UserRepository users;
    private final GuideDetailsRepository guides;
    private final PasswordEncoder encoder;
    private final JwtService jwt;

    public AuthService(UserRepository users, GuideDetailsRepository guides,
                       PasswordEncoder encoder, JwtService jwt) {
        this.users = users;
        this.guides = guides;
        this.encoder = encoder;
        this.jwt = jwt;
    }

    /** Inscription d'un touriste : compte actif immédiatement. */
    @Transactional
    public AuthResponse inscrireTouriste(RegisterRequest r) {
        String email = normaliser(r.email());
        valider(r.nom(), email, r.password());
        User user = creer(r.nom().trim(), email, r.password(), Role.TOURIST);
        return reponse(user);
    }

    /** Inscription d'un guide : le compte existe mais doit être validé par le conservateur. */
    @Transactional
    public AuthResponse inscrireGuide(GuideRegisterRequest r) {
        String email = normaliser(r.email());
        valider(r.nom(), email, r.password());
        if (r.numeroLicence() == null || r.numeroLicence().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Le numéro de licence est obligatoire");
        }
        User user = creer(r.nom().trim(), email, r.password(), Role.GUIDE);
        GuideDetails fiche = new GuideDetails();
        fiche.setUserId(user.getId());
        fiche.setNumeroLicence(r.numeroLicence().trim());
        fiche.setBiographie(r.biographie());
        fiche.setLangues(r.langues());
        fiche.setEstVerifie(false);
        guides.save(fiche);
        return reponse(user);
    }

    public AuthResponse connecter(LoginRequest r) {
        String email = normaliser(r.email());
        User user = users.findByEmail(email)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED,
                        "Email ou mot de passe incorrect"));
        if (r.password() == null || !encoder.matches(r.password(), user.getPasswordHash())) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Email ou mot de passe incorrect");
        }
        if (!user.isActif()) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Ce compte est désactivé");
        }
        return reponse(user);
    }

    public UserDto moi(Long userId) {
        User user = users.findById(userId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Utilisateur introuvable"));
        return versDto(user);
    }

    // ---------------------------------------------------------------------

    private User creer(String nom, String email, String motDePasse, Role role) {
        if (users.existsByEmail(email)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Un compte existe déjà avec cet email");
        }
        User user = new User();
        user.setNom(nom);
        user.setEmail(email);
        user.setPasswordHash(encoder.encode(motDePasse));
        user.setRole(role);
        return users.save(user);
    }

    private AuthResponse reponse(User user) {
        return new AuthResponse(jwt.generer(user), versDto(user));
    }

    private UserDto versDto(User user) {
        boolean verifie = true;
        if (user.getRole() == Role.GUIDE) {
            verifie = guides.findByUserId(user.getId()).map(GuideDetails::isEstVerifie).orElse(false);
        }
        return new UserDto(user.getId(), user.getNom(), user.getEmail(), user.getRole().name(), verifie);
    }

    private String normaliser(String email) {
        return email == null ? "" : email.trim().toLowerCase();
    }

    private void valider(String nom, String email, String motDePasse) {
        if (nom == null || nom.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Le nom est obligatoire");
        }
        if (!email.contains("@") || !email.contains(".")) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Email invalide");
        }
        if (motDePasse == null || motDePasse.length() < 6) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Le mot de passe doit contenir au moins 6 caractères");
        }
    }
}
