package com.uasz.ms_auth.dto;

public record GuideRegisterRequest(String nom, String email, String password,
                                   String numeroLicence, String biographie, String langues) {
}
