package com.uasz.ms_auth.dto;

public record GuideUpdateRequest(String nom, String numeroLicence, String biographie, String langues) {
}
