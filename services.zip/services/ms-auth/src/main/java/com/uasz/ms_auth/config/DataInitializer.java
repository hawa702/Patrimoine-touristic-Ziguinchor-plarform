package com.uasz.ms_auth.config;

import com.uasz.ms_auth.entities.GuideDetails;
import com.uasz.ms_auth.entities.Role;
import com.uasz.ms_auth.entities.User;
import com.uasz.ms_auth.repositories.GuideDetailsRepository;
import com.uasz.ms_auth.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/** Comptes de démonstration (mot de passe : password123), créés uniquement si la base est vide. */
@Component
public class DataInitializer implements CommandLineRunner {

    private final UserRepository users;
    private final GuideDetailsRepository guides;
    private final PasswordEncoder encoder;
    private final boolean actif;

    public DataInitializer(UserRepository users, GuideDetailsRepository guides, PasswordEncoder encoder,
                           @Value("${app.seed-demo-users:true}") boolean actif) {
        this.users = users;
        this.guides = guides;
        this.encoder = encoder;
        this.actif = actif;
    }

    @Override
    public void run(String... args) {
        if (!actif || users.count() > 0) {
            return;
        }
        creer("Conservateur Principal", "conservateur@patrimoine.sn", Role.ADMIN);
        creer("Touriste Demo", "touriste@patrimoine.sn", Role.TOURIST);

        User guide = creer("Guide Demo", "guide@patrimoine.sn", Role.GUIDE);
        GuideDetails fiche = new GuideDetails();
        fiche.setUserId(guide.getId());
        fiche.setNumeroLicence("LIC-0001");
        fiche.setBiographie("Guide passionné par la Casamance, histoire et culture locale.");
        fiche.setLangues("Français, Anglais, Diola");
        fiche.setEstVerifie(true);
        guides.save(fiche);
    }

    private User creer(String nom, String email, Role role) {
        User u = new User();
        u.setNom(nom);
        u.setEmail(email);
        u.setPasswordHash(encoder.encode("password123"));
        u.setRole(role);
        return users.save(u);
    }
}
