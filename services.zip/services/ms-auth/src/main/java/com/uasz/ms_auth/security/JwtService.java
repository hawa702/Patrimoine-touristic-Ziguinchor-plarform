package com.uasz.ms_auth.security;

import com.uasz.ms_auth.entities.User;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

/** Émet les JWT (HS256). La validation est faite par l'API Gateway avec le même secret. */
@Component
public class JwtService {

    private final SecretKey key;
    private final long dureeMs;

    public JwtService(@Value("${jwt.secret}") String secret,
                      @Value("${jwt.expiration-minutes}") long minutes) {
        byte[] octets = secret.getBytes(StandardCharsets.UTF_8);
        if (octets.length < 32) {
            throw new IllegalStateException("jwt.secret doit contenir au moins 32 caractères");
        }
        this.key = Keys.hmacShaKeyFor(octets);
        this.dureeMs = minutes * 60_000L;
    }

    public String generer(User user) {
        long maintenant = System.currentTimeMillis();
        return Jwts.builder()
                .subject(String.valueOf(user.getId()))
                .claim("role", user.getRole().name())
                .claim("email", user.getEmail())
                .claim("name", user.getNom())
                .issuedAt(new Date(maintenant))
                .expiration(new Date(maintenant + dureeMs))
                .signWith(key)
                .compact();
    }
}
