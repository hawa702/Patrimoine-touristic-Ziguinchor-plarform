package com.uasz.ms_auth.dto;

/** Ce que voit tout visiteur : pas d'email ni de numéro de licence. */
public record GuidePublicDto(Long id, String nom, String biographie, String langues) {
}
