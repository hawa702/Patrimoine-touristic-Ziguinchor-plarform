package com.uasz.ms_auth.dto;

/** estVerifie : toujours true sauf pour un guide dont le compte n'est pas encore validé. */
public record UserDto(Long id, String nom, String email, String role, boolean estVerifie) {
}
