package com.uasz.ms_auth.dto;

public record RegisterRequest(String nom, String email, String password) {
}
