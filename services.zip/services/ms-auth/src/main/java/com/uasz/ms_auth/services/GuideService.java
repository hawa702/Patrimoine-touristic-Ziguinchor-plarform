package com.uasz.ms_auth.services;

import com.uasz.ms_auth.dto.GuideAdminDto;
import com.uasz.ms_auth.dto.GuidePublicDto;
import com.uasz.ms_auth.dto.GuideUpdateRequest;
import com.uasz.ms_auth.entities.GuideDetails;
import com.uasz.ms_auth.entities.Role;
import com.uasz.ms_auth.entities.User;
import com.uasz.ms_auth.repositories.GuideDetailsRepository;
import com.uasz.ms_auth.repositories.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class GuideService {

    private final UserRepository users;
    private final GuideDetailsRepository guides;

    public GuideService(UserRepository users, GuideDetailsRepository guides) {
        this.users = users;
        this.guides = guides;
    }

    /** Guides validés (annuaire public). */
    public List<GuidePublicDto> listerVerifies() {
        return guides.findByEstVerifie(true).stream()
                .map(g -> users.findById(g.getUserId()).filter(User::isActif).map(u -> versPublic(u, g)).orElse(null))
                .filter(d -> d != null)
                .toList();
    }

    public GuidePublicDto getPublic(Long userId) {
        GuideDetails fiche = fiche(userId);
        User user = utilisateur(userId);
        if (!fiche.isEstVerifie() || !user.isActif()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Guide introuvable");
        }
        return versPublic(user, fiche);
    }

    /** Comptes guides en attente de validation (conservateur). */
    public List<GuideAdminDto> listerEnAttente() {
        return guides.findByEstVerifie(false).stream()
                .map(g -> users.findById(g.getUserId()).filter(User::isActif).map(u -> versAdmin(u, g)).orElse(null))
                .filter(d -> d != null)
                .toList();
    }

    @Transactional
    public GuideAdminDto valider(Long userId) {
        GuideDetails fiche = fiche(userId);
        fiche.setEstVerifie(true);
        guides.save(fiche);
        return versAdmin(utilisateur(userId), fiche);
    }

    /** Refus : le compte est désactivé (il ne pourra plus se connecter). */
    @Transactional
    public void refuser(Long userId) {
        User user = utilisateur(userId);
        if (user.getRole() != Role.GUIDE) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Ce compte n'est pas un guide");
        }
        user.setActif(false);
        users.save(user);
    }

    public GuideAdminDto moi(Long userId) {
        return versAdmin(utilisateur(userId), fiche(userId));
    }

    @Transactional
    public GuideAdminDto mettreAJour(Long userId, GuideUpdateRequest r) {
        User user = utilisateur(userId);
        GuideDetails fiche = fiche(userId);
        if (r.nom() != null && !r.nom().isBlank()) {
            user.setNom(r.nom().trim());
            users.save(user);
        }
        if (r.numeroLicence() != null && !r.numeroLicence().isBlank()) {
            fiche.setNumeroLicence(r.numeroLicence().trim());
        }
        fiche.setBiographie(r.biographie());
        fiche.setLangues(r.langues());
        guides.save(fiche);
        return versAdmin(user, fiche);
    }

    // ---------------------------------------------------------------------

    private User utilisateur(Long userId) {
        return users.findById(userId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Utilisateur introuvable"));
    }

    private GuideDetails fiche(Long userId) {
        return guides.findByUserId(userId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Fiche guide introuvable"));
    }

    private GuidePublicDto versPublic(User u, GuideDetails g) {
        return new GuidePublicDto(u.getId(), u.getNom(), g.getBiographie(), g.getLangues());
    }

    private GuideAdminDto versAdmin(User u, GuideDetails g) {
        return new GuideAdminDto(u.getId(), u.getNom(), u.getEmail(), g.getNumeroLicence(),
                g.getBiographie(), g.getLangues(), g.isEstVerifie(), u.getDateCreation());
    }
}
