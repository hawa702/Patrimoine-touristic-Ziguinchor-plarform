package com.uasz.ms_auth.controllers;

import com.uasz.ms_auth.dto.GuideAdminDto;
import com.uasz.ms_auth.dto.GuidePublicDto;
import com.uasz.ms_auth.dto.GuideUpdateRequest;
import com.uasz.ms_auth.services.GuideService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/guides")
public class GuideController {

    private final GuideService guideService;

    public GuideController(GuideService guideService) {
        this.guideService = guideService;
    }

    // Public : annuaire des guides validés
    @GetMapping
    public List<GuidePublicDto> listerVerifies() {
        return guideService.listerVerifies();
    }

    // Conservateur : comptes guides à valider
    @GetMapping("/en-attente")
    public List<GuideAdminDto> listerEnAttente() {
        return guideService.listerEnAttente();
    }

    // Guide connecté : son profil professionnel
    @GetMapping("/me")
    public GuideAdminDto moi(@RequestHeader(value = "X-User-Id", required = false) Long userId) {
        return guideService.moi(exiger(userId));
    }

    @PutMapping("/me")
    public GuideAdminDto mettreAJour(@RequestHeader(value = "X-User-Id", required = false) Long userId,
                                     @RequestBody GuideUpdateRequest request) {
        return guideService.mettreAJour(exiger(userId), request);
    }

    // Public : fiche d'un guide validé
    @GetMapping("/{id}")
    public GuidePublicDto getPublic(@PathVariable Long id) {
        return guideService.getPublic(id);
    }

    // Conservateur : validation / refus
    @PutMapping("/{id}/valider")
    public GuideAdminDto valider(@PathVariable Long id) {
        return guideService.valider(id);
    }

    @PutMapping("/{id}/refuser")
    public ResponseEntity<Void> refuser(@PathVariable Long id) {
        guideService.refuser(id);
        return ResponseEntity.noContent().build();
    }

    private Long exiger(Long userId) {
        if (userId == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Connexion requise");
        }
        return userId;
    }
}
