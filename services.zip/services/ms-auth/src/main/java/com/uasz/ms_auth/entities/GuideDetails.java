package com.uasz.ms_auth.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "guide_details")
public class GuideDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private Long userId;

    private String numeroLicence;

    @Column(length = 2000)
    private String biographie;

    private String langues;

    private boolean estVerifie = false;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getNumeroLicence() { return numeroLicence; }
    public void setNumeroLicence(String numeroLicence) { this.numeroLicence = numeroLicence; }
    public String getBiographie() { return biographie; }
    public void setBiographie(String biographie) { this.biographie = biographie; }
    public String getLangues() { return langues; }
    public void setLangues(String langues) { this.langues = langues; }
    public boolean isEstVerifie() { return estVerifie; }
    public void setEstVerifie(boolean estVerifie) { this.estVerifie = estVerifie; }
}
