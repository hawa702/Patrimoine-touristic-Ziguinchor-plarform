package com.uasz.ms_auth.dto;

public record LoginRequest(String email, String password) {
}
