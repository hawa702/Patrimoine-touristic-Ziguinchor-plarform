package com.uasz.ms_auth.dto;

import java.time.LocalDateTime;

/** Vue complète : conservateur (validation) et guide lui-même (profil). */
public record GuideAdminDto(Long id, String nom, String email, String numeroLicence,
                            String biographie, String langues, boolean estVerifie,
                            LocalDateTime dateCreation) {
}
