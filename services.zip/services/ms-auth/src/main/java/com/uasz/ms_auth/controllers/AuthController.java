package com.uasz.ms_auth.controllers;

import com.uasz.ms_auth.dto.*;
import com.uasz.ms_auth.services.AuthService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public AuthResponse inscrireTouriste(@RequestBody RegisterRequest request) {
        return authService.inscrireTouriste(request);
    }

    @PostMapping("/register-guide")
    @ResponseStatus(HttpStatus.CREATED)
    public AuthResponse inscrireGuide(@RequestBody GuideRegisterRequest request) {
        return authService.inscrireGuide(request);
    }

    @PostMapping("/login")
    public AuthResponse connecter(@RequestBody LoginRequest request) {
        return authService.connecter(request);
    }

    /** X-User-Id est posé par l'API Gateway après validation du JWT. */
    @GetMapping("/me")
    public UserDto moi(@RequestHeader(value = "X-User-Id", required = false) Long userId) {
        if (userId == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Connexion requise");
        }
        return authService.moi(userId);
    }
}
