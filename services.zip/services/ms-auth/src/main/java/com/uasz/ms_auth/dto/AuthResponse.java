package com.uasz.ms_auth.dto;

public record AuthResponse(String token, UserDto user) {
}
