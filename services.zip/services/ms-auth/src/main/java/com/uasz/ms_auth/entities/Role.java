package com.uasz.ms_auth.entities;

public enum Role {
    TOURIST,   // touriste
    GUIDE,     // guide (compte à valider par le conservateur)
    ADMIN      // conservateur
}
