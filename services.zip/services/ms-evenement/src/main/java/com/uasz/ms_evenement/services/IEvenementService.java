package com.uasz.ms_evenement.services;

import com.uasz.ms_evenement.entities.Evenement;

import java.util.List;
import java.util.Optional;

public interface IEvenementService {
    // CREATE
    Evenement saveEvenement(Evenement evenement);

    // READ ALL
    List<Evenement> getAllEvenements();

    // READ ONE
    Optional<Evenement> getByIdEvenement(Long id);

    // READ par patrimoine
    List<Evenement> getEvenementsByPatrimoine(Long patrimoineId);

    // READ par guide (agenda du guide)
    List<Evenement> getEvenementsByGuide(Long guideId);

    // UPDATE
    Evenement updateEvenement(Long id, Evenement newEvenement);

    // DELETE
    void deleteEvenement(Long id);
}
