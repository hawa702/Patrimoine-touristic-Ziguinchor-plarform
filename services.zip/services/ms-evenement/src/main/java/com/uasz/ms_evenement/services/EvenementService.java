package com.uasz.ms_evenement.services;

import com.uasz.ms_evenement.clients.PatrimoineClient;
import com.uasz.ms_evenement.entities.Evenement;
import com.uasz.ms_evenement.repositories.EvenementRepository;
import feign.FeignException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

@Service
public class EvenementService implements IEvenementService {

    @Autowired
    EvenementRepository evenementRepository;

    @Autowired
    PatrimoineClient patrimoineClient;   // communication avec ms-patrimoine (OpenFeign)

    // CREATE
    @Override
    public Evenement saveEvenement(Evenement evenement) {
        valider(evenement);
        evenement.setId(null);
        return evenementRepository.save(evenement);
    }

    // READ ALL
    @Override
    public List<Evenement> getAllEvenements() {
        return evenementRepository.findAll();
    }

    // READ ONE
    @Override
    public Optional<Evenement> getByIdEvenement(Long id) {
        return evenementRepository.findById(id);
    }

    // READ par patrimoine
    @Override
    public List<Evenement> getEvenementsByPatrimoine(Long patrimoineId) {
        return evenementRepository.findByPatrimoineId(patrimoineId);
    }

    // READ par guide
    @Override
    public List<Evenement> getEvenementsByGuide(Long guideId) {
        return evenementRepository.findByGuideIdOrderByDateDebutAsc(guideId);
    }

    // UPDATE
    @Override
    public Evenement updateEvenement(Long id, Evenement newEvenement) {
        Evenement evenement = evenementRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "Evenement non trouvé avec l'id : " + id));
        valider(newEvenement);
        evenement.setTitre(newEvenement.getTitre());
        evenement.setDescription(newEvenement.getDescription());
        evenement.setType(newEvenement.getType());
        evenement.setDateDebut(newEvenement.getDateDebut());
        evenement.setDateFin(newEvenement.getDateFin());
        evenement.setLieu(newEvenement.getLieu());
        evenement.setPatrimoineId(newEvenement.getPatrimoineId());
        evenement.setPlacesMax(newEvenement.getPlacesMax());
        evenement.setGuideId(newEvenement.getGuideId());
        evenement.setGuideNom(newEvenement.getGuideNom());
        return evenementRepository.save(evenement);
    }

    // DELETE
    @Override
    public void deleteEvenement(Long id) {
        evenementRepository.deleteById(id);
    }

    // ---------------------------------------------------------------------
    // Méthodes privées
    // ---------------------------------------------------------------------

    private void valider(Evenement e) {
        if (e.getTitre() == null || e.getTitre().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Le titre est obligatoire");
        }
        if (e.getDateDebut() != null && e.getDateFin() != null && e.getDateFin().isBefore(e.getDateDebut())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "La date de fin précède la date de début");
        }
        verifierPatrimoine(e.getPatrimoineId());
    }

    /** Le site qui accueille l'évènement doit exister dans ms-patrimoine. */
    private void verifierPatrimoine(Long patrimoineId) {
        if (patrimoineId == null) {
            return;
        }
        try {
            patrimoineClient.getPatrimoineById(patrimoineId);
        } catch (FeignException.NotFound e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Patrimoine introuvable : " + patrimoineId);
        } catch (FeignException e) {
            throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,
                    "ms-patrimoine est indisponible, réessayez plus tard");
        }
    }
}
