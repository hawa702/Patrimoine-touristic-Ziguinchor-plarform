package com.uasz.ms_evenement.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Evenement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String titre;
    @Column(length = 2000)
    private String description;

    @Enumerated(EnumType.STRING)
    private TypeEvenement type;

    private LocalDateTime dateDebut;
    private LocalDateTime dateFin;
    private String lieu;             // lieu précis sur le site
    private Long patrimoineId;       // référence vers ms-patrimoine (site qui accueille l'événement)
    private int placesMax;           // nombre de places maximales disponibles
    private Long guideId;            // id du guide (utilisateur de ms-auth) assigné à une visite guidée
    private String guideNom;         // nom du guide, copié pour l'affichage
}
