package com.uasz.gateway;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** Table de routage : quel préfixe d'URL est envoyé vers quel microservice. */
@Configuration
public class RoutesConfig {

    @Bean
    public RouteLocator routes(RouteLocatorBuilder builder,
                               @Value("${services.auth.url}") String auth,
                               @Value("${services.avis.url}") String avis,
                               @Value("${services.patrimoine.url}") String patrimoine,
                               @Value("${services.circuit.url}") String circuit,
                               @Value("${services.evenement.url}") String evenement,
                               @Value("${services.reservation.url}") String reservation) {
        return builder.routes()
                .route("ms-auth", r -> r.path("/api/auth/**", "/api/guides/**").uri(auth))
                .route("ms-avis", r -> r.path("/api/avis/**", "/api/signalements/**").uri(avis))
                .route("ms-patrimoine", r -> r.path("/api/patrimoines/**").uri(patrimoine))
                .route("ms-circuit", r -> r.path("/api/circuits/**").uri(circuit))
                .route("ms-evenement", r -> r.path("/api/evenements/**").uri(evenement))
                .route("ms-reservation", r -> r.path("/api/reservations/**").uri(reservation))
                .build();
    }
}
