package com.uasz.gateway;

import java.util.Set;

/**
 * Une règle d'accès : méthode HTTP ("*" = toutes) + motif d'URL (style Ant) + qui a le droit.
 * PUBLIC = tout le monde ; AUTHENTICATED = toute personne connectée ; ROLES = liste de rôles autorisés.
 */
public record AccessRule(String method, String pattern, Access access, Set<String> roles) {

    public enum Access { PUBLIC, AUTHENTICATED, ROLES }

    public static AccessRule publicRule(String method, String pattern) {
        return new AccessRule(method, pattern, Access.PUBLIC, Set.of());
    }

    public static AccessRule authenticated(String method, String pattern) {
        return new AccessRule(method, pattern, Access.AUTHENTICATED, Set.of());
    }

    public static AccessRule roles(String method, String pattern, String... roles) {
        return new AccessRule(method, pattern, Access.ROLES, Set.of(roles));
    }
}
