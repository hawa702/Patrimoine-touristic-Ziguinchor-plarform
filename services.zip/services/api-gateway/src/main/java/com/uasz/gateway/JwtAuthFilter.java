package com.uasz.gateway;

import io.jsonwebtoken.Claims;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

import static com.uasz.gateway.AccessRule.*;

/**
 * Filtre global : pour chaque requête
 *   1. supprime les en-têtes X-User-* envoyés par le client (anti-usurpation) ;
 *   2. valide le JWT (Authorization: Bearer ...) ;
 *   3. applique la première règle d'accès qui correspond (méthode + URL) ;
 *   4. transmet l'identité aux microservices via X-User-Id, X-User-Role, X-User-Email, X-User-Name.
 */
@Component
public class JwtAuthFilter implements GlobalFilter, Ordered {

    private static final String ADMIN = "ADMIN";
    private static final String GUIDE = "GUIDE";
    private static final String TOURIST = "TOURIST";

    private static final List<String> ENTETES_IDENTITE =
            List.of("X-User-Id", "X-User-Role", "X-User-Email", "X-User-Name");

    /** L'ordre compte : la première règle qui correspond est appliquée. */
    private static final List<AccessRule> REGLES = List.of(
            // --- Authentification
            publicRule("POST", "/api/auth/login"),
            publicRule("POST", "/api/auth/register"),
            publicRule("POST", "/api/auth/register-guide"),
            authenticated("GET", "/api/auth/me"),

            // --- Guides
            roles("GET", "/api/guides/en-attente", ADMIN),
            roles("GET", "/api/guides/me", GUIDE),
            roles("PUT", "/api/guides/me", GUIDE),
            roles("PUT", "/api/guides/*/valider", ADMIN),
            roles("PUT", "/api/guides/*/refuser", ADMIN),
            publicRule("GET", "/api/guides"),
            publicRule("GET", "/api/guides/*"),

            // --- Avis et signalements
            roles("GET", "/api/avis/mes", TOURIST),
            publicRule("GET", "/api/avis"),
            publicRule("GET", "/api/avis/moyennes"),
            roles("POST", "/api/avis", TOURIST),
            roles("PUT", "/api/avis/*/reponse", GUIDE),
            roles("POST", "/api/avis/*/signaler", GUIDE, ADMIN),
            roles("DELETE", "/api/avis/*", ADMIN),
            roles("*", "/api/signalements/**", ADMIN),

            // --- Réservations
            publicRule("GET", "/api/reservations/disponibilite"),
            roles("GET", "/api/reservations", ADMIN),
            roles("GET", "/api/reservations/mes", TOURIST, ADMIN),
            roles("POST", "/api/reservations", TOURIST, ADMIN),
            roles("GET", "/api/reservations/*", TOURIST, ADMIN),
            roles("GET", "/api/reservations/*/qrcode", TOURIST, ADMIN),
            roles("PUT", "/api/reservations/*/confirmer", TOURIST, ADMIN),
            roles("PUT", "/api/reservations/*/annuler", TOURIST, ADMIN),

            // --- Catalogue : lecture publique, écriture réservée au conservateur
            publicRule("GET", "/api/patrimoines/**"),
            publicRule("GET", "/api/circuits/**"),
            publicRule("GET", "/api/evenements/**"),
            roles("*", "/api/patrimoines/**", ADMIN),
            roles("*", "/api/circuits/**", ADMIN),
            roles("*", "/api/evenements/**", ADMIN),

            // --- Tout le reste : conservateur uniquement
            roles("*", "/**", ADMIN)
    );

    private final AntPathMatcher matcher = new AntPathMatcher();
    private final JwtVerifier jwtVerifier;

    public JwtAuthFilter(JwtVerifier jwtVerifier) {
        this.jwtVerifier = jwtVerifier;
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest requete = exchange.getRequest();
        String methode = requete.getMethod().name();
        String chemin = requete.getURI().getPath();

        // Les pré-requêtes CORS passent sans contrôle
        if ("OPTIONS".equals(methode)) {
            return chain.filter(exchange);
        }

        Claims claims = lireClaims(requete);
        AccessRule regle = trouverRegle(methode, chemin);

        if (regle.access() != Access.PUBLIC) {
            if (claims == null) {
                return refuser(exchange, HttpStatus.UNAUTHORIZED, "Connexion requise ou session expirée");
            }
            if (regle.access() == Access.ROLES) {
                String role = claims.get("role", String.class);
                if (role == null || !regle.roles().contains(role)) {
                    return refuser(exchange, HttpStatus.FORBIDDEN, "Accès refusé pour votre rôle");
                }
            }
        }

        ServerHttpRequest transmise = requete.mutate().headers(h -> {
            ENTETES_IDENTITE.forEach(h::remove);
            if (claims != null) {
                h.set("X-User-Id", claims.getSubject());
                h.set("X-User-Role", String.valueOf(claims.get("role", String.class)));
                h.set("X-User-Email", String.valueOf(claims.get("email", String.class)));
                h.set("X-User-Name", URLEncoder.encode(
                        String.valueOf(claims.get("name", String.class)), StandardCharsets.UTF_8));
            }
        }).build();

        return chain.filter(exchange.mutate().request(transmise).build());
    }

    private AccessRule trouverRegle(String methode, String chemin) {
        for (AccessRule regle : REGLES) {
            boolean methodeOk = "*".equals(regle.method()) || regle.method().equals(methode);
            if (methodeOk && matcher.match(regle.pattern(), chemin)) {
                return regle;
            }
        }
        return REGLES.get(REGLES.size() - 1);
    }

    private Claims lireClaims(ServerHttpRequest requete) {
        String entete = requete.getHeaders().getFirst(HttpHeaders.AUTHORIZATION);
        if (entete == null || !entete.startsWith("Bearer ")) {
            return null;
        }
        return jwtVerifier.verifier(entete.substring(7).trim());
    }

    private Mono<Void> refuser(ServerWebExchange exchange, HttpStatus statut, String message) {
        ServerHttpResponse reponse = exchange.getResponse();
        reponse.setStatusCode(statut);
        reponse.getHeaders().setContentType(MediaType.APPLICATION_JSON);
        String json = "{\"status\":" + statut.value() + ",\"message\":\"" + message + "\"}";
        return reponse.writeWith(Mono.just(reponse.bufferFactory().wrap(json.getBytes(StandardCharsets.UTF_8))));
    }

    @Override
    public int getOrder() {
        return -1;
    }
}
